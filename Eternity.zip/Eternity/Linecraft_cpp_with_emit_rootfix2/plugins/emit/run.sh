#!/usr/bin/env sh
python3 "$(dirname "$0")/emit_plugin.py" "$1" "$2"
