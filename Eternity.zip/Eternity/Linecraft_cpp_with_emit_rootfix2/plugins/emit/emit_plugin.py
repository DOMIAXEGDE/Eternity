import json, os, sys
from pathlib import Path

def _die(msg: str, code: int = 2):
    print(msg, file=sys.stderr)
    return code

def _read_json(p: Path):
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)

def _write_json(p: Path, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)

def _safe_resolve_under(root: Path, rel: str, allow_outside: bool) -> Path:
    rel = rel.replace("\\", "/")
    if not allow_outside:
        parts = [p for p in rel.split("/") if p not in ("", ".")]
        if any(p == ".." for p in parts):
            raise ValueError("Path traversal '..' is not allowed: " + rel)
        target = (root / Path(*parts)).resolve()
        if root not in target.parents and target != root:
            raise ValueError("Output path escapes workspace root: " + str(target))
        return target
    return Path(rel).expanduser().resolve() if os.path.isabs(rel) else (root / rel).resolve()

def _parse_context_values(context_path: Path):
    regs = {}
    current_reg = None
    with context_path.open("r", encoding="utf-8", errors="replace") as f:
        for raw_line in f:
            line = raw_line.rstrip("\r\n")
            t = line.strip()
            if not t:
                continue
            if t == "}":
                break
            if (not line.startswith((" ", "\t"))) and ("(" not in line) and ("{" not in line):
                current_reg = t
                regs.setdefault(current_reg, {})
                continue
            if line.startswith((" ", "\t")):
                s = line.lstrip(" \t")
                if "\t" in s:
                    addr, val = s.split("\t", 1)
                else:
                    parts = s.split(maxsplit=1)
                    addr = parts[0]
                    val = parts[1] if len(parts) > 1 else ""
                addr = addr.strip()
                if current_reg is None:
                    current_reg = "01"
                    regs.setdefault(current_reg, {})
                regs.setdefault(current_reg, {})[addr] = val
    return regs

def _collect_from_spec(regs_map, spec, default_reg_tok):
    reg = str(spec.get("reg") or default_reg_tok)
    reg_map = regs_map.get(reg, {})
    out = []

    if "addrs" in spec:
        for a in spec["addrs"]:
            a = str(a)
            out.append(reg_map.get(a, ""))
        return out

    if "range" in spec:
        r = spec["range"]
        a_from = str(r.get("from"))
        a_to = str(r.get("to"))
        keys = sorted(reg_map.keys())
        for k in keys:
            if a_from <= k <= a_to:
                out.append(reg_map[k])
        return out

    if "addr" in spec:
        a = str(spec["addr"])
        out.append(reg_map.get(a, ""))
        return out

    return out

def main():
    if len(sys.argv) < 3:
        return _die("usage: emit_plugin.py <input.json> <outdir>")

    input_path = Path(sys.argv[1])
    outdir = Path(sys.argv[2])
    outdir.mkdir(parents=True, exist_ok=True)

    inp = _read_json(input_path)

    cfg = inp.get("cfg", {})
    prefix = str(cfg.get("prefix", "x"))[:1]
    default_reg = cfg.get("defaultReg", 1)
    if isinstance(default_reg, int):
        default_reg_tok = f"{default_reg:02d}"
    else:
        default_reg_tok = str(default_reg)

    context_file = inp.get("context_file", "")
    if not context_file:
        bank = inp.get("bank", "")
        if not bank:
            return _die("missing bank in input.json")
        bank = str(bank)
        if not bank.startswith(prefix):
            bank = prefix + bank
        context_file = str(Path("files") / f"{bank}.txt")

    context_path = Path(context_file)
    if not context_path.exists():
        return _die(f"context file missing: {context_path}")

    regs_map = _parse_context_values(context_path)

    stdin = inp.get("stdin", {})
    if not isinstance(stdin, dict):
        return _die("stdin must be a JSON object")

    workspace_root = Path.cwd().resolve()
    allow_outside = bool(stdin.get("allow_outside_workspace", False))

    project_root = str(stdin.get("project_root", "files/out/project"))
    try:
        project_abs = _safe_resolve_under(workspace_root, project_root, allow_outside)
    except Exception as e:
        return _die(f"bad project_root: {e}")

    created_dirs = []
    created_files = []

    for d in (stdin.get("mkdir", []) or []):
        try:
            p = _safe_resolve_under(project_abs, str(d), allow_outside=True)
            p.mkdir(parents=True, exist_ok=True)
            created_dirs.append(str(p))
        except Exception as e:
            return _die(f"mkdir failed for '{d}': {e}")

    overwrite = bool(stdin.get("allow_overwrite", False))
    files = stdin.get("files", []) or []
    if not isinstance(files, list):
        return _die("stdin.files must be a list")

    for fdesc in files:
        if not isinstance(fdesc, dict):
            return _die("each files[] entry must be an object")

        rel_path = fdesc.get("path")
        if not rel_path:
            return _die("files[].path is required")

        try:
            file_abs = _safe_resolve_under(project_abs, str(rel_path), allow_outside=True)
        except Exception as e:
            return _die(f"bad file path '{rel_path}': {e}")

        file_abs.parent.mkdir(parents=True, exist_ok=True)

        mode = fdesc.get("mode", "overwrite")  # overwrite | append
        if file_abs.exists() and not overwrite and mode == "overwrite":
            created_files.append({"path": str(file_abs), "status": "skipped_exists"})
            continue

        joiner = fdesc.get("join", "\n")
        ensure_nl = bool(fdesc.get("ensure_final_newline", True))

        content = ""
        if "text" in fdesc:
            content = str(fdesc.get("text", ""))
        elif "from" in fdesc:
            parts = []
            from_list = fdesc.get("from", [])
            if not isinstance(from_list, list):
                return _die("files[].from must be a list")
            for spec in from_list:
                if isinstance(spec, str):
                    if ":" in spec:
                        r, a = spec.split(":", 1)
                        spec = {"reg": r, "addr": a}
                    else:
                        spec = {"addr": spec}
                vals = _collect_from_spec(regs_map, spec, default_reg_tok)
                parts.extend(vals)
            content = joiner.join(parts)
        elif "range" in fdesc:
            vals = _collect_from_spec(regs_map, {"range": fdesc["range"], "reg": fdesc.get("reg")}, default_reg_tok)
            content = joiner.join(vals)
        else:
            return _die(f"files[].text or files[].from or files[].range required for {rel_path}")

        if ensure_nl and not content.endswith("\n"):
            content += "\n"

        try:
            if mode == "append":
                with file_abs.open("a", encoding="utf-8", newline="\n") as out:
                    out.write(content)
            else:
                with file_abs.open("w", encoding="utf-8", newline="\n") as out:
                    out.write(content)
        except Exception as e:
            return _die(f"write failed for '{rel_path}': {e}")

        created_files.append({"path": str(file_abs), "status": "written", "bytes": len(content.encode("utf-8"))})

    report = {
        "ok": True,
        "plugin": "emit",
        "workspace_root": str(workspace_root),
        "project_root": str(project_abs),
        "created_dirs": created_dirs,
        "files": created_files
    }
    _write_json(outdir / "output.json", report)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
