import json, os, sys

def main():
    if len(sys.argv) < 3:
        print("usage: echo_plugin.py <input.json> <outdir>", file=sys.stderr)
        return 2
    input_path = sys.argv[1]
    outdir = sys.argv[2]
    os.makedirs(outdir, exist_ok=True)

    with open(input_path, "r", encoding="utf-8") as f:
        inp = json.load(f)

    code_file = inp.get("code_file", "")
    try:
        with open(code_file, "r", encoding="utf-8") as f:
            code = f.read()
    except Exception as e:
        code = f"[cannot read code_file: {e}]"

    out = {
        "ok": True,
        "plugin": "echo",
        "echo": code,
        "stdin": inp.get("stdin", {}),
        "bank": inp.get("bank"),
        "reg": inp.get("reg"),
        "addr": inp.get("addr"),
    }

    with open(os.path.join(outdir, "output.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
