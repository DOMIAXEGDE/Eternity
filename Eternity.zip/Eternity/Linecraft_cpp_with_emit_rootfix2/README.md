# Linecraft (C++ / Visual Studio 2026 Insiders)

This repo is a **non‑AI** baseline implementation of the clix-style context system captured in `doc.txt`.

What you get:
- Context text format parsing/serialization (bank/register/address)
- A compatible REPL command set (`:open`, `:ins`, `:insr`, `:w`, `:resolve`, `:export`, ...)
- **Optional** *offline* filesystem plugins (`:plugin_run`) — **no AI dependency**

## Build (Windows / VS 2026 Insiders)

### Visual Studio (recommended)
- **File → Open → Folder...** (open this repo)
- Choose preset: `windows-msvc-debug`
- Build target: `linecraft-cli`

### Command line
From “Developer PowerShell for VS”:

```powershell
cmake --preset windows-msvc-debug
cmake --build --preset windows-msvc-debug
```

Binary: `out/build/windows-msvc-debug/linecraft-cli.exe`

## Run
Run from repo root (so `files/` and `plugins/` are found):

```powershell
out\build\windows-msvc-debug\linecraft-cli.exe
```

Try:

```text
:open x00001
:ins 0001 print("hello")
:w
:resolve
:export
:plugins
:plugin_run echo 01 0001 {"note":"demo"}
:q
```

Outputs:
- `files/out/x00001.resolved.txt`
- `files/out/x00001.json`
- `files/out/plugins/x00001/r01a0001/echo/output.json`

## Design note: removing AI plugin components

The prototype design in `doc.txt` mentions “AI plugin” ideas (Codex/Gemini) as a computation oracle.
Linecraft removes that requirement:
- Core editing/resolve/export works with **zero plugins**.
- Plugins are treated as **local programs** invoked via a manifest (`plugins/<name>/plugin.json`).
- Nothing in the host assumes network, LLM APIs, or AI-specific IO.



## Default plugins shipped

### 1) `echo`
Minimal demo plugin (offline) — returns the resolved cell content in `output.json`.

### 2) `emit`
Offline **codebase emitter** — creates directories recursively and writes one/multiple files by
joining address values as multi-line text. Supports any file extension (path determines extension).

**Emit a file from multiple addresses**
```text
:open x00002
:plugin_run emit 01 0001 {"project_root":"files/out/projects/hello","mkdir":["src"],"allow_overwrite":true,
  "files":[
    {"path":"src/main.cpp","from":[{"reg":"01","addrs":["0001","0002","0003","0004","0005"]}],"join":"\n"}
  ]
}
```

**Create a multi-folder project scaffold**
```text
:plugin_run emit 01 0001 {"project_root":"files/out/projects/MyLib","mkdir":["include/mylib","src","tests"],
  "allow_overwrite":true,
  "files":[
    {"path":"include/mylib/mylib.hpp","text":"#pragma once\n\n// ...\n"},
    {"path":"src/mylib.cpp","text":"#include \"mylib/mylib.hpp\"\n"},
    {"path":"CMakeLists.txt","text":"cmake_minimum_required(VERSION 3.28)\nproject(MyLib LANGUAGES CXX)\n"}
  ]
}
```

Notes
- By default, output is restricted to **inside the current workspace root** (the folder you run Linecraft from).
- Use `"allow_outside_workspace": true` only if you intentionally want to write outside the workspace.

## Windows troubleshooting (MSVC + Ninja)

If you see a linker wall like `LNK2019` plus warnings:

`library machine type 'x86' conflicts with target machine type 'x64'`

it means your link search path is resolving **x86** Windows/VC libraries while your build is targeting **x64**.
This repo defensively prepends the expected x64 lib paths (see `LINECRAFT_FORCE_X64_LIBPATH` in `CMakeLists.txt`),
but you should also ensure you are using an **x64** Visual Studio Developer PowerShell / Command Prompt.
