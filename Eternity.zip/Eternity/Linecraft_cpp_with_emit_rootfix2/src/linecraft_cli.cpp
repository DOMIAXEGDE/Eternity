#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <optional>
#include <regex>
#include <sstream>
#include <string>
#include <unordered_set>
#include <vector>
#include <array>

#ifdef _WIN32
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN 1
#  endif
#  ifndef NOMINMAX
#    define NOMINMAX 1
#  endif
#  include <windows.h>
#endif

#if defined(__APPLE__)
#  include <mach-o/dyld.h>
#endif

#if !defined(_WIN32)
#  include <unistd.h>
#endif


namespace fs = std::filesystem;

static void init_console_utf8() {
#ifdef _WIN32
    // Best-effort: ensure UTF-8 output so box drawing / em-dash render correctly
    // even when the host console code page defaults to CP437/850.
    ::SetConsoleOutputCP(CP_UTF8);
    ::SetConsoleCP(CP_UTF8);

    // Optional: allow ANSI/VT sequences when available (harmless if not supported).
    HANDLE hOut = ::GetStdHandle(STD_OUTPUT_HANDLE);
    if (hOut != INVALID_HANDLE_VALUE) {
        DWORD mode = 0;
        if (::GetConsoleMode(hOut, &mode)) {
            mode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
            ::SetConsoleMode(hOut, mode);
        }
    }
#endif
}

//==============================================================================
// Runtime path discovery
//==============================================================================

struct RuntimePaths {
    fs::path root;    // Project root (contains plugins/ and files/)
    fs::path files;   // root/files
    fs::path out;     // root/files/out
    fs::path plugins; // root/plugins
};

static fs::path get_executable_path_fallback(const char* argv0) {
    // argv0 is not reliable on Windows but can help on other platforms.
    if (!argv0 || !*argv0) return {};
    try {
        fs::path p = fs::path(argv0);
        if (p.is_relative()) p = fs::current_path() / p;
        return fs::weakly_canonical(p);
    } catch (...) {
        return {};
    }
}

static fs::path get_executable_path(const char* argv0) {
#ifdef _WIN32
    std::wstring buf(MAX_PATH, L'\0');
    DWORD len = ::GetModuleFileNameW(nullptr, buf.data(), static_cast<DWORD>(buf.size()));
    if (len > 0) {
        buf.resize(len);
        return fs::path(buf);
    }
    return get_executable_path_fallback(argv0);
#elif defined(__APPLE__)
    uint32_t size = 0;
    (void)_NSGetExecutablePath(nullptr, &size);
    if (size > 0) {
        std::string tmp(size, '\0');
        if (_NSGetExecutablePath(tmp.data(), &size) == 0) {
            return fs::weakly_canonical(fs::path(tmp.c_str()));
        }
    }
    return get_executable_path_fallback(argv0);
#else
    std::array<char, 4096> buf{};
    ssize_t n = ::readlink("/proc/self/exe", buf.data(), buf.size() - 1);
    if (n > 0) {
        buf[static_cast<size_t>(n)] = '\0';
        return fs::weakly_canonical(fs::path(buf.data()));
    }
    return get_executable_path_fallback(argv0);
#endif
}

static bool looks_like_root(const fs::path& p) {
    // Minimal heuristic: a plugins directory exists.
    // We don't require files/ because the CLI can create it.
    return fs::exists(p / "plugins") && fs::is_directory(p / "plugins");
}

static fs::path detect_root(const char* argv0) {
    // Search order: CWD then exe-dir, then walk up a few parents.
    std::vector<fs::path> starts;
    try { starts.push_back(fs::current_path()); } catch (...) {}

    fs::path exe = get_executable_path(argv0);
    if (!exe.empty()) starts.push_back(exe.parent_path());

    for (const auto& start : starts) {
        fs::path cur = start;
        for (int i = 0; i < 8; ++i) {
            if (cur.empty()) break;
            if (looks_like_root(cur)) return cur;
            // Secondary hint: CMake project root.
            if (fs::exists(cur / "CMakeLists.txt") && fs::exists(cur / "plugins")) return cur;
            fs::path parent = cur.parent_path();
            if (parent == cur) break;
            cur = parent;
        }
    }
    // Fallback to current directory.
    try { return fs::current_path(); } catch (...) { return {}; }
}

static RuntimePaths make_runtime_paths(const char* argv0) {
    RuntimePaths rp;
    rp.root = detect_root(argv0);
    if (rp.root.empty()) {
        try { rp.root = fs::current_path(); } catch (...) { rp.root = fs::path("."); }
    }
    rp.files = rp.root / "files";
    rp.out = rp.files / "out";
    rp.plugins = rp.root / "plugins";
    return rp;
}


// -----------------------------------------------------------------------------
// Config (mirrors the clix examples in doc.txt; kept small + deterministic)
// -----------------------------------------------------------------------------
struct Config {
    char prefix = 'x';
    int  base = 10;
    int  widthBank = 5;
    int  widthReg  = 2;
    int  widthAddr = 4;
    long long defaultReg = 1; // "01" (doc.txt help: :ins targets register 1)
    RuntimePaths paths;
};

static std::string trim(std::string s) {
    auto ns = [](int ch){ return !std::isspace(ch); };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), ns));
    s.erase(std::find_if(s.rbegin(), s.rend(), ns).base(), s.end());
    return s;
}

static int digit_value(char c){
    if (c>='0' && c<='9') return c-'0';
    if (c>='A' && c<='Z') return 10+(c-'A');
    if (c>='a' && c<='z') return 10+(c-'a');
    return -1;
}

static bool parse_int_base(const std::string& s, int base, long long& out){
    if (s.empty()) return false;
    long long v=0;
    for (char c : s) {
        int d = digit_value(c);
        if (d < 0 || d >= base) return false;
        v = v*base + d;
        if (v < 0) return false;
    }
    out = v;
    return true;
}

static std::string to_base_n(long long val, int base, int width){
    if (base < 2 || base > 36) base = 10;
    if (val == 0) return std::string(std::max(1, width), '0');
    bool neg = val < 0; if (neg) val = -val;
    std::string s;
    while (val > 0) {
        int d = int(val % base);
        s.push_back(d < 10 ? char('0' + d) : char('a' + (d - 10)));
        val /= base;
    }
    if (neg) s.push_back('-');
    std::reverse(s.begin(), s.end());
    if (width > 0 && (int)s.size() < width) s = std::string(width - (int)s.size(), '0') + s;
    return s;
}

static std::string json_escape(const std::string& s){
    std::string o; o.reserve(s.size()+8);
    for (unsigned char c : s) {
        switch (c) {
            case '\\': o += "\\\\"; break;
            case '"':  o += "\\\""; break;
            case '\b': o += "\\b"; break;
            case '\f': o += "\\f"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default:
                if (c < 0x20) { char buf[7]; std::snprintf(buf, sizeof(buf), "\\u%04X", c); o += buf; }
                else o += char(c);
        }
    }
    return o;
}

// -----------------------------------------------------------------------------
// Model
// -----------------------------------------------------------------------------
struct Bank {
    long long id = 0;
    std::string title;
    std::map<long long, std::map<long long, std::string>> regs; // reg -> addr -> value
};

struct Workspace {
    std::map<long long, Bank> banks;
    std::map<long long, fs::path> files;
};

static fs::path ctx_path(const Config& cfg, long long bank){
    return cfg.paths.files / (std::string(1, cfg.prefix) + to_base_n(bank, cfg.base, cfg.widthBank) + ".txt");
}
static fs::path out_resolved_path(const Config& cfg, long long bank){
    return cfg.paths.out / (std::string(1, cfg.prefix) + to_base_n(bank, cfg.base, cfg.widthBank) + ".resolved.txt");
}
static fs::path out_json_path(const Config& cfg, long long bank){
    return cfg.paths.out / (std::string(1, cfg.prefix) + to_base_n(bank, cfg.base, cfg.widthBank) + ".json");
}

static bool read_all(const fs::path& p, std::string& out){
    std::ifstream in(p, std::ios::binary);
    if (!in) return false;
    out.assign((std::istreambuf_iterator<char>(in)), {});
    return true;
}
static bool write_all(const fs::path& p, const std::string& s){
    fs::create_directories(p.parent_path());
    auto tmp = p; tmp += ".tmp";
    {
        std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
        if (!out) return false;
        out.write(s.data(), (std::streamsize)s.size());
        if (!out) return false;
    }
    std::error_code ec;
    fs::rename(tmp, p, ec);
    if (ec) {
        fs::copy_file(tmp, p, fs::copy_options::overwrite_existing, ec);
        fs::remove(tmp);
        if (ec) return false;
    }
    return true;
}

// -----------------------------------------------------------------------------
// Context parsing/writing (compatible with doc.txt examples)
// - Header: x00001\t(title){
// - Optional register lines (00, 02, ...)
// - Address lines indented: \t0001\tvalue
// - If no register line appears, defaultReg is used.
// -----------------------------------------------------------------------------
static bool parse_bank_text(const std::string& text, const Config& cfg, Bank& out, std::string& err){
    std::string content = text;
    if (content.size() >= 3 && (unsigned char)content[0]==0xEF && (unsigned char)content[1]==0xBB && (unsigned char)content[2]==0xBF)
        content.erase(0,3);

    std::vector<std::string> lines;
    {
        std::istringstream is(content);
        std::string line;
        while (std::getline(is, line)) lines.push_back(line);
    }
    if (lines.empty()) { err = "empty"; return false; }

    size_t i=0;
    while (i<lines.size() && trim(lines[i]).empty()) i++;
    if (i==lines.size()) { err = "no header"; return false; }

    std::string header = trim(lines[i]);
    size_t j=i+1;
    while (header.find('{')==std::string::npos && j<lines.size()) {
        header += " " + trim(lines[j]);
        j++;
    }
    auto lp = header.find('(');
    auto rp = header.rfind(')');
    if (lp==std::string::npos || rp==std::string::npos || rp<lp) { err = "bad header"; return false; }

    std::string left = trim(header.substr(0, lp));
    std::string title = trim(header.substr(lp+1, rp-lp-1));
    if (!left.empty() && left[0]==cfg.prefix) left = left.substr(1);

    long long bankId=0;
    if (!parse_int_base(left, cfg.base, bankId)) { err = "bad bank id"; return false; }

    out = {};
    out.id = bankId;
    out.title = title;

    size_t body = i;
    while (body<lines.size() && lines[body].find('{')==std::string::npos) body++;
    if (body==lines.size()) { err = "missing {"; return false; }
    body++;

    long long curReg = cfg.defaultReg;

    for (size_t k=body; k<lines.size(); ++k) {
        std::string s = lines[k];
        if (s.find('}')!=std::string::npos) break;
        if (trim(s).empty()) continue;

        if (!s.empty() && s[0] != '\t' && s[0] != ' ') {
            long long reg=0;
            if (!parse_int_base(trim(s), cfg.base, reg)) { err = "bad register line"; return false; }
            curReg = reg;
            continue;
        }

        while (!s.empty() && (s[0]=='\t' || s[0]==' ')) s.erase(s.begin());
        size_t sep = s.find('\t');
        if (sep==std::string::npos) sep = s.find(' ');
        std::string addrTok, val;
        if (sep==std::string::npos) { addrTok = trim(s); val = ""; }
        else { addrTok = trim(s.substr(0, sep)); val = s.substr(sep+1); }

        long long addr=0;
        if (!parse_int_base(addrTok, cfg.base, addr)) { err = "bad addr"; return false; }
        out.regs[curReg][addr] = val;
    }

    return true;
}

static std::string write_bank_text(const Bank& b, const Config& cfg){
    std::ostringstream os;
    std::string bankStr = std::string(1, cfg.prefix) + to_base_n(b.id, cfg.base, cfg.widthBank);
    os << bankStr << "\t(" << b.title << "){\n";

    bool multi = (b.regs.size()>1) || (b.regs.size()==1 && b.regs.begin()->first != cfg.defaultReg);
    if (!multi) {
        auto it = b.regs.find(cfg.defaultReg);
        if (it != b.regs.end()) {
            for (auto& [addr, val] : it->second)
                os << "\t" << to_base_n(addr, cfg.base, cfg.widthAddr) << "\t" << val << "\n";
        }
    } else {
        for (auto& [reg, addrs] : b.regs) {
            os << to_base_n(reg, cfg.base, cfg.widthReg) << "\n";
            for (auto& [addr, val] : addrs)
                os << "\t" << to_base_n(addr, cfg.base, cfg.widthAddr) << "\t" << val << "\n";
        }
    }

    os << "}\n";
    return os.str();
}

static bool ensure_loaded(const Config& cfg, Workspace& ws, long long bank, std::string& err){
    if (ws.banks.count(bank)) return true;
    auto p = ctx_path(cfg, bank);
    if (!fs::exists(p)) { err = "missing: " + p.string(); return false; }
    std::string text;
    if (!read_all(p, text)) { err = "cannot read: " + p.string(); return false; }
    Bank b;
    if (!parse_bank_text(text, cfg, b, err)) return false;
    ws.banks[bank] = std::move(b);
    ws.files[bank] = p;
    return true;
}

// -----------------------------------------------------------------------------
// Resolver (supports references described in doc.txt):
//   r<reg>.<addr>
//   x<bank>.<reg>.<addr>
//   <bank>.<reg>.<addr>
//   x<bank>.<addr>  (defaults reg=defaultReg)
//   @file(path)
// Circular refs protected.
// -----------------------------------------------------------------------------
struct Resolver {
    const Config& cfg;
    Workspace& ws;

    bool get_value(long long bank, long long reg, long long addr, std::string& out){
        std::string err; (void)ensure_loaded(cfg, ws, bank, err);
        auto itB = ws.banks.find(bank);
        if (itB==ws.banks.end()) return false;
        auto itR = itB->second.regs.find(reg);
        if (itR==itB->second.regs.end()) return false;
        auto itA = itR->second.find(addr);
        if (itA==itR->second.end()) return false;
        out = itA->second;
        return true;
    }

    std::string resolve_string(const std::string& in, long long currentBank, std::unordered_set<std::string> visited){
        std::string s = in;

        // @file(path)
        {
            static const std::regex re(R"(@file\(([^)]+)\))");
            std::smatch m;
            std::string out; out.reserve(s.size());
            auto it=s.cbegin(), end=s.cend();
            while (std::regex_search(it, end, m, re)) {
                out.append(it, m[0].first);
                auto fname = trim(m[1].str());
                std::string txt;
                if (!read_all(fs::path(fname), txt)) out += "[Missing file: " + fname + "]";
                else out += txt;
                it = m[0].second;
            }
            out.append(it, end);
            s.swap(out);
        }

        auto resolve_ref = [&](long long b, long long r, long long a, const std::string& token)->std::string{
            std::string key = std::to_string(b) + "." + std::to_string(r) + "." + std::to_string(a);
            if (visited.count(key)) return "[Circular Ref: " + token + "]";
            std::string v;
            if (!get_value(b, r, a, v)) return "[Missing " + token + "]";
            visited.insert(key);
            return resolve_string(v, b, visited);
        };

        // r<reg>.<addr>
        {
            static const std::regex re(R"(r([0-9A-Za-z]+)\.([0-9A-Za-z]+))");
            std::smatch m;
            std::string out; out.reserve(s.size());
            auto it=s.cbegin(), end=s.cend();
            while (std::regex_search(it, end, m, re)) {
                out.append(it, m[0].first);
                long long r=0,a=0;
                if (!parse_int_base(m[1].str(), cfg.base, r) || !parse_int_base(m[2].str(), cfg.base, a)) out += "[BadRef " + m[0].str() + "]";
                else out += resolve_ref(currentBank, r, a, m[0].str());
                it = m[0].second;
            }
            out.append(it, end);
            s.swap(out);
        }

        // x<bank>.<reg>.<addr>
        {
            const std::regex re(std::string(1,cfg.prefix) + R"(([0-9A-Za-z]+)\.([0-9A-Za-z]+)\.([0-9A-Za-z]+))");
            std::smatch m;
            std::string out; out.reserve(s.size());
            auto it=s.cbegin(), end=s.cend();
            while (std::regex_search(it, end, m, re)) {
                out.append(it, m[0].first);
                long long b=0,r=0,a=0;
                if (!parse_int_base(m[1].str(), cfg.base, b) || !parse_int_base(m[2].str(), cfg.base, r) || !parse_int_base(m[3].str(), cfg.base, a)) out += "[BadRef " + m[0].str() + "]";
                else out += resolve_ref(b, r, a, m[0].str());
                it = m[0].second;
            }
            out.append(it, end);
            s.swap(out);
        }

        // <bank>.<reg>.<addr>
        {
            static const std::regex re(R"(\b([0-9A-Za-z]+)\.([0-9A-Za-z]+)\.([0-9A-Za-z]+)\b)");
            std::smatch m;
            std::string out; out.reserve(s.size());
            auto it=s.cbegin(), end=s.cend();
            while (std::regex_search(it, end, m, re)) {
                out.append(it, m[0].first);
                long long b=0,r=0,a=0;
                if (!parse_int_base(m[1].str(), cfg.base, b) || !parse_int_base(m[2].str(), cfg.base, r) || !parse_int_base(m[3].str(), cfg.base, a)) out += "[BadRef " + m[0].str() + "]";
                else out += resolve_ref(b, r, a, m[0].str());
                it = m[0].second;
            }
            out.append(it, end);
            s.swap(out);
        }

        // x<bank>.<addr> (defaults reg=defaultReg)
        {
            const std::regex re(std::string(1,cfg.prefix) + R"(([0-9A-Za-z]+)\.([0-9A-Za-z]+))");
            std::smatch m;
            std::string out; out.reserve(s.size());
            auto it=s.cbegin(), end=s.cend();
            while (std::regex_search(it, end, m, re)) {
                auto tok = m[0].str();
                if (std::count(tok.begin(), tok.end(), '.') != 1) { out.append(it, m[0].second); it = m[0].second; continue; }
                out.append(it, m[0].first);
                long long b=0,a=0;
                if (!parse_int_base(m[1].str(), cfg.base, b) || !parse_int_base(m[2].str(), cfg.base, a)) out += "[BadRef " + tok + "]";
                else out += resolve_ref(b, cfg.defaultReg, a, tok);
                it = m[0].second;
            }
            out.append(it, end);
            s.swap(out);
        }

        return s;
    }
};

static std::string resolve_bank_to_text(const Config& cfg, Workspace& ws, long long bank){
    std::string err; (void)ensure_loaded(cfg, ws, bank, err);
    auto itB = ws.banks.find(bank);
    if (itB==ws.banks.end()) return {};
    Resolver R{cfg, ws};

    const Bank& b = itB->second;
    std::ostringstream os;
    std::string bankStr = std::string(1, cfg.prefix) + to_base_n(b.id, cfg.base, cfg.widthBank);
    os << bankStr << "\t(" << b.title << "){\n";

    bool multi = (b.regs.size()>1) || (b.regs.size()==1 && b.regs.begin()->first != cfg.defaultReg);
    if (!multi) {
        auto it = b.regs.find(cfg.defaultReg);
        if (it != b.regs.end()) {
            for (auto& [addr, raw] : it->second) {
                auto resolved = R.resolve_string(raw, bank, {});
                os << "\t" << to_base_n(addr, cfg.base, cfg.widthAddr) << "\t" << resolved << "\n";
            }
        }
    } else {
        for (auto& [reg, addrs] : b.regs) {
            os << to_base_n(reg, cfg.base, cfg.widthReg) << "\n";
            for (auto& [addr, raw] : addrs) {
                auto resolved = R.resolve_string(raw, bank, {});
                os << "\t" << to_base_n(addr, cfg.base, cfg.widthAddr) << "\t" << resolved << "\n";
            }
        }
    }
    os << "}\n";
    return os.str();
}

static std::string export_bank_to_json(const Config& cfg, Workspace& ws, long long bank){
    std::string err; (void)ensure_loaded(cfg, ws, bank, err);
    auto itB = ws.banks.find(bank);
    if (itB==ws.banks.end()) return "{}\n";

    const Bank& b = itB->second;
    std::string bankStr = std::string(1, cfg.prefix) + to_base_n(b.id, cfg.base, cfg.widthBank);

    std::ostringstream os;
    os << "{\n";
    os << "  \"bank\": \"" << json_escape(bankStr) << "\",\n";
    os << "  \"title\": \"" << json_escape(b.title) << "\",\n";
    os << "  \"registers\": [\n";

    bool firstReg=true;
    for (auto& [reg, addrs] : b.regs) {
        if (!firstReg) os << ",\n";
        firstReg=false;
        os << "    {\"id\":\"" << json_escape(to_base_n(reg, cfg.base, cfg.widthReg)) << "\",\"addresses\":[\n";
        bool firstAddr=true;
        for (auto& [addr, val] : addrs) {
            if (!firstAddr) os << ",\n";
            firstAddr=false;
            os << "      {\"id\":\"" << json_escape(to_base_n(addr, cfg.base, cfg.widthAddr))
               << "\",\"value\":\"" << json_escape(val) << "\"}";
        }
        os << "\n    ]}";
    }

    os << "\n  ]\n";
    os << "}\n";
    return os.str();
}

// -----------------------------------------------------------------------------
// Offline plugin host (manifest: plugins/<name>/plugin.json)
// Input: input.json + code.txt; Output: output.json
// -----------------------------------------------------------------------------
struct Plugin {
    std::string name;
    std::string entry_win;
    std::string entry_lin;
    fs::path dir;
};

static std::string json_get_str(const std::string& j, const std::string& key){
    auto p = j.find("\"" + key + "\"");
    if (p==std::string::npos) return {};
    p = j.find(':', p); if (p==std::string::npos) return {};
    p = j.find('"', p); if (p==std::string::npos) return {};
    auto q = j.find('"', p+1); if (q==std::string::npos) return {};
    return j.substr(p+1, q-(p+1));
}

static std::vector<Plugin> discover_plugins(const fs::path& pluginsRoot){
    std::vector<Plugin> out;
    fs::path root = pluginsRoot;
    if (root.empty() || !fs::exists(root)) return out;
    for (auto& e : fs::directory_iterator(root)) {
        if (!e.is_directory()) continue;
        auto dir = e.path();
        auto mf = dir / "plugin.json";
        if (!fs::exists(mf)) continue;
        std::string j; if (!read_all(mf, j)) continue;
        Plugin p;
        p.dir = dir;
        p.name = json_get_str(j, "name");
        p.entry_win = json_get_str(j, "entry_win");
        p.entry_lin = json_get_str(j, "entry_lin");
        if (!p.name.empty()) out.push_back(std::move(p));
    }
    return out;
}

static const Plugin* find_plugin(const std::vector<Plugin>& ps, const std::string& name){
    for (auto& p : ps) if (p.name==name) return &p;
    return nullptr;
}

static bool plugin_run(const Config& cfg, Workspace& ws, const Plugin& p,
                       long long bank, long long reg, long long addr,
                       const std::string& stdin_json_or_path,
                       std::string& report){

    Resolver R{cfg, ws};
    std::string raw;
    if (!R.get_value(bank, reg, addr, raw)) { report = "No value at that cell."; return false; }
    std::string code = R.resolve_string(raw, bank, {});

    std::string bankStr = std::string(1, cfg.prefix) + to_base_n(bank, cfg.base, cfg.widthBank);
    std::string regStr  = to_base_n(reg,  cfg.base, cfg.widthReg);
    std::string addrStr = to_base_n(addr, cfg.base, cfg.widthAddr);

    fs::path outdir = cfg.paths.out / "plugins" / bankStr / ("r"+regStr+"a"+addrStr) / p.name;
    fs::create_directories(outdir);

#ifdef _WIN32
    std::string entry = p.entry_win;
#else
    std::string entry = p.entry_lin;
#endif
    if (entry.empty()) { report = "Manifest missing entry for this OS."; return false; }

    fs::path entryPath = fs::absolute(p.dir / entry);
    if (!fs::exists(entryPath)) { report = "Entry not found: " + entryPath.string(); return false; }

    fs::path codeFile   = fs::absolute(outdir / "code.txt");
    fs::path inputFile  = fs::absolute(outdir / "input.json");
    fs::path outputFile = fs::absolute(outdir / "output.json");
    fs::path logFile    = fs::absolute(outdir / "run.log");
    fs::path errFile    = fs::absolute(outdir / "run.err");

    if (!write_all(codeFile, code)) { report = "Cannot write code.txt"; return false; }

    std::string stdin_json = "{}";
    if (!stdin_json_or_path.empty()) {
        if (fs::exists(stdin_json_or_path)) { std::string tmp; if (read_all(stdin_json_or_path, tmp)) stdin_json = tmp; }
        else stdin_json = stdin_json_or_path;
    }

    std::ostringstream is;
    is << "{\n";
    is << "  \"bank\": \"" << json_escape(bankStr) << "\",\n";
    is << "  \"reg\": \"" << json_escape(regStr) << "\",\n";
    is << "  \"addr\": \"" << json_escape(addrStr) << "\",\n";
    is << "  \"title\": \"" << json_escape(ws.banks.at(bank).title) << "\",\n";
    // Engine config for plugins (offline, no AI)
    is << "  \"cfg\": {\n";
    is << "    \"prefix\": \"" << json_escape(std::string(1, cfg.prefix)) << "\",\n";
    is << "    \"base\": " << cfg.base << ",\n";
    is << "    \"widthBank\": " << cfg.widthBank << ",\n";
    is << "    \"widthReg\": " << cfg.widthReg << ",\n";
    is << "    \"widthAddr\": " << cfg.widthAddr << ",\n";
    is << "    \"defaultReg\": " << cfg.defaultReg << "\n";
    is << "  },\n";
    // Absolute path to the context file for this bank
    is << "  \"context_file\": \"" << json_escape(fs::absolute(ctx_path(cfg, bank)).string()) << "\",\n";
    is << "  \"code_file\": \"" << json_escape(codeFile.string()) << "\",\n";
    is << "  \"stdin\": " << (stdin_json.empty()?"{}":stdin_json) << "\n";
    is << "}\n";
    if (!write_all(inputFile, is.str())) { report = "Cannot write input.json"; return false; }

    int ec = 0;

#ifdef _WIN32
    auto dq = [](const std::string& s){ return "\""+s+"\""; };
    const std::string inner =
        dq(entryPath.string()) + " " + dq(inputFile.string()) + " " + dq(fs::absolute(outdir).string()) +
        " > " + dq(logFile.string()) + " 2> " + dq(errFile.string());
    const std::string cmd = std::string("cmd.exe /S /C ") + "\"" + inner + "\"";
    ec = std::system(cmd.c_str());
#else
    auto sq = [](const std::string& s){ return "'"+s+"'"; };
    const std::string inner =
        "\"" + entryPath.string() + "\" \"" + inputFile.string() + "\" \"" + fs::absolute(outdir).string() +
        "\" > \"" + logFile.string() + "\" 2> \"" + errFile.string() + "\"";
    const std::string cmd = std::string("/bin/sh -c ") + sq(inner);
    ec = std::system(cmd.c_str());
#endif

    std::string outJson;
    if (!read_all(outputFile, outJson)) {
        std::string errtxt; (void)read_all(errFile, errtxt);
        report = "Plugin did not produce output.json (exit=" + std::to_string(ec) + ")" + (errtxt.empty()?"":("\nerr:\n"+errtxt));
        return false;
    }

    std::string logtxt, errtxt;
    (void)read_all(logFile, logtxt);
    (void)read_all(errFile, errtxt);

    std::ostringstream rep;
    rep << "exit=" << ec << "\n";
    if (!logtxt.empty()) rep << "log:\n" << logtxt << "\n";
    if (!errtxt.empty()) rep << "stderr:\n" << errtxt << "\n";

    report = rep.str();
    return true;
}

// -----------------------------------------------------------------------------
// CLI
// -----------------------------------------------------------------------------
static void print_help(){
    std::cout <<
R"(────────────────────────────────────────────────────────────────────────────
Linecraft CLI — Help (non‑AI baseline)
────────────────────────────────────────────────────────────────────────────
Quick start
  :open x00001
  :ins 0001 hello
  :insr 02 0003 world
  :show
  :w
  :resolve
  :export
  :plugins
  :plugin_run echo 01 0001 {"note":"demo"}
  :q

Commands
  :help
  :open <ctx>
  :switch <ctx>
  :preload
  :ls
  :show
  :ins <addr> <value...>         (default reg = 01)
  :insr <reg> <addr> <value...>
  :del <addr>
  :delr <reg> <addr>
  :w
  :resolve
  :export
  :plugins
  :plugin_run <name> <reg> <addr> [stdin.json|inlineJSON]
  :q
────────────────────────────────────────────────────────────────────────────
)" << "\n";
}

int main(int argc, char** argv){
    init_console_utf8();
    Config cfg;
    cfg.paths = make_runtime_paths(argc > 0 ? argv[0] : nullptr);
    fs::create_directories(cfg.paths.files);
    fs::create_directories(cfg.paths.out);
    Workspace ws;
    std::vector<Plugin> plugins = discover_plugins(cfg.paths.plugins);

    std::optional<long long> current;
    bool dirty=false;

    std::cout << "Linecraft CLI — shared core (non‑AI)\n";
    std::cout << "Root: " << cfg.paths.root.string() << "\n";
    std::cout << "Type :help for commands.\n\n";

    auto ensure_current = [&](){
        if (!current) { std::cout << "No current context. Use :open <ctx>\n"; return false; }
        return true;
    };

    auto open_ctx = [&](const std::string& token){
        std::string t = token;
        if (!t.empty() && t[0]==cfg.prefix) t = t.substr(1);
        long long id=0;
        if (!parse_int_base(t, cfg.base, id)) { std::cout << "Bad ctx id\n"; return false; }

        auto p = ctx_path(cfg, id);
        if (fs::exists(p)) {
            std::string text, err;
            if (!read_all(p, text)) { std::cout << "Cannot read\n"; return false; }
            Bank b;
            if (!parse_bank_text(text, cfg, b, err)) { std::cout << "Parse error: " << err << "\n"; return false; }
            ws.banks[id] = std::move(b);
            ws.files[id] = p;
            current = id;
            dirty=false;
            std::cout << "Loaded " << p.string() << "\n";
            return true;
        }

        // create
        Bank b;
        b.id = id;
        b.title = std::string(1,cfg.prefix) + to_base_n(id, cfg.base, cfg.widthBank);
        b.regs[cfg.defaultReg] = {};
        auto text = write_bank_text(b, cfg);
        if (!write_all(p, text)) { std::cout << "Cannot create file\n"; return false; }
        ws.banks[id] = std::move(b);
        ws.files[id] = p;
        current = id;
        dirty=false;
        std::cout << "Created " << p.string() << "\n";
        return true;
    };

    auto preload = [&](){
        fs::path dir = cfg.paths.files;
        if (!fs::exists(dir)) return;
        for (auto& e : fs::directory_iterator(dir)) {
            if (!e.is_regular_file()) continue;
            auto p = e.path();
            if (p.extension() != ".txt") continue;
            std::string text; if (!read_all(p, text)) continue;
            Bank b; std::string err;
            if (!parse_bank_text(text, cfg, b, err)) continue;
            ws.banks[b.id] = std::move(b);
            ws.files[b.id] = p;
        }
        std::cout << "Preloaded " << ws.banks.size() << " contexts.\n";
    };

    auto show = [&](){
        if (!ensure_current()) return;
        std::cout << write_bank_text(ws.banks[*current], cfg);
    };

    auto save = [&](){
        if (!ensure_current()) return;
        auto p = ctx_path(cfg, *current);
        auto text = write_bank_text(ws.banks[*current], cfg);
        if (!write_all(p, text)) std::cout << "Save failed\n";
        else { dirty=false; std::cout << "Saved " << p.string() << "\n"; }
    };

    auto list = [&](){
        if (ws.banks.empty()) { std::cout << "(no contexts)\n"; return; }
        for (auto& [id,b] : ws.banks) {
            std::cout << cfg.prefix << to_base_n(id, cfg.base, cfg.widthBank) << "  (" << b.title << ")";
            if (current && *current==id) std::cout << " [current]";
            std::cout << "\n";
        }
    };

    std::string line;
    while (true) {
        std::cout << ">> ";
        if (!std::getline(std::cin, line)) break;
        auto s = trim(line);
        if (s.empty()) continue;

        if (s==":help") { print_help(); continue; }
        if (s==":preload") { preload(); continue; }
        if (s==":ls") { list(); continue; }
        if (s==":show") { show(); continue; }
        if (s==":w") { save(); continue; }

        if (s==":resolve") {
            if (!ensure_current()) continue;
            auto txt = resolve_bank_to_text(cfg, ws, *current);
            auto outp = out_resolved_path(cfg, *current);
            if (!write_all(outp, txt)) std::cout << "Write failed\n";
            else std::cout << "Wrote " << outp.string() << "\n";
            continue;
        }

        if (s==":export") {
            if (!ensure_current()) continue;
            auto js = export_bank_to_json(cfg, ws, *current);
            auto outp = out_json_path(cfg, *current);
            if (!write_all(outp, js)) std::cout << "Write failed\n";
            else std::cout << "Wrote " << outp.string() << "\n";
            continue;
        }

        if (s==":plugins") {
            plugins = discover_plugins(cfg.paths.plugins);
            if (plugins.empty()) std::cout << "(no plugins)\n";
            else for (auto& p : plugins) std::cout << " - " << p.name << " @ " << p.dir.string() << "\n";
            continue;
        }

        if (s==":q") {
            if (dirty) {
                std::cout << "Unsaved changes. Type :w to save or :q again to quit.\n";
                std::string l2;
                std::cout << ">> ";
                if (!std::getline(std::cin, l2)) break;
                if (trim(l2)==":q") break;
                s = trim(l2);
            } else break;
        }

        // Tokenize
        std::istringstream is(s);
        std::vector<std::string> tok;
        for (std::string t; is>>t;) tok.push_back(t);
        if (tok.empty()) continue;

        if (tok[0]==":open" && tok.size()>=2) { open_ctx(tok[1]); continue; }
        if (tok[0]==":switch" && tok.size()>=2) { open_ctx(tok[1]); continue; }

        if (tok[0]==":ins" && tok.size()>=3) {
            if (!ensure_current()) continue;
            long long addr=0; if (!parse_int_base(tok[1], cfg.base, addr)) { std::cout << "Bad address\n"; continue; }
            auto pos = s.find(tok[2]);
            std::string value = (pos==std::string::npos)?"":s.substr(pos);
            ws.banks[*current].regs[cfg.defaultReg][addr] = value;
            dirty=true;
            continue;
        }

        if (tok[0]==":insr" && tok.size()>=4) {
            if (!ensure_current()) continue;
            long long reg=0, addr=0;
            if (!parse_int_base(tok[1], cfg.base, reg)) { std::cout << "Bad reg\n"; continue; }
            if (!parse_int_base(tok[2], cfg.base, addr)) { std::cout << "Bad addr\n"; continue; }
            auto pos = s.find(tok[3]);
            std::string value = (pos==std::string::npos)?"":s.substr(pos);
            ws.banks[*current].regs[reg][addr] = value;
            dirty=true;
            continue;
        }

        if (tok[0]==":del" && tok.size()>=2) {
            if (!ensure_current()) continue;
            long long addr=0; if (!parse_int_base(tok[1], cfg.base, addr)) { std::cout << "Bad addr\n"; continue; }
            auto& m = ws.banks[*current].regs[cfg.defaultReg];
            auto n = m.erase(addr);
            std::cout << (n?"Deleted.\n":"No such addr.\n");
            if (n) dirty=true;
            continue;
        }

        if (tok[0]==":delr" && tok.size()>=3) {
            if (!ensure_current()) continue;
            long long reg=0, addr=0;
            if (!parse_int_base(tok[1], cfg.base, reg)) { std::cout << "Bad reg\n"; continue; }
            if (!parse_int_base(tok[2], cfg.base, addr)) { std::cout << "Bad addr\n"; continue; }
            auto itR = ws.banks[*current].regs.find(reg);
            if (itR==ws.banks[*current].regs.end()) { std::cout << "No such reg\n"; continue; }
            auto n = itR->second.erase(addr);
            std::cout << (n?"Deleted.\n":"No such addr.\n");
            if (n) dirty=true;
            if (itR->second.empty()) ws.banks[*current].regs.erase(itR);
            continue;
        }

        if (tok[0]==":plugin_run" && tok.size()>=4) {
            if (!ensure_current()) continue;
            auto* pl = find_plugin(plugins, tok[1]);
            if (!pl) { std::cout << "No such plugin. Use :plugins\n"; continue; }
            long long reg=0, addr=0;
            if (!parse_int_base(tok[2], cfg.base, reg)) { std::cout << "Bad reg\n"; continue; }
            if (!parse_int_base(tok[3], cfg.base, addr)) { std::cout << "Bad addr\n"; continue; }
            std::string stdin_json = "{}";
            if (tok.size()>=5) {
                auto pos = s.find(tok[4]);
                stdin_json = (pos==std::string::npos)?"{}":s.substr(pos);
            }
            std::string rep;
            bool ok = plugin_run(cfg, ws, *pl, *current, reg, addr, stdin_json, rep);
            std::cout << (ok?"Plugin ok\n":"Plugin failed\n") << rep << "\n";
            continue;
        }

        std::cout << "Unknown / malformed command. Type :help\n";
    }

    return 0;
}