/**
 * operator-framework.js
 * 
 * Base framework that provides the shared namespace for all Operator modules
 */
const OperatorFramework = {};