/**
 * operator-alphabet.js
 * 
 * This module implements the Alphabet System (Tile Color Viewer) for the Operator framework,
 * providing grid visualization and manipulation capabilities.
 * It integrates with the operator-dropdown.js system.
 * 
 * @module OperatorAlphabet
 * @version 1.0.0
 * @depends OperatorFramework.Dropdown
 */

// Access the shared namespace for Operator framework

/**
 * Alphabet System for grid visualization and tile color operations
 * @namespace OperatorAlphabet
 */
OperatorFramework.Alphabet = (function() {
    'use strict';

    // Private module variables
    let _initialized = false;
    let _section = null;
    let _grids = []; // Array to store color sequences of each grid
    let _currentGridIndex = 0; // Index of the currently displayed grid
    let _defaultOptions = {
        containerId: 'main', // ID of the container to add the alphabet section to
        sectionId: 'alphabet-system-section', // ID for the created section element
        defaultTileColor: '#ff0000', // Default tile color
        defaultTileSize: 100 // Default tile size in pixels
    };
    let _options = {};
    
    /**
     * Initialize the Alphabet System
     * @param {Object} options - Configuration options
     * @param {string} [options.containerId='main'] - ID of the container to add the alphabet section to
     * @param {string} [options.sectionId='alphabet-system-section'] - ID for the created section element
     * @param {string} [options.defaultTileColor='#ff0000'] - Default tile color
     * @param {number} [options.defaultTileSize=100] - Default tile size in pixels
     * @returns {boolean} Success status
     */
    function initialize(options = {}) {
        if (_initialized) {
            console.warn('OperatorAlphabet is already initialized');
            return false;
        }
        
        // Merge options with defaults
        _options = { ..._defaultOptions, ...options };
        
        console.log('OperatorAlphabet initialized with default options');
        _initialized = true;
        
        // Register with dropdown system if available
        if (OperatorFramework.Dropdown) {
            OperatorFramework.Dropdown.addSystem({
                id: 'alphabet',
                name: 'Tile Color Viewer',
                description: 'Create and manipulate colorful grid visualizations',
                loadFunction: loadAlphabetSystem
            });
            console.log('Alphabet System registered with OperatorFramework.Dropdown');
        } else {
            console.warn('OperatorFramework.Dropdown not available, Alphabet System not registered');
        }
        
        return true;
    }
    
    /**
     * Load the Alphabet System UI and functionality
     * @returns {boolean} Success status
     */
    function loadAlphabetSystem() {
        if (!_initialized) {
            console.error('OperatorAlphabet not initialized, call initialize() first');
            return false;
        }
        
        // Check if already loaded
        if (_section && document.getElementById(_options.sectionId)) {
            showAlphabetSection();
            return true;
        }
        
        // Get container
        //const container = document.getElementById(_options.containerId);
        // Use:
		const container = document.querySelector('main');
		if (!container) {
            console.error(`Container with ID "${_options.containerId}" not found`);
            return false;
        }
        
        // Create Alphabet System section
        _section = document.createElement('section');
        _section.id = _options.sectionId;
        _section.className = 'operation-section';
        
        // Populate with Alphabet System content
        _section.innerHTML = _getAlphabetSystemHTML();
        
        // Add to container
        container.appendChild(_section);
        
        // Add styles
        _addAlphabetSystemStyles();
        
        // Initialize event listeners
        _initAlphabetSystemEventListeners();
        
        // Show the section
        showAlphabetSection();
        
        // Initialize the grid with default settings
        updateGrid();
        
        console.log('Alphabet System loaded successfully');
        return true;
    }
    
    /**
     * Show the Alphabet System section and hide other sections
     */
    function showAlphabetSection() {
        if (!_section) return;
        
        // Hide all sections
        const allSections = document.querySelectorAll('.operation-section');
        allSections.forEach(section => {
            section.classList.remove('active');
        });
        
        // Show Alphabet section
        _section.classList.add('active');
    }
    
    /**
     * Generate the Alphabet System HTML content
     * @private
     * @returns {string} HTML content
     */
    function _getAlphabetSystemHTML() {
        return `
            <h2>Tile Color Viewer</h2>
            <div class="operation-container">
                <div class="operation-controls">
                    <!-- Hero Section -->
                    <div class="alphabet-hero">
                        <p>Create and customize colorful grids with ease.</p>
                    </div>

                    <!-- Controls Section -->
                    <div id="controls" class="controls-container">
                        <label for="tile-color">Tile Color: </label>
                        <input type="color" id="tile-color" value="${_options.defaultTileColor}">

                        <label for="tile-size">Tile Size (px): </label>
                        <input type="number" id="tile-size" value="${_options.defaultTileSize}" placeholder="Tile size in pixels">

                        <button id="update-grid">Update Grid</button>
                    </div>

                    <!-- Compounded ID Input Container -->
                    <div id="compounded-id-input-container" class="controls-container">
                        <h3>Generate Grids by Compounded IDs</h3>
                        <div id="compounded-id-inputs">
                            <div class="compounded-id-input-row">
                                <input type="text" class="compounded-id-input" placeholder="Enter Compounded Grid ID">
                            </div>
                        </div>
                        <button id="add-compounded-id">+</button>
                        <button id="generate-grid-by-id">Generate Grids</button>
                        <br>
                        <!-- File Upload Input -->
                        <p>Upload a file containing compounded grid IDs (e.g., sequences.txt).</p>
                        <input type="file" id="file-input" accept=".txt">

                        <!-- Execute Button -->
                        <button id="execute-button" aria-label="Process uploaded file">Execute</button>
                    </div>

                    <!-- Color List Container -->
                    <div id="color-list-container" class="controls-container">
                        <h3>Sequence List</h3>
                        <ul id="color-list"></ul>
                        <button id="download-colors">Download Tile ID</button>
                    </div>
                </div>
                
                <div class="operation-result">
                    <h3>Grid Display</h3>
                    
                    <!-- Grid Display Section -->
                    <canvas id="grid-canvas" style="border: 1px solid #ccc;"></canvas>

                    <!-- Navigation Controls -->
                    <div id="navigation-controls">
                        <button id="prev-grid" aria-label="Go to previous grid">Previous Grid</button>
                        <button id="next-grid" aria-label="Go to next grid">Next Grid</button>
                        <button id="download-grid-image" aria-label="Download current grid as image">Download Grid Image</button>
                    </div>

                    <!-- Current Grid Information -->
                    <div id="current-grid-id"></div>
                    <div id="current-grid-position"></div>
                </div>
            </div>
        `;
    }
    
    /**
     * Add CSS styles for the Alphabet System
     * @private
     */
    function _addAlphabetSystemStyles() {
        const styleId = 'operator-alphabet-styles';
        
        // Don't add styles if they already exist
        if (document.getElementById(styleId)) return;
        
        const styleElement = document.createElement('style');
        styleElement.id = styleId;
        styleElement.textContent = `
            /* CSS for Alphabet System */
            #alphabet-system-section {
                --primary-color: #4B5320; /* Army Green */
                --secondary-color: #FFFFFF; /* White */
                --accent-color: #BDB76B; /* Dark Khaki */
                --accent-hover-color: #D2B48C; /* Tan */
                --background-color: #F5F5DC; /* Beige */
                --text-color: #333333; /* Dark Gray */
            }

            /* General Reset - scoped to alphabet section */
            #alphabet-system-section * {
                box-sizing: border-box;
            }

            .alphabet-hero {
                width: 100%;
                text-align: center;
                padding: 20px;
                background-color: var(--primary-color);
                color: var(--secondary-color);
                margin-bottom: 20px;
            }

            .alphabet-hero p {
                font-size: 1.2rem;
            }

            /* Controls Container */
            .controls-container {
                background: var(--secondary-color);
                padding: 20px;
                border: 2px solid var(--accent-color);
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
                width: 100%;
                margin-bottom: 20px;
            }

            #controls {
                display: flex;
                flex-wrap: wrap;
                justify-content: space-between;
                align-items: center;
                gap: 10px;
            }

            #controls label {
                flex: 1 1 200px;
                font-size: 1rem;
                color: var(--primary-color);
                font-weight: 500;
            }

            #controls input {
                flex: 1 1 200px;
                padding: 8px 12px;
                border: 2px solid var(--accent-color);
                font-size: 1rem;
                color: var(--text-color);
                background-color: #F5F5DC; /* Beige */
                font-family: "Fira Code", "Consolas", monospace;
            }

            #controls button {
                flex: 1 1 100%;
                padding: 12px 25px;
                font-size: 1rem;
                color: var(--secondary-color);
                background-color: var(--primary-color);
                border: 2px solid var(--accent-color);
                cursor: pointer;
                transition: background-color 0.3s ease, transform 0.2s ease, color 0.3s ease;
                margin-top: 10px;
                font-family: "Fira Code", "Consolas", monospace;
            }

            #controls button:hover {
                background-color: var(--accent-color);
                color: var(--text-color);
                transform: translateY(-2px);
            }

            /* Grid Canvas */
            #grid-canvas {
                border: 2px solid var(--accent-color);
                margin-bottom: 20px;
                width: 100%;
                max-width: 400px;
                height: auto;
            }

            /* Navigation Controls */
            #navigation-controls {
                display: flex;
                justify-content: center;
                align-items: center;
                gap: 10px;
                width: 100%;
                margin-bottom: 20px;
                flex-wrap: wrap;
            }

            #navigation-controls button {
                padding: 12px 25px;
                font-size: 1rem;
                color: var(--secondary-color);
                background-color: var(--primary-color);
                border: 2px solid var(--accent-color);
                cursor: pointer;
                font-weight: bold;
                transition: background-color 0.3s ease, transform 0.2s ease, color 0.3s ease;
                font-family: "Fira Code", "Consolas", monospace;
            }

            #navigation-controls button:hover {
                background-color: var(--accent-color);
                color: var(--text-color);
                transform: translateY(-2px);
            }

            #navigation-controls button:disabled {
                background-color: #ccc;
                border: 2px solid #999;
                color: #666;
                cursor: not-allowed;
                transform: none;
            }

            /* Current Grid Information */
            #current-grid-id,
            #current-grid-position {
                font-size: 1rem;
                color: var(--primary-color);
                margin-bottom: 10px;
                text-align: center;
                font-weight: 500;
                font-family: "Fira Code", "Consolas", monospace;
            }

            /* Color List Container */
            #color-list-container h3 {
                font-size: 1.2rem;
                margin-bottom: 10px;
                color: var(--primary-color);
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 1px;
            }

            #color-list {
                list-style-type: none;
                padding: 0;
                margin: 0;
            }

            #color-list li {
                background: #F5F5DC; /* Beige */
                padding: 10px;
                margin-bottom: 5px;
                border: 2px solid var(--accent-color);
                font-size: 1rem;
                color: var(--text-color);
                font-family: "Fira Code", "Consolas", monospace;
            }

            /* Download Colors Button */
            #download-colors {
                margin-top: 10px;
                padding: 12px 25px;
                font-size: 1rem;
                color: var(--secondary-color);
                background-color: var(--primary-color);
                border: 2px solid var(--accent-color);
                cursor: pointer;
                transition: background-color 0.3s ease, transform 0.2s ease, color 0.3s ease;
                font-family: "Fira Code", "Consolas", monospace;
            }

            #download-colors:hover {
                background-color: var(--accent-color);
                color: var(--text-color);
                transform: translateY(-2px);
            }

            /* Compounded ID Input Container */
            #compounded-id-inputs {
                display: flex;
                flex-direction: column;
                gap: 10px;
                margin-bottom: 10px;
            }

            .compounded-id-input-row {
                display: flex;
                align-items: center;
            }

            .compounded-id-input {
                flex: 1;
                padding: 8px 12px;
                border: 2px solid var(--accent-color);
                font-size: 1rem;
                color: var(--text-color);
                background-color: #F5F5DC; /* Beige */
                font-family: "Fira Code", "Consolas", monospace;
            }

            /* Add Compounded ID Button */
            #add-compounded-id {
                padding: 10px;
                font-size: 1.5rem;
                color: var(--secondary-color);
                background-color: var(--primary-color);
                border: 2px solid var(--accent-color);
                cursor: pointer;
                transition: background-color 0.3s ease, transform 0.2s ease, color 0.3s ease;
                margin-bottom: 10px;
                width: 40px;
                height: 40px;
                line-height: 20px;
                font-family: "Fira Code", "Consolas", monospace;
            }

            #add-compounded-id:hover {
                background-color: var(--accent-color);
                color: var(--text-color);
                transform: translateY(-2px);
            }

            /* Generate Grids Button */
            #generate-grid-by-id, #execute-button {
                padding: 12px 25px;
                font-size: 1rem;
                color: var(--secondary-color);
                background-color: var(--primary-color);
                border: 2px solid var(--accent-color);
                cursor: pointer;
                transition: background-color 0.3s ease, transform 0.2s ease, color 0.3s ease;
                font-family: "Fira Code", "Consolas", monospace;
                margin-top: 10px;
            }

            #generate-grid-by-id:hover, #execute-button:hover {
                background-color: var(--accent-color);
                color: var(--text-color);
                transform: translateY(-2px);
            }
            
            /* Error messages */
            .error-message {
                color: #e74c3c;
                background-color: rgba(231, 76, 60, 0.1);
                padding: 10px;
                border-left: 4px solid #e74c3c;
                margin-top: 10px;
                font-size: 0.9rem;
            }
            
            /* Success messages */
            .success-message {
                color: #2ecc71;
                background-color: rgba(46, 204, 113, 0.1);
                padding: 10px;
                border-left: 4px solid #2ecc71;
                margin-top: 10px;
                font-size: 0.9rem;
            }
        `;
        
        document.head.appendChild(styleElement);
    }
    
    /**
     * Initialize event listeners for the Alphabet System
     * @private
     */
    function _initAlphabetSystemEventListeners() {
        // Main buttons
        document.getElementById('update-grid').addEventListener('click', updateGrid);
        document.getElementById('add-compounded-id').addEventListener('click', addNewCompoundedIDInput);
        document.getElementById('generate-grid-by-id').addEventListener('click', generateGridsFromInputs);
        document.getElementById('execute-button').addEventListener('click', processUploadedFile);
        document.getElementById('download-colors').addEventListener('click', downloadTileID);
        
        // Navigation buttons
        document.getElementById('prev-grid').addEventListener('click', () => {
            if (_currentGridIndex > 0) {
                _currentGridIndex--;
                displayCurrentGrid();
            }
        });
        
        document.getElementById('next-grid').addEventListener('click', () => {
            if (_currentGridIndex < _grids.length - 1) {
                _currentGridIndex++;
                displayCurrentGrid();
            }
        });
        
        document.getElementById('download-grid-image').addEventListener('click', downloadGridImage);
        
        // Initialize with default value
        const defaultCompoundedID = '1443664';
        document.querySelector('.compounded-id-input').value = defaultCompoundedID;
    }
    
    /**
     * Convert hex color code to a unique numeric ID (BigInt)
     * @param {string} hex - Hex color code
     * @returns {BigInt} Unique numeric ID
     */
    function hexToID(hex) {
        return BigInt('0x' + hex.replace('#', '')) + BigInt(1);
    }
    
    /**
     * Convert numeric ID (BigInt) back to hex color code
     * @param {BigInt|string|number} id - Numeric ID
     * @returns {string} Hex color code
     */
    function idToHex(id) {
        id = BigInt(id);
        if (id <= 0n) {
            return '#000000'; // Default to black
        }
        let hex = (id - BigInt(1)).toString(16).padStart(6, '0');
        return `#${hex}`;
    }
    
    /**
     * Calculate the compounded grid ID from a color sequence
     * @param {Array<string>} colorSequence - Array of hex color codes
     * @returns {string} Compounded grid ID
     */
    function calculateCompoundedGridID(colorSequence) {
        return colorSequence.map(color => hexToID(color).toString()).join('');
    }
    
    /**
     * Calculate grid dimensions based on the number of tiles
     * @param {number} numTiles - Number of tiles
     * @returns {Object} Grid dimensions {rows, cols}
     */
    function calculateGridDimensions(numTiles) {
        const sideLength = Math.ceil(Math.sqrt(numTiles));
        return { rows: sideLength, cols: sideLength };
    }
    
    /**
     * Validate hex color code
     * @param {string} hex - Hex color code
     * @returns {boolean} Whether the hex color code is valid
     */
    function isValidHexColor(hex) {
        return /^#([0-9A-F]{6})$/i.test(hex);
    }
    
    /**
     * Update the grid based on user inputs
     */
    function updateGrid() {
        try {
            const tileColor = document.getElementById('tile-color').value;
            const tileSize = parseInt(document.getElementById('tile-size').value);
            
            if (isNaN(tileSize) || tileSize <= 0) {
                showError("Please enter a valid positive number for tile size.");
                return;
            }
            
            const numTiles = 1; // Start with a single tile
            const colorSequence = Array(numTiles).fill(tileColor);
            _grids = [colorSequence]; // Reset grids array with the new grid
            _currentGridIndex = 0; // Reset to the first grid
            
            displayCurrentGrid();
            
            showSuccess("Grid updated successfully");
        } catch (error) {
            showError(`Error updating grid: ${error.message}`);
            console.error("Error updating grid:", error);
        }
    }
    
    /**
     * Display the current grid based on _currentGridIndex
     */
    function displayCurrentGrid() {
        try {
            const canvas = document.getElementById('grid-canvas');
            const context = canvas.getContext('2d');
            
            if (_grids.length === 0) {
                context.clearRect(0, 0, canvas.width, canvas.height);
                return;
            }
            
            const tileSize = parseInt(document.getElementById('tile-size').value) || _options.defaultTileSize;
            const colorSequence = _grids[_currentGridIndex];
            const numTiles = colorSequence.length;
            const { rows, cols } = calculateGridDimensions(numTiles);
            
            // Set canvas dimensions
            canvas.width = cols * tileSize;
            canvas.height = rows * tileSize;
            
            // Clear the canvas
            context.clearRect(0, 0, canvas.width, canvas.height);
            
            // Draw the grid
            colorSequence.forEach((color, i) => {
                const col = i % cols;
                const row = Math.floor(i / cols);
                const x = col * tileSize;
                const y = row * tileSize;
                
                context.fillStyle = color;
                context.fillRect(x, y, tileSize, tileSize);
                
                // Optional: Add a border to each tile
                context.strokeStyle = '#ccc';
                context.strokeRect(x, y, tileSize, tileSize);
            });
            
            // Remove existing event listeners to prevent stacking
            canvas.onclick = null;
            
            // Add a single event listener to the canvas
            canvas.addEventListener('click', function(event) {
                const rect = canvas.getBoundingClientRect();
                const clickX = event.clientX - rect.left;
                const clickY = event.clientY - rect.top;
                
                const clickedCol = Math.floor(clickX / tileSize);
                const clickedRow = Math.floor(clickY / tileSize);
                const clickedIndex = clickedRow * cols + clickedCol;
                
                if (clickedIndex >= 0 && clickedIndex < colorSequence.length) {
                    const newColor = prompt("Enter new hex color (e.g., #00ff00):", colorSequence[clickedIndex]);
                    if (newColor) {
                        if (isValidHexColor(newColor)) {
                            colorSequence[clickedIndex] = newColor;
                            displayCurrentGrid(); // Redraw the grid
                            showSuccess("Tile color updated");
                        } else {
                            showError('Please enter a valid hex color code (e.g., #00ff00).');
                        }
                    }
                }
            });
            
            updateColorList();
            updateNavigationButtons();
        } catch (error) {
            showError(`Error displaying grid: ${error.message}`);
            console.error("Error displaying grid:", error);
        }
    }
    
    /**
     * Update the color list and display the compounded grid ID
     */
    function updateColorList() {
        try {
            const colorList = document.getElementById('color-list');
            colorList.innerHTML = '';
            const colorSequence = _grids[_currentGridIndex];
            
            colorSequence.forEach((color, index) => {
                const listItem = document.createElement('li');
                listItem.textContent = `ID ${hexToID(color)}: ${color}`;
                colorList.appendChild(listItem);
            });
            
            const compoundedGridID = calculateCompoundedGridID(colorSequence);
            const gridIdElement = document.getElementById('current-grid-id');
            gridIdElement.textContent = `Compounded Grid ID: ${compoundedGridID}`;
            
            const gridPositionElement = document.getElementById('current-grid-position');
            gridPositionElement.textContent = `Grid ${_currentGridIndex + 1} of ${_grids.length}`;
        } catch (error) {
            showError(`Error updating color list: ${error.message}`);
            console.error("Error updating color list:", error);
        }
    }
    
    /**
     * Update the navigation buttons' disabled state
     */
    function updateNavigationButtons() {
        try {
            const prevButton = document.getElementById('prev-grid');
            const nextButton = document.getElementById('next-grid');
            
            prevButton.disabled = _currentGridIndex === 0;
            nextButton.disabled = _currentGridIndex === _grids.length - 1;
        } catch (error) {
            console.error("Error updating navigation buttons:", error);
        }
    }
    
    /**
     * Split a compounded ID into tile IDs
     * @param {string} compoundedID - Compounded grid ID
     * @param {number} tileIDLength - Length of each tile ID
     * @returns {Array<string>} Array of tile IDs
     */
    function splitCompoundedID(compoundedID, tileIDLength) {
        const tileIDs = [];
        let index = 0;
        while (index < compoundedID.length) {
            const tileID = compoundedID.substr(index, tileIDLength);
            tileIDs.push(tileID);
            index += tileIDLength;
        }
        return tileIDs;
    }
    
    /**
     * Regenerate grids from an array of compounded grid IDs
     * @param {Array<string>} compoundedIDs - Array of compounded grid IDs
     */
    function regenerateGrids(compoundedIDs) {
        try {
            if (!compoundedIDs || !Array.isArray(compoundedIDs) || compoundedIDs.length === 0) {
                showError("No valid compounded IDs provided");
                return;
            }
            
            _grids = []; // Reset the grids array
            
            compoundedIDs.forEach((idString, index) => {
                const tileIDLength = 7; // Standard tile ID length
                let tileIDs = [];
                
                idString = idString.trim();
                
                if (/^\d+$/.test(idString)) {
                    // It's a single large number; split it into tile IDs
                    tileIDs = splitCompoundedID(idString, tileIDLength);
                } else {
                    showError(`Invalid Compounded Grid ID format at index ${index}. Please enter a single large integer.`);
                    throw new Error('Invalid Compounded Grid ID format');
                }
                
                const colorSequenceFromID = tileIDs.map(id => {
                    try {
                        const hexColor = idToHex(id);
                        if (isValidHexColor(hexColor)) {
                            return hexColor;
                        } else {
                            showError(`Invalid tile ID: ${id}`);
                            return '#000000'; // Default to black
                        }
                    } catch (error) {
                        console.error(`Error processing tile ID ${id}:`, error);
                        return '#000000'; // Default to black
                    }
                });
                
                _grids.push(colorSequenceFromID);
            });
            
            _currentGridIndex = 0; // Start from the first grid
            displayCurrentGrid();
            
            showSuccess(`Successfully regenerated ${_grids.length} ${_grids.length === 1 ? 'grid' : 'grids'}`);
        } catch (error) {
            showError(`Error regenerating grids: ${error.message}`);
            console.error("Error regenerating grids:", error);
        }
    }
    
    /**
     * Add a new compounded ID input field
     */
    function addNewCompoundedIDInput() {
        try {
            const inputsContainer = document.getElementById('compounded-id-inputs');
            const newInputRow = document.createElement('div');
            newInputRow.className = 'compounded-id-input-row';
            
            const newInput = document.createElement('input');
            newInput.type = 'text';
            newInput.className = 'compounded-id-input';
            newInput.placeholder = 'Enter Compounded Grid ID';
            
            newInputRow.appendChild(newInput);
            inputsContainer.appendChild(newInputRow);
        } catch (error) {
            showError(`Error adding input field: ${error.message}`);
            console.error("Error adding input field:", error);
        }
    }
    
    /**
     * Generate grids from input fields
     */
    function generateGridsFromInputs() {
        try {
            const inputFields = document.querySelectorAll('.compounded-id-input');
            const compoundedIDStrings = [];
            
            inputFields.forEach(input => {
                const idString = input.value.trim();
                if (idString !== '') {
                    compoundedIDStrings.push(idString);
                }
            });
            
            if (compoundedIDStrings.length === 0) {
                showError('Please enter at least one Compounded Grid ID.');
                return;
            }
            
            regenerateGrids(compoundedIDStrings);
        } catch (error) {
            showError(`Error generating grids: ${error.message}`);
            console.error("Error generating grids:", error);
        }
    }
    
    /**
     * Process an uploaded file containing compounded grid IDs
     */
    function processUploadedFile() {
        try {
            const fileInput = document.getElementById('file-input');
            const file = fileInput.files[0];
            
            if (!file) {
                showError("Please select a sequences.txt file before executing.");
                return;
            }
            
            const reader = new FileReader();
            
            reader.onload = function(event) {
                try {
                    const content = event.target.result;
                    const lines = content.split('\n').map(line => line.trim());
                    
                    const validIDs = lines.filter(line => /^\d+$/.test(line)); // Only numeric lines
                    if (validIDs.length > 0) {
                        regenerateGrids(validIDs); // Process the valid compound IDs
                    } else {
                        showError("No valid compound IDs found in the file.");
                    }
                } catch (error) {
                    showError(`Error processing file content: ${error.message}`);
                    console.error("Error processing file content:", error);
                }
            };
            
            reader.onerror = function() {
                showError("Failed to read the file.");
            };
            
            reader.readAsText(file);
        } catch (error) {
            showError(`Error processing file: ${error.message}`);
            console.error("Error processing file:", error);
        }
    }
    
    /**
     * Download the tile ID information
     */
    function downloadTileID() {
        try {
            if (_grids.length === 0 || _currentGridIndex >= _grids.length) {
                showError("No grid available to download");
                return;
            }
            
            const colorSequence = _grids[_currentGridIndex];
            const compoundedGridID = calculateCompoundedGridID(colorSequence);
            const fileContent = colorSequence.map((color, index) => `ID ${hexToID(color)}: ${color}`).join('\n');
            const fullContent = `Compounded Grid ID: ${compoundedGridID}\n\n${fileContent}`;
            
            // Create and download the file
            const blob = new Blob([fullContent], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = 'color_sequence.txt';
            a.click();
            
            URL.revokeObjectURL(url);
            
            showSuccess("Tile ID information downloaded");
        } catch (error) {
            showError(`Error downloading tile ID: ${error.message}`);
            console.error("Error downloading tile ID:", error);
        }
    }
    
    /**
     * Download the current grid as an image
     */
    function downloadGridImage() {
        try {
            const canvas = document.getElementById('grid-canvas');
            const image = canvas.toDataURL('image/png');
            
            // Create and download the image
            const a = document.createElement('a');
            a.href = image;
            a.download = `grid_${_currentGridIndex + 1}.png`;
            a.click();
            
            showSuccess("Grid image downloaded");
        } catch (error) {
            showError(`Error downloading grid image: ${error.message}`);
            console.error("Error downloading grid image:", error);
        }
    }
    
    /**
     * Show an error message
     * @param {string} message - Error message
     */
    function showError(message) {
        // Remove any existing error messages
        const existingError = document.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
        
        // Remove any existing success messages
        const existingSuccess = document.querySelector('.success-message');
        if (existingSuccess) {
            existingSuccess.remove();
        }
        
        // Create and show the error message
        const container = document.getElementById('compounded-id-input-container');
        const errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        errorElement.textContent = message;
        
        container.appendChild(errorElement);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (document.body.contains(errorElement)) {
                errorElement.remove();
            }
        }, 5000);
    }
    
    /**
     * Show a success message
     * @param {string} message - Success message
     */
    function showSuccess(message) {
        // Remove any existing error messages
        const existingError = document.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
        
        // Remove any existing success messages
        const existingSuccess = document.querySelector('.success-message');
        if (existingSuccess) {
            existingSuccess.remove();
        }
        
        // Create and show the success message
        const container = document.getElementById('compounded-id-input-container');
        const successElement = document.createElement('div');
        successElement.className = 'success-message';
        successElement.textContent = message;
        
        container.appendChild(successElement);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (document.body.contains(successElement)) {
                successElement.remove();
            }
        }, 5000);
    }
    
    /**
     * Get the current grids
     * @returns {Array<Array<string>>} The current grids
     */
    function getGrids() {
        return [..._grids];
    }
    
    /**
     * Get the current grid
     * @returns {Array<string>|null} The current grid or null if no grid is available
     */
    function getCurrentGrid() {
        if (_grids.length === 0 || _currentGridIndex >= _grids.length) {
            return null;
        }
        return [..._grids[_currentGridIndex]];
    }
    
    /**
     * Set the current grid
     * @param {Array<string>} colorSequence - The color sequence for the grid
     * @param {boolean} [replace=false] - Whether to replace the current grid or add a new one
     * @returns {boolean} Success status
     */
    function setCurrentGrid(colorSequence, replace = false) {
        if (!colorSequence || !Array.isArray(colorSequence)) {
            return false;
        }
        
        // Validate all colors
        for (const color of colorSequence) {
            if (!isValidHexColor(color)) {
                return false;
            }
        }
        
        if (replace && _grids.length > 0) {
            _grids[_currentGridIndex] = [...colorSequence];
        } else {
            _grids.push([...colorSequence]);
            _currentGridIndex = _grids.length - 1;
        }
        
        displayCurrentGrid();
        return true;
    }
    
    /**
     * Set the current grid index
     * @param {number} index - The index to set
     * @returns {boolean} Success status
     */
    function setCurrentGridIndex(index) {
        if (index < 0 || index >= _grids.length) {
            return false;
        }
        
        _currentGridIndex = index;
        displayCurrentGrid();
        return true;
    }
    
    /**
     * Convert a grid to a data URL
     * @param {number} [index] - Index of the grid to convert, defaults to current grid
     * @returns {string|null} Data URL of the grid or null if no grid is available
     */
    function gridToDataURL(index = null) {
        const gridIndex = index !== null ? index : _currentGridIndex;
        
        if (_grids.length === 0 || gridIndex < 0 || gridIndex >= _grids.length) {
            return null;
        }
        
        const colorSequence = _grids[gridIndex];
        const numTiles = colorSequence.length;
        const { rows, cols } = calculateGridDimensions(numTiles);
        const tileSize = parseInt(document.getElementById('tile-size').value) || _options.defaultTileSize;
        
        // Create a temporary canvas
        const canvas = document.createElement('canvas');
        canvas.width = cols * tileSize;
        canvas.height = rows * tileSize;
        const context = canvas.getContext('2d');
        
        // Draw the grid
        colorSequence.forEach((color, i) => {
            const col = i % cols;
            const row = Math.floor(i / cols);
            const x = col * tileSize;
            const y = row * tileSize;
            
            context.fillStyle = color;
            context.fillRect(x, y, tileSize, tileSize);
            
            // Add a border to each tile
            context.strokeStyle = '#ccc';
            context.strokeRect(x, y, tileSize, tileSize);
        });
        
        return canvas.toDataURL('image/png');
    }
    
    // Public API
    return {
        initialize,
        loadAlphabetSystem,
        showAlphabetSection,
        updateGrid,
        displayCurrentGrid,
        regenerateGrids,
        downloadTileID,
        downloadGridImage,
        getGrids,
        getCurrentGrid,
        setCurrentGrid,
        setCurrentGridIndex,
        gridToDataURL,
        hexToID,
        idToHex,
        calculateCompoundedGridID,
        isValidHexColor
    };
})();

// Automatically initialize when the DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Look for the main container
    const mainElement = document.querySelector('main');
    if (mainElement) {
        OperatorFramework.Alphabet.initialize({
            containerId: mainElement.id || 'main'
        });
        console.log('Alphabet System initialized');
    } else {
        console.warn('Main element not found, Alphabet System not automatically initialized');
    }
});