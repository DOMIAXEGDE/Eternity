#!/usr/bin/env python3
"""
C700h.py (Python 3.14.2)

C700 Host utility: Acceptance → Deterministic Quantum/Classical Circuit Derivation.

Rewritten from the uploaded dimension-generator.py:
- Same acceptance rules (7-digit tokenization, perfect-square grid, color range, adjacency conflict).
- Same deterministic mapping into Qiskit circuits and optional classical "shadow".
- Adds a clean CLI with subcommands: accept, derive, menu.
- Still supports huge integer accepted-states (decimal) and binary "0b...".

Dependencies:
  - derive PNG output:   pip install "qiskit[visualization]" matplotlib numpy pillow
  - category PNG output: pip install matplotlib pillow

Notes:
- Qiskit is imported lazily so `accept` works without Qiskit installed.
- Output defaults to ./out
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
from dataclasses import dataclass
from typing import Any, Iterable, List, Optional, Sequence, Tuple


# -----------------------------
# Constants
# -----------------------------

SEGMENT_LEN: int = 7
MAX_COLOR_INDEX: int = 16 ** 6  # 16777216

GATES: List[str] = ["x", "y", "z", "h", "s", "sdg", "t", "tdg", "rx", "ry", "rz", "cx"]


# -----------------------------
# Acceptance helpers
# -----------------------------

def is_perfect_square(n: int) -> bool:
    if n <= 0:
        return False
    r = math.isqrt(n)
    return r * r == n


def decode_id_to_color_indexes(id_string: str, segment_length: int = SEGMENT_LEN) -> List[int]:
    """
    Mirrors map.js behavior:
    - Split left-to-right into fixed segment_length chunks.
    - No padding.
    - Last segment may be shorter.
    - Non-integer segments are skipped.
    """
    out: List[int] = []
    for i in range(0, len(id_string), segment_length):
        seg = id_string[i : i + segment_length]
        try:
            out.append(int(seg, 10))
        except ValueError:
            # keep behavior: silently ignore invalid chunks
            pass
    return out


def are_valid_color_indexes(indexes: Sequence[int]) -> bool:
    return all(1 <= x <= MAX_COLOR_INDEX for x in indexes)


def has_adjacent_conflict(indexes: Sequence[int], wrap: bool = False) -> bool:
    """
    True if:
    - token count not perfect square, OR
    - any orthogonal neighbor pair in the grid is equal.
    Optional wrap-around adjacency on right and bottom edges.
    """
    if not is_perfect_square(len(indexes)):
        return True

    m = math.isqrt(len(indexes))

    def idx(r: int, c: int) -> int:
        return indexes[r * m + c]

    for r in range(m):
        for c in range(m):
            cur = idx(r, c)

            # right
            if c + 1 < m:
                if cur == idx(r, c + 1):
                    return True
            elif wrap and m > 1:
                if cur == idx(r, 0):
                    return True

            # down
            if r + 1 < m:
                if cur == idx(r + 1, c):
                    return True
            elif wrap and m > 1:
                if cur == idx(0, c):
                    return True

    return False


def color_index_to_hex(index: int) -> str:
    # 1 -> #000000, 16^6 -> #FFFFFF
    v = index - 1
    return "#" + format(v, "06x")


@dataclass(frozen=True)
class AcceptanceReport:
    ok: bool
    reason: str
    m: int
    indexes: List[int]
    hex_colors: List[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "reason": self.reason,
            "m": self.m,
            "token_count": len(self.indexes),
            "indexes": self.indexes,
            "hex_colors": self.hex_colors,
        }


def verify_acceptance_from_decimal_string(id_decimal: str, wrap_adjacency: bool = False) -> AcceptanceReport:
    indexes = decode_id_to_color_indexes(id_decimal, segment_length=SEGMENT_LEN)

    if not is_perfect_square(len(indexes)):
        return AcceptanceReport(
            False,
            f"Token count {len(indexes)} is not a perfect square.",
            0,
            list(indexes),
            [],
        )

    m = math.isqrt(len(indexes))

    if not are_valid_color_indexes(indexes):
        return AcceptanceReport(
            False,
            "One or more tokens are outside [1..16^6].",
            m,
            list(indexes),
            [],
        )

    if has_adjacent_conflict(indexes, wrap=wrap_adjacency):
        return AcceptanceReport(
            False,
            "Adjacency conflict: at least one orthogonal neighbor pair is equal.",
            m,
            list(indexes),
            [],
        )

    hex_colors = [color_index_to_hex(x) for x in indexes]
    return AcceptanceReport(True, "Accepted.", m, list(indexes), hex_colors)


# -----------------------------
# Deterministic circuit derivation
# -----------------------------

def token_to_angle(token: int) -> float:
    # Deterministic discrete angle: multiples of pi/16 (never 0)
    k = (token % 32) + 1
    return k * (math.pi / 16.0)


def derive_quantum_and_classical_from_grid(
    indexes: Sequence[int],
    m: int,
    max_qubits: int = 8,
    max_layers: int = 16,
    reversible_only: bool = False,
):
    """
    Deterministic mapping:
    - Qubits = min(m, max_qubits)
    - Layers = min(m, max_layers)
    - Gate for (r,c) chosen by token % len(GATES)

    classical_shadow keeps:
    - x and cx when they occur (and in reversible_only mode)
    """
    # Lazy import so accept/help can run without qiskit installed
    from qiskit import QuantumCircuit  # type: ignore

    q = min(m, max_qubits)
    layers = min(m, max_layers)

    qc = QuantumCircuit(q, name="derived_quantum")
    cc = QuantumCircuit(q, name="classical_shadow")

    def grid_token(r: int, c: int) -> int:
        return indexes[r * m + c]

    for r in range(layers):
        for c in range(q):
            tok = grid_token(r, c)
            gate = GATES[tok % len(GATES)]

            if reversible_only:
                # force into exact classical correspondence
                gate = "cx" if (tok % 2 == 1 and q > 1) else "x"

            if gate in ("x", "y", "z", "h", "s", "sdg", "t", "tdg"):
                getattr(qc, gate)(c)
                if gate == "x":
                    cc.x(c)

            elif gate == "cx":
                if q == 1:
                    qc.x(c)
                    cc.x(c)
                else:
                    control = c
                    shift = 1 + (tok % (q - 1))
                    target = (c + shift) % q
                    qc.cx(control, target)
                    cc.cx(control, target)

            elif gate in ("rx", "ry", "rz"):
                ang = token_to_angle(tok)
                getattr(qc, gate)(ang, c)
                # no classical equivalent in shadow

        qc.barrier()

    return qc, cc


# -----------------------------
# Output helpers
# -----------------------------

def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def save_circuit_png(qc, path: str) -> None:
    from qiskit.visualization import circuit_drawer  # type: ignore
    circuit_drawer(qc, output="mpl", filename=path)


def combine_pngs_side_by_side(left_path: str, right_path: str, out_path: str) -> None:
    """
    Create a clean side-by-side "assembly" PNG.

    Improvements over the earlier helper:
      - trims excess whitespace around each image (matplotlib outputs often have large margins)
      - matches heights by resizing proportionally
      - uses a white background (no black blocks)
      - vertically centers both panels

    Requires: Pillow
    """
    from PIL import Image, ImageChops  # type: ignore

    def _trim_whitespace(im: Image.Image, bg_rgb=(255, 255, 255), pad: int = 16) -> Image.Image:
        # Work in RGB for robust diff.
        rgb = im.convert("RGB")
        bg = Image.new("RGB", rgb.size, bg_rgb)
        diff = ImageChops.difference(rgb, bg).convert("L")
        # Threshold small compression artifacts
        diff = diff.point(lambda p: 255 if p > 10 else 0)
        bbox = diff.getbbox()
        if not bbox:
            return im
        x0, y0, x1, y1 = bbox
        x0 = max(0, x0 - pad)
        y0 = max(0, y0 - pad)
        x1 = min(im.width, x1 + pad)
        y1 = min(im.height, y1 + pad)
        return im.crop((x0, y0, x1, y1))

    a = Image.open(left_path).convert("RGBA")
    b = Image.open(right_path).convert("RGBA")

    a = _trim_whitespace(a)
    b = _trim_whitespace(b)

    # Match heights (like the quantum/classical assembly)
    target_h = max(a.height, b.height)

    def _resize_to_h(im: Image.Image, h: int) -> Image.Image:
        if im.height == h:
            return im
        w = int(round(im.width * (h / float(im.height))))
        return im.resize((w, h), resample=Image.Resampling.LANCZOS)

    a2 = _resize_to_h(a, target_h)
    b2 = _resize_to_h(b, target_h)

    pad = 24
    w = a2.width + b2.width + pad * 3
    h = target_h + pad * 2

    canvas = Image.new("RGBA", (w, h), (255, 255, 255, 255))

    # Center vertically (mostly redundant after height-match, but keeps future-proof)
    y_a = pad + (target_h - a2.height) // 2
    y_b = pad + (target_h - b2.height) // 2

    canvas.paste(a2, (pad, y_a), a2)
    canvas.paste(b2, (pad * 2 + a2.width, y_b), b2)

    # Save as RGB (avoids odd alpha rendering in some viewers)
    canvas.convert("RGB").save(out_path)

def write_gate_sequence(qc, out_txt: str) -> None:
    """
    Qiskit 1.x compatible:
    - qc.data yields CircuitInstruction objects
    - Qubit index obtained via qc.find_bit(qubit).index
    """
    parts: List[str] = []

    for ci in qc.data:
        op = ci.operation
        if op.name == "barrier":
            continue

        qinds = [qc.find_bit(q).index for q in ci.qubits]

        if op.name in ("rx", "ry", "rz"):
            angle = op.params[0]
            parts.append(f"{op.name}({angle},{qinds[0]})")
        elif op.name == "cx":
            parts.append(f"cx({qinds[0]},{qinds[1]})")
        else:
            parts.append(f"{op.name}({qinds[0]})")

    with open(out_txt, "w", encoding="utf-8") as f:
        f.write(" ".join(parts) + "\n")



# -----------------------------
# Deterministic semantic category derivation + diagram rendering
# -----------------------------

def _hex_luma(hex_color: str) -> float:
    """Return perceived luminance in [0,1] for '#RRGGBB'."""
    hc = hex_color.lstrip("#")
    r = int(hc[0:2], 16) / 255.0
    g = int(hc[2:4], 16) / 255.0
    b = int(hc[4:6], 16) / 255.0
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _hex_to_rgb01(hex_color: str) -> tuple[float, float, float]:
    hc = hex_color.lstrip("#")
    r = int(hc[0:2], 16) / 255.0
    g = int(hc[2:4], 16) / 255.0
    b = int(hc[4:6], 16) / 255.0
    return (r, g, b)


def token_to_semantic_symbol(token: int, q: int, reversible_only: bool = False) -> str:
    """
    Semantic label for a token.

    - Mirrors the derive mapping: gate name chosen by token % len(GATES)
    - In reversible_only: coerces to x/cx exactly like circuit derivation
    - For rotation gates: includes a discrete angle class (k·pi/16)
    - For cx: includes deterministic shift class when q>1
    """
    gate = GATES[token % len(GATES)]
    if reversible_only:
        gate = "cx" if (token % 2 == 1 and q > 1) else "x"

    if gate in ("rx", "ry", "rz"):
        k = (token % 32) + 1
        return f"{gate}(k={k})"
    if gate == "cx":
        if q <= 1:
            return "x"
        shift = 1 + (token % (q - 1))
        return f"cx(shift={shift})"
    return gate


def derive_semantic_category_from_grid(
    indexes: Sequence[int],
    m: int,
    max_qubits: int = 8,
    max_layers: int = 16,
    reversible_only: bool = False,
) -> dict[str, Any]:
    """
    Build a deterministic *semantic* category presentation.

    Semantics (default):
      - Objects = unique semantic symbols induced by the derive mapping (gate semantics),
        rather than one object per cell.
      - Generators = observed orthogonal adjacency relations between semantic symbols
        (east + south) restricted to the same window used by circuit derivation:
          q = min(m, max_qubits)
          layers = min(m, max_layers)

    The category is presented as the free category on this generator graph
    (identities + composition by paths are implicit).

    Returns a JSON-serializable dict with objects + aggregated generators.
    """
    q = min(m, max_qubits)
    layers = min(m, max_layers)

    def grid_token(r: int, c: int) -> int:
        return int(indexes[r * m + c])

    # Aggregate objects (semantic symbols) and representative/average colors
    obj_set: set[str] = set()
    rgb_sum: dict[str, list[float]] = {}
    rgb_n: dict[str, int] = {}

    # Aggregate generators: key=(src,dst,kind) -> {count, examples}
    gen: dict[tuple[str, str, str], dict[str, Any]] = {}

    def add_obj(sym: str, hex_color: str) -> None:
        obj_set.add(sym)
        r, g, b = _hex_to_rgb01(hex_color)
        if sym not in rgb_sum:
            rgb_sum[sym] = [0.0, 0.0, 0.0]
            rgb_n[sym] = 0
        rgb_sum[sym][0] += r
        rgb_sum[sym][1] += g
        rgb_sum[sym][2] += b
        rgb_n[sym] += 1

    def add_edge(src: str, dst: str, kind: str, at_rc: tuple[int, int]) -> None:
        key = (src, dst, kind)
        if key not in gen:
            gen[key] = {"src": src, "dst": dst, "kind": kind, "count": 0, "examples": []}
        gen[key]["count"] += 1
        # store up to a few examples deterministically
        if len(gen[key]["examples"]) < 12:
            gen[key]["examples"].append({"at": [at_rc[0], at_rc[1]]})

    # Walk same window used for circuit derivation (layers x q)
    for r in range(layers):
        for c in range(q):
            tok = grid_token(r, c)
            sym = token_to_semantic_symbol(tok, q=q, reversible_only=reversible_only)
            add_obj(sym, color_index_to_hex(tok))

            # East adjacency (within window)
            if c + 1 < q:
                tok2 = grid_token(r, c + 1)
                sym2 = token_to_semantic_symbol(tok2, q=q, reversible_only=reversible_only)
                add_obj(sym2, color_index_to_hex(tok2))
                add_edge(sym, sym2, "E", (r, c))

            # South adjacency (within window)
            if r + 1 < layers:
                tok2 = grid_token(r + 1, c)
                sym2 = token_to_semantic_symbol(tok2, q=q, reversible_only=reversible_only)
                add_obj(sym2, color_index_to_hex(tok2))
                add_edge(sym, sym2, "S", (r, c))

    objects = sorted(obj_set)

    # Representative color per object = average of contributing token colors
    obj_color: dict[str, str] = {}
    for o in objects:
        n = max(1, int(rgb_n.get(o, 1)))
        r, g, b = (rgb_sum[o][0] / n, rgb_sum[o][1] / n, rgb_sum[o][2] / n)
        obj_color[o] = "#" + "".join(f"{int(max(0,min(255,round(v*255)))):02x}" for v in (r, g, b))

    generators = []
    for (src, dst, kind), payload in gen.items():
        label = f"{kind}×{payload['count']}"
        generators.append(
            {
                "src": src,
                "dst": dst,
                "kind": kind,
                "count": int(payload["count"]),
                "label": label,
                "examples": payload["examples"],
            }
        )

    # stable ordering for determinism
    generators.sort(key=lambda e: (e["src"], e["dst"], e["kind"]))

    return {
        "kind": "semantic_free_category_presentation",
        "objects": [{"id": o, "color": obj_color[o]} for o in objects],
        "generators": generators,
        "composition": "paths (free category on the generator graph)",
        "identities": "implicit for each object",
        "window": {"q": q, "layers": layers, "m": m},
        "reversible_only": bool(reversible_only),
    }


def render_grid_png(
    indexes: Sequence[int],
    hex_colors: Sequence[str],
    m: int,
    out_path: str,
    show_cell_labels: bool = False,
) -> None:
    """Render the token grid as a deterministic PNG."""
    try:
        import matplotlib.pyplot as plt
        from matplotlib.patches import Rectangle
    except ModuleNotFoundError as e:
        raise ModuleNotFoundError(
            "Missing dependency: matplotlib (needed for grid/category PNG). Install with: pip install matplotlib"
        ) from e

    fig_w = max(4.0, float(m) * 1.05)
    fig_h = max(4.0, float(m) * 1.05)
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))

    for r in range(m):
        for c in range(m):
            i = r * m + c
            fc = hex_colors[i]
            ax.add_patch(Rectangle((c, -r - 1), 1, 1, facecolor=fc, edgecolor="black", linewidth=1.0))
            if show_cell_labels:
                luma = _hex_luma(fc)
                txt_color = "white" if luma < 0.45 else "black"
                ax.text(c + 0.5, -r - 0.5, str(indexes[i]), ha="center", va="center", fontsize=6, color=txt_color)

    ax.set_aspect("equal")
    ax.set_xlim(0, m)
    ax.set_ylim(-m, 0)
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(out_path, dpi=220)
    plt.close(fig)


def render_semantic_category_png(category: dict[str, Any], out_path: str, show_edge_labels: bool = True) -> None:
    """
    Render the semantic category diagram as a deterministic PNG.

    Key goals:
      - stable (deterministic) layout
      - readable (avoid massive whitespace / "content shoved into a corner")
      - assembly-friendly (cropped margins)

    Layout:
      - nodes placed on a circle in sorted object-id order (deterministic)
      - edges drawn as directed arrows
      - node labels are shortened to fit inside nodes (full ids remain in category.json)
      - edge labels are only shown when count > 1 (or if you pass --hide-edge-labels to hide all)
    """
    try:
        import matplotlib.pyplot as plt
        from matplotlib.patches import FancyArrowPatch, Circle
    except ModuleNotFoundError as e:
        raise ModuleNotFoundError(
            "Missing dependency: matplotlib (needed for category PNG). Install with: pip install matplotlib"
        ) from e

    objects = [o["id"] for o in category.get("objects", [])]
    colors = {o["id"]: o.get("color", "#888888") for o in category.get("objects", [])}
    gens = list(category.get("generators", []))

    # Deterministic circle layout
    n = max(1, len(objects))
    import math as _math

    pos: dict[str, tuple[float, float]] = {}
    for i, oid in enumerate(objects):
        ang = (2.0 * _math.pi * i) / n
        pos[oid] = (_math.cos(ang), _math.sin(ang))

    # Short labels so text doesn't blow up layout
    def _short_label(oid: str) -> str:
        if oid.startswith("rx(k=") or oid.startswith("ry(k=") or oid.startswith("rz(k="):
            # rx(k=25) -> rx25
            m = re.match(r"^(r[xyz])\(k=(\d+)\)$", oid)
            if m:
                return f"{m.group(1)}{m.group(2)}"
        if oid.startswith("cx(shift="):
            m = re.match(r"^cx\(shift=(\d+)\)$", oid)
            if m:
                return f"cx{m.group(1)}"
        return oid

    # Fixed figure size (avoid n-based runaway whitespace)
    fig, ax = plt.subplots(figsize=(8.0, 8.0))

    idx_map = {oid: i for i, oid in enumerate(objects)}

    def _curve_for(kind: str, src: str, dst: str) -> float:
        if src == dst:
            return 0.35
        base = 0.18 if kind == "E" else -0.18
        base += ((idx_map[src] - idx_map[dst]) % 7 - 3) * 0.01
        return base

    # Draw edges first
    for e in gens:
        src = e.get("src")
        dst = e.get("dst")
        if src not in pos or dst not in pos:
            continue
        x0, y0 = pos[src]
        x1, y1 = pos[dst]
        kind = str(e.get("kind", ""))
        rad = _curve_for(kind, src, dst)

        arrow = FancyArrowPatch(
            (x0, y0),
            (x1, y1),
            arrowstyle="->",
            mutation_scale=12,
            linewidth=1.15,
            color="black",
            connectionstyle=f"arc3,rad={rad}",
        )
        ax.add_patch(arrow)

        if show_edge_labels:
            # reduce clutter: only label multiplicities > 1
            count = int(e.get("count", 1) or 1)
            if count > 1:
                mx, my = (x0 + x1) / 2.0, (y0 + y1) / 2.0
                ax.text(mx, my + rad * 0.35, f"{kind}×{count}", ha="center", va="center", fontsize=9)

    # Draw nodes
    radius = 0.13  # stable size
    for oid in objects:
        x, y = pos[oid]
        fc = colors.get(oid, "#888888")
        ax.add_patch(Circle((x, y), radius=radius, facecolor=fc, edgecolor="black", linewidth=1.2))
        luma = _hex_luma(fc)
        txt_color = "white" if luma < 0.45 else "black"
        ax.text(x, y, _short_label(oid), ha="center", va="center", fontsize=10, color=txt_color)

    # FIXED limits so content stays centered and uses the canvas
    ax.set_aspect("equal")
    ax.set_xlim(-1.35, 1.35)
    ax.set_ylim(-1.35, 1.35)
    ax.axis("off")

    # Save tightly (removes massive margins) but with padding for labels/arrows
    fig.savefig(out_path, dpi=220, bbox_inches="tight", pad_inches=0.2, facecolor="white")
    plt.close(fig)


# -----------------------------
# Input parsing
# -----------------------------

_DEC_RE = re.compile(r"^[0-9]+$")


def parse_accepted_state_to_decimal_string(raw: str) -> str:
    """
    Accepts:
      - decimal integer string (possibly huge)
      - binary with 0b prefix
    Returns canonical decimal string (no leading zeros except "0").
    """
    s = raw.strip()
    if s.lower().startswith("0b"):
        n = int(s, 2)
        return str(n)

    if not _DEC_RE.fullmatch(s):
        raise ValueError("Not a valid decimal integer string (or 0b... binary).")

    # allow huge integers; normalize leading zeros
    s2 = s.lstrip("0")
    return s2 if s2 != "" else "0"


def read_text_file(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()


# -----------------------------
# Commands
# -----------------------------

def cmd_accept(args: argparse.Namespace) -> int:
    raw = read_text_file(args.infile) if args.infile else args.state
    if raw is None:
        print("No state provided. Use --state or --in.", file=sys.stderr)
        return 2

    try:
        dec_str = parse_accepted_state_to_decimal_string(raw)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        return 2

    report = verify_acceptance_from_decimal_string(dec_str, wrap_adjacency=args.wrap)
    if args.json:
        print(json.dumps(report.to_dict(), indent=2))
    else:
        print(report.reason)
        if report.ok:
            print(f"Grid: {report.m} x {report.m} (tokens={len(report.indexes)})")
            if args.show_hex:
                print("Hex colors:")
                print(" ".join(report.hex_colors))
            if args.show_indexes:
                print("Indexes:")
                print(" ".join(str(x) for x in report.indexes))

    return 0 if report.ok else 1


def cmd_derive(args: argparse.Namespace) -> int:
    raw = read_text_file(args.infile) if args.infile else args.state
    if raw is None:
        print("No state provided. Use --state or --in.", file=sys.stderr)
        return 2

    try:
        dec_str = parse_accepted_state_to_decimal_string(raw)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        return 2

    report = verify_acceptance_from_decimal_string(dec_str, wrap_adjacency=args.wrap)
    if not report.ok:
        print(f"Acceptance check: {report.reason}", file=sys.stderr)
        return 1

    print(f"Accepted. Grid: {report.m} x {report.m} (tokens={len(report.indexes)})")

    try:
        qc, cc = derive_quantum_and_classical_from_grid(
            indexes=report.indexes,
            m=report.m,
            max_qubits=args.max_qubits,
            max_layers=args.max_layers,
            reversible_only=args.reversible_only,
        )
    except ModuleNotFoundError:
        print(
            "Missing dependency: qiskit.\n"
            'Install with: pip install "qiskit[visualization]" matplotlib numpy pillow',
            file=sys.stderr,
        )
        return 2

    outdir = args.outdir
    ensure_dir(outdir)

    # Save text gate sequences
    q_txt = os.path.join(outdir, "source_quantum.txt")
    c_txt = os.path.join(outdir, "source_classical.txt")
    write_gate_sequence(qc, q_txt)
    write_gate_sequence(cc, c_txt)

    wrote: List[str] = [q_txt, c_txt]

    # Save PNGs (optional)
    if not args.no_png:
        try:
            q_png = os.path.join(outdir, "quantum.png")
            c_png = os.path.join(outdir, "classical.png")
            a_png = os.path.join(outdir, "assembly.png")

            save_circuit_png(qc, q_png)
            save_circuit_png(cc, c_png)
            wrote.extend([q_png, c_png])

            try:
                combine_pngs_side_by_side(q_png, c_png, a_png)
                wrote.append(a_png)
            except ModuleNotFoundError:
                # Pillow missing; keep individual PNGs
                pass

        except Exception as e:
            print(f"PNG render failed: {e}", file=sys.stderr)
            print("Tip: ensure matplotlib + pillow are installed.", file=sys.stderr)

    # Save a minimal manifest (handy for pipelines)
    manifest = {
        "accepted": True,
        "grid_m": report.m,
        "token_count": len(report.indexes),
        "wrap_adjacency": bool(args.wrap),
        "reversible_only": bool(args.reversible_only),
        "max_qubits": int(args.max_qubits),
        "max_layers": int(args.max_layers),
        "outputs": wrote,
    }
    mf = os.path.join(outdir, "manifest.json")
    with open(mf, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    wrote.append(mf)

    print("Wrote:")
    for p in wrote:
        print(f"  {p}")

    return 0

def cmd_category(args: argparse.Namespace) -> int:
    raw = read_text_file(args.infile) if args.infile else args.state
    if raw is None:
        print("No state provided. Use --state or --in.", file=sys.stderr)
        return 2

    try:
        dec_str = parse_accepted_state_to_decimal_string(raw)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        return 2

    report = verify_acceptance_from_decimal_string(dec_str, wrap_adjacency=args.wrap)
    if not report.ok:
        print(f"Acceptance check: {report.reason}", file=sys.stderr)
        return 1

    outdir = args.outdir
    ensure_dir(outdir)

    # Derive semantic category (free category presentation over semantic adjacency graph)
    cat = derive_semantic_category_from_grid(
        indexes=report.indexes,
        m=report.m,
        max_qubits=args.max_qubits,
        max_layers=args.max_layers,
        reversible_only=args.reversible_only,
    )

    cat_path = os.path.join(outdir, "category.json")
    with open(cat_path, "w", encoding="utf-8") as f:
        json.dump(cat, f, indent=2)

    wrote: List[str] = [cat_path]

    # PNG outputs (optional)
    if not args.no_png:
        # grid view (helps as a deterministic "assembly" companion)
        grid_png = os.path.join(outdir, "grid.png")
        cat_png = os.path.join(outdir, "category.png")
        asm_png = os.path.join(outdir, "category_assembly.png")

        try:
            render_grid_png(
                indexes=report.indexes,
                hex_colors=report.hex_colors,
                m=report.m,
                out_path=grid_png,
                show_cell_labels=args.show_grid_labels,
            )
            wrote.append(grid_png)
        except Exception as e:
            print(f"Grid PNG render failed: {e}", file=sys.stderr)

        try:
            render_semantic_category_png(cat, cat_png, show_edge_labels=not args.hide_edge_labels)
            wrote.append(cat_png)
        except Exception as e:
            print(f"Category PNG render failed: {e}", file=sys.stderr)

        if args.assembly:
            try:
                if os.path.exists(grid_png) and os.path.exists(cat_png):
                    combine_pngs_side_by_side(grid_png, cat_png, asm_png)
                    wrote.append(asm_png)
            except ModuleNotFoundError:
                # Pillow missing; assembly is optional
                pass
            except Exception:
                pass

    manifest = {
        "accepted": True,
        "grid_m": report.m,
        "token_count": len(report.indexes),
        "wrap_adjacency": bool(args.wrap),
        "reversible_only": bool(args.reversible_only),
        "max_qubits": int(args.max_qubits),
        "max_layers": int(args.max_layers),
        "outputs": wrote,
        "category_kind": cat.get("kind", "semantic_free_category_presentation"),
    }
    mf = os.path.join(outdir, "category_manifest.json")
    with open(mf, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    wrote.append(mf)

    print("Wrote:")
    for p in wrote:
        print(f"  {p}")
    return 0




def cmd_menu(_: argparse.Namespace) -> int:
    # Simple interactive fallback (similar to original)
    print("\nC700h — Acceptance → Quantum/Classical Circuit Deriver\n")
    while True:
        try:
            mode = input("Enter 1=derive, 2=accept-only, 3=exit: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0

        if mode == "3":
            return 0

        if mode not in ("1", "2"):
            print("Unknown mode.\n")
            continue

        raw = input("Paste accepted state (decimal or 0b... binary): ").strip()
        wrap = input("Wrap-around adjacency? (y/n): ").strip().lower().startswith("y")

        try:
            dec_str = parse_accepted_state_to_decimal_string(raw)
        except ValueError as e:
            print(str(e) + "\n")
            continue

        report = verify_acceptance_from_decimal_string(dec_str, wrap_adjacency=wrap)
        print(f"\nAcceptance check: {report.reason}")
        if not report.ok:
            print("Not accepted.\n")
            continue

        print(f"Grid: {report.m} x {report.m} (tokens={len(report.indexes)})")

        if mode == "2":
            print()
            continue

        reversible_only = input("Reversible-only (exact classical correspondent)? (y/n): ").strip().lower().startswith("y")
        max_qubits = int(input("Max qubits (e.g. 8): ").strip() or "8")
        max_layers = int(input("Max layers (e.g. 16): ").strip() or "16")
        outdir = input("Output dir (default: out): ").strip() or "out"

        try:
            qc, cc = derive_quantum_and_classical_from_grid(
                indexes=report.indexes,
                m=report.m,
                max_qubits=max_qubits,
                max_layers=max_layers,
                reversible_only=reversible_only,
            )
        except ModuleNotFoundError:
            print(
                '\nMissing dependency. Install with:\n  pip install "qiskit[visualization]" matplotlib numpy pillow\n'
            )
            continue

        ensure_dir(outdir)
        write_gate_sequence(qc, os.path.join(outdir, "source_quantum.txt"))
        write_gate_sequence(cc, os.path.join(outdir, "source_classical.txt"))

        try:
            qpng = os.path.join(outdir, "quantum.png")
            cpng = os.path.join(outdir, "classical.png")
            apng = os.path.join(outdir, "assembly.png")
            save_circuit_png(qc, qpng)
            save_circuit_png(cc, cpng)
            try:
                combine_pngs_side_by_side(qpng, cpng, apng)
            except ModuleNotFoundError:
                pass

            print("\nWrote:")
            print(f"  {qpng}")
            print(f"  {cpng}")
            if os.path.exists(apng):
                print(f"  {apng}")
            print(f"  {os.path.join(outdir, 'source_quantum.txt')}")
            print(f"  {os.path.join(outdir, 'source_classical.txt')}\n")
        except Exception as e:
            print(f"\nRender failed: {e}\n")


# -----------------------------
# CLI wiring
# -----------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="C700h.py",
        description="C700 Host: acceptance + deterministic quantum/classical circuit derivation",
    )
    sub = p.add_subparsers(dest="cmd", required=False)

    # accept
    pa = sub.add_parser("accept", help="Run acceptance check only")
    pa.add_argument("--state", type=str, default=None, help="Accepted state as decimal or 0b... binary")
    pa.add_argument("--in", dest="infile", type=str, default=None, help="Read accepted state from a text file")
    pa.add_argument("--wrap", action="store_true", help="Enable wrap-around adjacency checks")
    pa.add_argument("--json", action="store_true", help="Emit JSON report")
    pa.add_argument("--show-indexes", action="store_true", help="Print decoded 7-digit token indexes")
    pa.add_argument("--show-hex", action="store_true", help="Print hex colors for each token")
    pa.set_defaults(func=cmd_accept)

    # derive
    pd = sub.add_parser("derive", help="Accept + derive circuits + write outputs")
    pd.add_argument("--state", type=str, default=None, help="Accepted state as decimal or 0b... binary")
    pd.add_argument("--in", dest="infile", type=str, default=None, help="Read accepted state from a text file")
    pd.add_argument("--wrap", action="store_true", help="Enable wrap-around adjacency checks")
    pd.add_argument("--reversible-only", action="store_true", help="Force reversible-only mapping (exact classical correspondent)")
    pd.add_argument("--max-qubits", type=int, default=8, help="Maximum qubits (default: 8)")
    pd.add_argument("--max-layers", type=int, default=16, help="Maximum layers (default: 16)")
    pd.add_argument("--outdir", type=str, default="out", help="Output directory (default: out)")
    pd.add_argument("--no-png", action="store_true", help="Skip PNG rendering (write text outputs only)")
    pd.set_defaults(func=cmd_derive)

    # category
    pc = sub.add_parser("category", help="Accept + derive semantic category + write outputs")
    pc.add_argument("--state", type=str, default=None, help="Accepted state as decimal or 0b... binary")
    pc.add_argument("--in", dest="infile", type=str, default=None, help="Read accepted state from a text file")
    pc.add_argument("--wrap", action="store_true", help="Enable wrap-around adjacency checks")
    pc.add_argument("--reversible-only", action="store_true", help="Match derive reversible-only semantics (x/cx only)")
    pc.add_argument("--max-qubits", type=int, default=8, help="Semantic window width q=min(m,max_qubits) (default: 8)")
    pc.add_argument("--max-layers", type=int, default=16, help="Semantic window height layers=min(m,max_layers) (default: 16)")
    pc.add_argument("--outdir", type=str, default="out", help="Output directory (default: out)")
    pc.add_argument("--no-png", action="store_true", help="Skip PNG rendering (write JSON outputs only)")
    pc.add_argument("--hide-edge-labels", action="store_true", help="Hide edge labels on category PNG")
    pc.add_argument("--show-grid-labels", action="store_true", help="Overlay numeric token labels on grid PNG")
    pc.add_argument("--assembly", action="store_true", help="Write a side-by-side assembly PNG (grid + category)")
    pc.set_defaults(func=cmd_category)


    # menu
    pm = sub.add_parser("menu", help="Interactive menu mode (fallback)")
    pm.set_defaults(func=cmd_menu)

    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    # If no subcommand provided, default to menu for convenience
    if not getattr(args, "cmd", None):
        return cmd_menu(args)

    # Require one of --state / --in for accept/derive/category
    if args.cmd in ("accept", "derive", "category") and not args.state and not args.infile:
        parser.error("accept/derive/category require --state or --in")

    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
