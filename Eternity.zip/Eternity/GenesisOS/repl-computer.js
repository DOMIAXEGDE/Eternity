// repl-computer.js — Accumulator Computer in Genesis OS (v1.4.2)
// Minimal UI + Programmer Panel (Assembler, Memory, Breakpoints)
// ISA: NOP, LDI, ADDI, SUBI, STA, LDA, DSP, HLT, PRT
// Directives: .ORG, .BYTE (numbers, labels, "strings" with escapes)

export function initialize(gosApiProxy){
  const container = gosApiProxy.window.getContainer();
  const doc = container.ownerDocument;

  // ---------- Styles ----------
  const style = doc.createElement('style');
  style.textContent = [
    ":root {",
    "  --bg-color: #1e1e2e;",
    "  --editor-bg: #282a36;",
    "  --text-color: #cdd6f4;",
    "  --muted: #6c7086;",
    "  --border-color: #313244;",
    "  --focus-color: #f5c2e7;",
    "  --scrollbar-bg: #313244;",
    "  --scrollbar-thumb: #585b70;",
    "  --err: #e74c3c;",
    "  --ok: #70d392;",
    "  --topbar-h: 36px;",
    "}",
    ".gos-root{font-family:'Fira Code','Cascadia Code','JetBrains Mono',monospace;",
    "  background:var(--bg-color); min-height:100%; display:flex; align-items:center; justify-content:center;",
    "  padding:20px; position:relative; color:var(--text-color)}",
    ".editor{width:94%; max-width:940px; height:76vh; background:var(--editor-bg);",
    "  border:2px solid var(--border-color); border-radius:8px; box-shadow:0 4px 30px rgba(0,0,0,.3);",
    "  display:grid; grid-template-rows: var(--topbar-h) 1fr; overflow:hidden;",
    "  transition:border-color .3s ease, box-shadow .3s ease; position:relative}",
    ".editor:focus-within{outline:none; border-color:var(--focus-color);",
    "  box-shadow:0 0 0 3px rgba(245,194,231,.3), 0 4px 30px rgba(0,0,0,.3);}",
    ".topbar{grid-row:1/2; display:flex; align-items:center; gap:8px; padding:6px 10px;",
    "  border-bottom:1px solid var(--border-color);",
    "  background:linear-gradient(180deg,rgba(255,255,255,.02),rgba(0,0,0,0)); z-index:3}",
    ".shell{grid-row:2/3; display:flex; overflow:hidden}",
    ".left{min-width:45px; border-right:1px solid var(--border-color); color:var(--muted);",
    "  padding:15px 10px 15px 15px; line-height:1.6; user-select:none; overflow:auto; white-space:pre}",
    ".right{flex:1; display:flex; flex-direction:column; min-width:0}",
    ".log{flex:1; padding:12px 15px; overflow:auto; line-height:1.6; white-space:pre-wrap}",
    ".input{border-top:1px solid var(--border-color); display:flex; gap:8px; padding:10px}",
    ".cmd{flex:1; background:transparent; color:var(--text-color); border:none; outline:none; font-size:16px}",
    ".cmd::placeholder{color:var(--muted)}",
    ".tag{display:inline-block; border:1px solid var(--border-color); padding:2px 6px; border-radius:999px; color:#aeb3cf; margin-right:6px}",
    ".ok{color:var(--ok)} .err{color:var(--err)} .muted{color:var(--muted)}",
    ".pillbtn{display:inline-flex; align-items:center; gap:6px; padding:4px 8px; border:1px solid var(--border-color); border-radius:999px; cursor:pointer; background:#1f2023; color:#bfc3df}",
    ".pillbtn:hover{filter:brightness(1.05)}",
    ".panel{position:absolute; right:0; top:var(--topbar-h); height:calc(100% - var(--topbar-h)); width:0; overflow:hidden;",
    "  transition:width .25s ease; border-left:1px solid var(--border-color); background:var(--editor-bg); z-index:2}",
    ".panel.open{width:min(54%,520px)}",
    ".panel-inner{display:flex; flex-direction:column; height:100%}",
    ".tabs{display:flex; gap:6px; border-bottom:1px solid var(--border-color); padding:8px}",
    ".tab{padding:6px 10px; border:1px solid var(--border-color); border-bottom:none; border-top-left-radius:8px; border-top-right-radius:8px; background:#222432; color:#cfd3f4; cursor:pointer}",
    ".tab.active{background:#1e2030}",
    ".pane{flex:1; display:none; min-height:0}",
    ".pane.active{display:flex; overflow:auto}",
    ".asm-left{flex:1; display:flex; flex-direction:column; border-right:1px solid var(--border-color); min-height:0}",
    ".asm-src{flex:1; background:transparent; color:var(--text-color); border:none; outline:none; padding:10px; resize:none; font-size:14px; line-height:1.5; min-height:0; overflow:auto}",
    ".asm-actions{display:flex; gap:8px; padding:8px; border-top:1px solid var(--border-color)}",
    ".asm-right{width:180px; padding:8px; display:flex; flex-direction:column; gap:8px}",
    ".mini-input{width:100%; background:#202233; color:#e9ecff; border:1px solid var(--border-color); border-radius:8px; padding:6px 8px; outline:none}",
    ".btn{background:#202124; color:#f1f1f1; border:1px solid var(--border-color); padding:7px 10px; border-radius:8px; cursor:pointer}",
    ".btn:hover{filter:brightness(1.06)}",
    ".mem-grid{flex:1; overflow:auto; padding:8px}",
    "table.mem{border-collapse:collapse; font-size:12px; width:100%}",
    "table.mem th, table.mem td{border:1px solid var(--border-color); padding:4px; text-align:center}",
    "table.mem th{position:sticky; top:0; background:#1e2030}",
    ".cell{background:#202233; color:#e9ecff; border:1px solid #2b2e4a; width:34px; text-align:center}",
    ".bp-list{flex:1; overflow:auto; padding:8px; font-size:13px}",
    ".flex{display:flex; gap:8px; align-items:center}",
    ".hint{position:absolute; bottom:14px; left:50%; transform:translateX(-50%); color:var(--muted); font-size:12px; opacity:.8}"
  ].join("\n");
  doc.head.appendChild(style);

  // ---------- DOM ----------
  container.innerHTML = "";
  const root = doc.createElement("div");
  root.className = "gos-root";
  root.innerHTML = [
    '<div class="editor" id="editor">',
    '  <div class="topbar">',
    '    <span class="tag" id="modeTag">MODE: manual</span>',
    '    <span class="tag" id="clockTag">CLK: stopped</span>',
    '    <span class="tag" id="hzTag">HZ: 2</span>',
    '    <span class="tag" id="phaseTag">PHASE: T0</span>',
    '    <span class="tag" id="pcTag">PC: 00</span>',
    '    <span class="tag" id="accTag">ACC: 00</span>',
    '    <span class="pillbtn" id="panelBtn">Programmer Panel</span>',
    '  </div>',
    '  <div class="shell">',
    '    <div class="left" id="lines">1</div>',
    '    <div class="right">',
    '      <div class="log" id="log"></div>',
    '      <div class="input">',
    '        <input class="cmd" id="cmd" placeholder=":help — assembler, memory inspector, breakpoints (:panel to toggle)" autocomplete="off"/>',
    '      </div>',
    '    </div>',
    '    <div class="panel" id="panel">',
    '      <div class="panel-inner">',
    '        <div class="tabs">',
    '          <div class="tab active" data-pane="asm">Assembler</div>',
    '          <div class="tab" data-pane="mem">Memory</div>',
    '          <div class="tab" data-pane="bp">Breakpoints</div>',
    '        </div>',
    '        <div class="pane active" id="pane-asm">',
    '          <div class="asm-left">',
    '            <textarea id="asmSrc" class="asm-src" spellcheck="false" placeholder="; Example\nstart:\n  LDI #0x2A\n  DSP\n  HLT"></textarea>',
    '            <div class="asm-actions">',
    '              <button class="btn" id="assembleBtn">Assemble -> MEM</button>',
    '              <button class="btn" id="runDemoBtn">Load Demo</button>',
    '            </div>',
    '          </div>',
    '          <div class="asm-right">',
    '            <label>Origin (.org)</label>',
    '            <input id="asmOrg" class="mini-input" value="0x00"/>',
    '            <label>PC after assemble</label>',
    '            <input id="asmPC" class="mini-input" value="0x00"/>',
    '            <div class="muted" style="font-size:12px">Supported: NOP, LDI #imm, ADDI #imm, SUBI #imm, STA addr, LDA addr, DSP, HLT, .BYTE list (numbers/labels/strings). Labels allowed.</div>',
    '          </div>',
    '        </div>',
    '        <div class="pane" id="pane-mem">',
    '          <div class="mem-grid" id="memGrid"></div>',
    '        </div>',
    '        <div class="pane" id="pane-bp">',
    '          <div class="flex" style="padding:8px">',
    '            <input id="bpAddr" class="mini-input" placeholder="0x00"/>',
    '            <button class="btn" id="bpAdd">Add</button>',
    '            <button class="btn" id="bpClear">Clear All</button>',
    '          </div>',
    '          <div class="bp-list" id="bpList"></div>',
    '        </div>',
    '      </div>',
    '    </div>',
    '  </div>',
    '</div>',
    '<div class="hint">Type <code>:help</code> for documentation</div>'
  ].join("\n");
  container.appendChild(root);

  // ---------- Helpers ----------
  const $ = s => root.querySelector(s);
  const logEl = $("#log"), linesEl = $("#lines"), input = $("#cmd"), panel = $("#panel");
  $("#panelBtn").addEventListener("click", ()=> panel.classList.toggle("open"));
  root.addEventListener("click", (e)=>{
    if(e.target.classList.contains("tab")){
      root.querySelectorAll(".tab").forEach(t=>t.classList.remove("active"));
      e.target.classList.add("active");
      root.querySelectorAll(".pane").forEach(p=>p.classList.remove("active"));
      $("#pane-"+e.target.dataset.pane).classList.add("active");
    }
  });
  // Optional keyboard toggle (Ctrl/Cmd+P)
  root.addEventListener("keydown", (e)=>{
    if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==="p"){ e.preventDefault(); panel.classList.toggle("open"); }
  });

  let lineCount = 1;
  const print = (msg, cls="") => {
    const div = doc.createElement("div");
    if(cls) div.className = cls;
    div.textContent = msg;
    logEl.appendChild(div);
    logEl.scrollTop = logEl.scrollHeight;
    lineCount += String(msg).split("\n").length;
    linesEl.textContent = Array.from({length:lineCount}, (_,i)=>i+1).join("\n");
  };
  const setTag = (id, text) => { const el = $("#"+id); if(el) el.textContent = text; };

  // ---------- CPU/BUS Model ----------
  const clamp8 = x => ((x % 256) + 256) % 256;
  const toHex2 = x => x.toString(16).toUpperCase().padStart(2,"0");
  function Latch(name){ this.name=name; this.q=0; this.next=0; this.enable=true;
    this.latch=(d)=>{ if(this.enable){ this.next = clamp8(d); } };
    this.clock=()=>{ this.q = this.next; }; }
  function add8_ripple(a,b){ let c=0,o=0; for(let i=0;i<8;i++){ const A=(a>>i)&1,B=(b>>i)&1; const s=A^B^c; const m=(A&B)|(A&c)|(B&c); o|=(s<<i); c=m&1; } return o&0xFF; }
  function sub8_ripple(a,b){ return add8_ripple(a, add8_ripple((~b)&0xFF, 1)); }

  const ACC = new Latch("ACC");
  const IR  = new Latch("IR");
  const DR  = new Latch("DR");
  const PC  = new Latch("PC");
  const CTRL = { developer:false };

  const MEM = new Uint8Array(256);
  const loadMem = (bytes, at=0)=>{ for(let i=0;i<bytes.length;i++) MEM[(at+i)&0xFF]=bytes[i]&0xFF; renderMem(); };

  const PHASES = ["T0","T1","T2","T3","T4"];
  let phase = 0;
  let auto = false;
  let hz = 2;
  let timer = null;
  const breakpoints = new Set();

  // PRT microcode state
  let prtActive = false;
  let prtPtr = 0;

  const updateTop = () => {
    setTag("modeTag", "MODE: " + (auto? "auto":"manual"));
    setTag("clockTag", "CLK: " + (timer? "running":"stopped"));
    setTag("hzTag", "HZ: " + hz);
    setTag("phaseTag", "PHASE: " + PHASES[phase]);
    setTag("pcTag", "PC: " + toHex2(PC.q));
    setTag("accTag", "ACC: " + toHex2(ACC.q));
  };

  function decoder4AND(op, en){
    const lines = new Array(16).fill(0);
    if(!en) return lines;
    const b0=(op>>0)&1, b1=(op>>1)&1, b2=(op>>2)&1, b3=(op>>3)&1;
    for(let i=0;i<16;i++){
      const i0=(i>>0)&1,i1=(i>>1)&1,i2=(i>>2)&1,i3=(i>>3)&1;
      lines[i]=(b0===i0 && b1===i1 && b2===i2 && b3===i3)?1:0;
    }
    return lines;
  }

  const OPC = { NOP:0x0, LDI:0x1, ADDI:0x2, SUBI:0x3, STA:0x4, LDA:0x5, DSP:0x6, HLT:0x7, PRT:0x8 };

  function stepMicro(){
    // PRT loop
    if(prtActive){
      switch(phase){
        case 0: DR.latch(MEM[prtPtr]); DR.clock(); break;
        case 1:
          if(DR.q===0){ prtActive=false; print("PRT done","muted"); }
          else { const ch = String.fromCharCode(DR.q); print("PRT: '" + ch + "' (0x" + DR.q.toString(16).toUpperCase().padStart(2,"0") + ")"); }
          break;
        case 2: if(DR.q!==0){ prtPtr = (prtPtr + 1) & 0xFF; } break;
        case 3: case 4: break;
      }
      phase = (phase+1)%5; updateTop(); return;
    }

    const op = IR.q & 0x0F;
    const onehot = decoder4AND(op, true);
    switch(phase){
      case 0: // fetch
        DR.latch(MEM[PC.q]); DR.clock();
        PC.latch(PC.q+1); PC.clock();
        IR.latch(DR.q); IR.clock();
        break;
      case 1: // operand fetch / PRT init
        if(onehot[OPC.LDI]||onehot[OPC.ADDI]||onehot[OPC.SUBI]||onehot[OPC.LDA]||onehot[OPC.STA]){
          DR.latch(MEM[PC.q]); DR.clock(); PC.latch(PC.q+1); PC.clock();
        }
        if(onehot[OPC.PRT]){ prtActive = true; prtPtr = ACC.q; }
        break;
      case 2:
        if(onehot[OPC.LDI]){ ACC.latch(DR.q); ACC.clock(); }
        if(onehot[OPC.LDA]){ ACC.latch(MEM[DR.q]); ACC.clock(); }
        break;
      case 3:
        if(onehot[OPC.ADDI]){ ACC.latch(add8_ripple(ACC.q, DR.q)); ACC.clock(); }
        if(onehot[OPC.SUBI]){ ACC.latch(sub8_ripple(ACC.q, DR.q)); ACC.clock(); }
        if(onehot[OPC.STA]){ MEM[DR.q] = ACC.q; renderMemCell(DR.q); }
        break;
      case 4:
        if(onehot[OPC.DSP]){ print("DISPLAY: " + toHex2(ACC.q) + " (" + ACC.q + ")", "ok"); }
        if(onehot[OPC.HLT]){ stopClock(); print("HALT","muted"); }
        break;
    }
    phase = (phase+1)%5;
    updateTop();
    if(phase===0 && breakpoints.has(PC.q)){ stopClock(); print("BREAK @ " + toHex2(PC.q), "err"); }
  }

  function tick(){ stepMicro(); }
  function startClock(){ if(timer) return; timer = setInterval(tick, Math.max(5, 1000/Math.max(1,hz))); updateTop(); }
  function stopClock(){ if(timer){ clearInterval(timer); timer=null; } updateTop(); }
  function setHz(v){ hz = Math.max(1, Math.min(1000, v|0)); if(timer){ stopClock(); startClock(); } updateTop(); }

  // ---------- Programmer Panel: Memory & Breakpoints ----------
  function renderMem(){
    const host = $("#memGrid"); if(!host) return;
    const table = doc.createElement("table"); table.className="mem";
    const thead = doc.createElement("thead");
    const hr = doc.createElement("tr");
    hr.appendChild(th(""));
    for(let x=0;x<16;x++) hr.appendChild(th(x.toString(16).toUpperCase()));
    thead.appendChild(hr); table.appendChild(thead);
    const tbody = doc.createElement("tbody");
    for(let r=0;r<16;r++){
      const tr = doc.createElement("tr");
      tr.appendChild(th((r*16).toString(16).toUpperCase().padStart(2,"0")));
      for(let c=0;c<16;c++){
        const addr = r*16+c;
        const td = doc.createElement("td");
        const inp = doc.createElement("input"); inp.className="cell"; inp.value = toHex2(MEM[addr]);
        inp.maxLength = 2;
        inp.addEventListener("change", ()=>{
          const v = parseInt(inp.value,16);
          if(isNaN(v)){ inp.value = toHex2(MEM[addr]); return; }
          MEM[addr]=v&0xFF; inp.value = toHex2(MEM[addr]);
        });
        td.appendChild(inp); tr.appendChild(td);
      }
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    host.innerHTML = ""; host.appendChild(table);
  }
  function renderMemCell(addr){
    const host = $("#memGrid"); if(!host) return;
    const inp = host.querySelectorAll("input.cell")[addr];
    if(inp) inp.value = toHex2(MEM[addr]);
  }
  function th(t){ const e=doc.createElement("th"); e.textContent=t; return e; }

  function renderBreakpoints(){
    const list = $("#bpList"); list.innerHTML = "";
    if(breakpoints.size===0){ const d=doc.createElement("div"); d.className="muted"; d.textContent="(no breakpoints)"; list.appendChild(d); return; }
    [...breakpoints].sort((a,b)=>a-b).forEach(addr=>{
      const row = doc.createElement("div"); row.className="flex";
      const tag = doc.createElement("span"); tag.className="tag"; tag.textContent="@"+toHex2(addr);
      const del = doc.createElement("button"); del.className="btn"; del.textContent="Remove";
      del.onclick = ()=>{ breakpoints.delete(addr); renderBreakpoints(); };
      row.append(tag, del); list.appendChild(row);
    });
  }

  $("#bpAdd").addEventListener("click", ()=>{
    const v = $("#bpAddr").value.trim();
    const val = /^0x/i.test(v) ? parseInt(v,16) : parseInt(v,16);
    if(isNaN(val)){ print("invalid breakpoint addr","err"); return; }
    breakpoints.add(val & 0xFF); renderBreakpoints();
  });
  $("#bpClear").addEventListener("click", ()=>{ breakpoints.clear(); renderBreakpoints(); });

  // ---------- Assembler ----------
  const ASM = {
    assemble(src, origin){
      // Two-pass with labels + .BYTE (numbers, labels, strings with escapes)
      const lines = src.split(/\r?\n/);
      const rows = lines.map((ln,i)=>({i, raw:ln, t: ln.replace(/;.*$/,"").trim()})).filter(x=>x.t.length>0);
      const labels = new Map();
      let pc = origin|0;

      const isOrg = (t) => /^\.org\b/i.test(t);
      const isByte = (t) => /^\.byte\b/i.test(t);

      const parseByteList = (arg, labels) => {
        const tokens = [];
        let i=0, inQ=false, qch='"', esc=false, cur="";
        while(i<arg.length){
          const ch = arg[i++];
          if(inQ){
            if(esc){ cur += ch; esc=false; continue; }
            if(ch==='\\'){ esc=true; continue; }
            if(ch===qch){ tokens.push({type:"str", s:cur}); cur=""; inQ=false; continue; }
            cur += ch;
          } else {
            if(ch=='"' || ch=="'"){ inQ=true; qch=ch; continue; }
            if(ch===',' || /\s/.test(ch)){
              if(cur.trim().length){ tokens.push({type:"num", s:cur.trim()}); cur=""; }
              continue;
            }
            cur += ch;
          }
        }
        if(cur.trim().length){ tokens.push({type:"num", s:cur.trim()}); }

        const unescape = (s) => {
          const out = [];
          for(let i=0;i<s.length;i++){
            let ch = s[i];
            if(ch==='\\' && i+1<s.length){
              const n = s[++i];
              if(n==='n'){ out.push(0x0A); continue; }
              if(n==='r'){ out.push(0x0D); continue; }
              if(n==='t'){ out.push(0x09); continue; }
              if(n==='0'){ out.push(0x00); continue; }
              if(n==='\\'){ out.push(0x5C); continue; }
              if(n==='"'){ out.push(0x22); continue; }
              if(n=="'"){ out.push(0x27); continue; }
              if(n==='x' && i+2<s.length){
                const hh = s.substring(i+1, i+3);
                const v = parseInt(hh,16);
                if(!isNaN(v)){ out.push(v&0xFF); i+=2; continue; }
              }
              out.push(n.charCodeAt(0));
              continue;
            }
            out.push(ch.charCodeAt(0));
          }
          return out;
        };

        const toByte = (s)=>{
          if(s==null || s==="") return 0;
          if(/^#/.test(s)) s = s.replace(/^#/,"");
          if(/^0x/i.test(s)) return (parseInt(s,16)&0xFF);
          if(/^[0-9]+$/.test(s)) return (parseInt(s,10)&0xFF);
          if(labels.has(s)) return (labels.get(s)&0xFF);
          throw new Error("Unknown number/label: "+s);
        };

        const out = [];
        tokens.forEach(t=>{
          if(t.type==="str"){ unescape(t.s).forEach(b=> out.push(b&0xFF)); }
          else { out.push(toByte(t.s)); }
        });
        return out;
      };

      // Pass 1
      rows.forEach(x=>{
        const m = x.t.match(/^([A-Za-z_]\w*):\s*(.*)$/);
        if(m){ labels.set(m[1], pc & 0xFF); x.t = m[2].trim(); }
        if(!x.t) return;

        if(isOrg(x.t)){
          const arg = x.t.replace(/^\.org\b/i,"").trim();
          pc = parseInt(arg.replace(/^0x/i,""), 16) & 0xFF;
          return;
        }
        if(isByte(x.t)){
          const arg = x.t.replace(/^\.byte\b/i,"").trim();
          try { const bytes = parseByteList(arg, labels); pc = (pc + bytes.length) & 0xFF; } catch(e){}
          return;
        }

        const opcode = x.t.split(/\s+/)[0].toUpperCase();
        if(["LDI","ADDI","SUBI","STA","LDA"].includes(opcode)) pc = (pc + 2) & 0xFF;
        else if(["NOP","DSP","HLT","PRT"].includes(opcode)) pc = (pc + 1) & 0xFF;
        else if(opcode) throw new Error("Unknown opcode/directive on pass1: "+opcode);
      });

      // Pass 2
      pc = origin|0;
      const out = [];
      const toByte = (s)=>{
        if(s==null || s==="") return 0;
        if(/^#/.test(s)) s = s.replace(/^#/,"");
        if(/^0x/i.test(s)) return (parseInt(s,16)&0xFF);
        if(/^[0-9]+$/.test(s)) return (parseInt(s,10)&0xFF);
        if(labels.has(s)) return (labels.get(s)&0xFF);
        throw new Error("Unknown number/label: "+s);
      };

      rows.forEach(x=>{
        if(!x.t) return;

        if(isOrg(x.t)){
          const arg = x.t.replace(/^\.org\b/i,"").trim();
          pc = parseInt(arg.replace(/^0x/i,""), 16) & 0xFF;
          return;
        }
        if(isByte(x.t)){
          const arg = x.t.replace(/^\.byte\b/i,"").trim();
          const bytes = parseByteList(arg, labels);
          bytes.forEach(b=> out.push(b&0xFF));
          pc = (pc + bytes.length) & 0xFF;
          return;
        }

        const parts = x.t.split(/\s+/);
        const op = parts[0].toUpperCase();
        const arg = parts.slice(1).join(" ").trim();

        switch(op){
          case "NOP": out.push(0x00); pc=(pc+1)&0xFF; break;
          case "LDI": out.push(0x01, toByte(arg)); pc=(pc+2)&0xFF; break;
          case "ADDI": out.push(0x02, toByte(arg)); pc=(pc+2)&0xFF; break;
          case "SUBI": out.push(0x03, toByte(arg)); pc=(pc+2)&0xFF; break;
          case "STA": out.push(0x04, toByte(arg)); pc=(pc+2)&0xFF; break;
          case "LDA": out.push(0x05, toByte(arg)); pc=(pc+2)&0xFF; break;
          case "DSP": out.push(0x06); pc=(pc+1)&0xFF; break;
          case "HLT": out.push(0x07); pc=(pc+1)&0xFF; break;
          case "PRT": out.push(0x08); pc=(pc+1)&0xFF; break;
          default: throw new Error("Unknown opcode on pass2: "+op);
        }
      });
      return out;
    }
  };

  // ---------- REPL ----------
  const help = [
    "OVERVIEW",
    "  Accumulator CPU with 5-phase microcycle (T0..T4), 4-AND decoder (4-bit), 8-pin bus model, latches, ripple adder.",
    "  Manual clock (:tick) and automatic clock (:clock start / :clock stop / :hz N).",
    "  Admin control (:admin on|off) gates privileged ops.",
    "  Programmer Panel: :panel to toggle — Assembler, Memory Inspector, Breakpoints.",
    "",
    "INSTRUCTIONS",
    "  NOP(00)  LDI(01) imm8  ADDI(02) imm8  SUBI(03) imm8  STA(04) addr8  LDA(05) addr8  DSP(06)  HLT(07)  PRT(08)",
    "  PRT: print zero-terminated string starting at ACC via a microcoded loop",
    "",
    "DIRECTIVES",
    "  .BYTE <items...>   # hex (0x..), decimal, label, or \\\"string\\\" with escapes; emits bytes at current PC",
    "  .ORG <addr>        # set assembly origin",
    "",
    "REPL COMMANDS",
    "  :help",
    "  :panel                      Toggle programmer panel",
    "  :admin on|off               Toggle developer control unit",
    "  :mode manual|auto           Set manual or automatic clock mode",
    "  :clock start|stop           Start/stop the clock (auto mode)",
    "  :hz <n>                     Set auto clock frequency (1..1000 Hz)",
    "  :tick                       Single clock tick",
    "  :stepi                      Run to next instruction boundary (phase T0)",
    "  :state                      Dump CPU state",
    "  :mem set <addr> <val>       Set MEM[addr]=val (hex)",
    "  :load <hex bytes>           Load program at 0x00 (space/comma separated)",
    "  :pc <hex>                   Set program counter",
    "  :run <n>                    Tick n cycles (manual mode)",
    "  :acc set <n>                Directly set ACC (admin only, decimal)",
    "  :break add <addr>           Add breakpoint (hex)",
    "  :break del <addr>           Remove breakpoint",
    "  :break list                 List breakpoints",
    "  :reset                      Reset registers and phase (memory preserved)"
  ].join("\n");

  function parseHexBytes(s){ return s.replace(/[,]/g," ").trim().split(/\s+/).filter(Boolean).map(x=>parseInt(x,16)&0xFF); }
  function dumpState(){ print("PC="+toHex2(PC.q)+" ACC="+toHex2(ACC.q)+" IR="+toHex2(IR.q)+" DR="+toHex2(DR.q)+" PHASE="+PHASES[phase]); }
  function requireAdmin(){ if(!CTRL.developer){ print("admin-developer required. Use :admin on","err"); return false; } return true; }

  function stepi(){ const startPhase = phase; do { stepMicro(); } while(phase !== 0); print("stepi","muted"); }

  function runCmd(line){
    const raw = line.trim(); if(!raw) return;
    if(raw[0] !== ":"){ print("(data) "+raw,"muted"); return; }
    const [cmd, ...rest] = raw.split(/\s+/);
    const args = rest.join(" ");

    switch(cmd){
      case ":help": print(help); break;
      case ":panel": panel.classList.toggle("open"); break;
      case ":admin": CTRL.developer = /^on$/i.test(rest[0]||""); print("developer="+(CTRL.developer?"on":"off"),"ok"); break;
      case ":mode": if(/^auto$/i.test(rest[0]||"")){ auto=true; startClock(); } else { auto=false; stopClock(); } updateTop(); print("mode="+(auto?"auto":"manual"),"ok"); break;
      case ":clock": if(/^start$/i.test(rest[0]||"")){ auto=true; startClock(); print("clock started","ok"); } else { stopClock(); auto=false; print("clock stopped","muted"); } break;
      case ":hz": setHz(parseInt(rest[0]||"2",10)||2); print("hz="+hz,"ok"); break;
      case ":tick": if(auto){ print("stop auto clock first (:clock stop)","err"); break; } tick(); print("tick","muted"); break;
      case ":stepi": if(auto){ print("stop auto clock first (:clock stop)","err"); break; } stepi(); break;
      case ":state": dumpState(); break;
      case ":mem":
        if(rest[0]==="set"){ const addr=parseInt(rest[1],16)&0xFF; const val=parseInt(rest[2],16)&0xFF; MEM[addr]=val; renderMemCell(addr); print("MEM["+toHex2(addr)+"]="+toHex2(val),"ok"); }
        else print("usage: :mem set <addrHEX> <valHEX>","muted"); break;
      case ":load": {
        const bytes = parseHexBytes(args);
        for(let i=0;i<256;i++) MEM[i]=0;
        for(let i=0;i<bytes.length;i++) MEM[i]=bytes[i];
        renderMem();
        PC.q=0; IR.q=0; DR.q=0; ACC.q=0; phase=0;
        print("program loaded ("+bytes.length+" bytes) at 00","ok"); dumpState();
      } break;
      case ":pc": PC.q = parseInt(rest[0]||"0",16)&0xFF; updateTop(); dumpState(); break;
      case ":run": {
        const n = Math.max(0, parseInt(rest[0]||"0",10)|0); if(auto){ print("stop auto clock first (:clock stop)","err"); break; }
        for(let i=0;i<n;i++) tick(); print("ran "+n+" ticks","muted");
      } break;
      case ":acc":
        if(rest[0]==="set"){ if(!requireAdmin()) break; ACC.q = clamp8(parseInt(rest[1]||"0",10)|0); updateTop(); print("ACC="+toHex2(ACC.q),"ok"); }
        else print("usage: :acc set <decimal>  (admin)","muted"); break;
      case ":break":
        if(rest[0]==="add"){ const a=parseInt(rest[1],16)&0xFF; breakpoints.add(a); renderBreakpoints(); print("break @ "+toHex2(a),"ok"); }
        else if(rest[0]==="del"){ const a=parseInt(rest[1],16)&0xFF; breakpoints.delete(a); renderBreakpoints(); print("break removed @ "+toHex2(a),"ok"); }
        else if(rest[0]==="list"){ print("breakpoints: "+([...breakpoints].map(x=>toHex2(x)).join(", ")||"(none)")); }
        else print("usage: :break add|del|list <addrHEX?>","muted");
        break;
      case ":reset":
        PC.q=0; IR.q=0; DR.q=0; ACC.q=0; phase=0; updateTop(); print("reset","muted"); break;
      default: print("unknown command: "+cmd+". Type :help","err");
    }
  }

  // ---------- Boot demo ----------
  (function boot(){
    const demo = [0x01, 0x2A, 0x06, 0x07]; // LDI 2A; DSP; HLT
    for(let i=0;i<demo.length;i++) MEM[i]=demo[i];
    PC.q=0; ACC.q=0; IR.q=0; DR.q=0; phase=0;
  })();
  print("REPL Computer ready. Type :help");
  print("Tip: PRT (0x08) prints a zero-terminated string from ACC");
  dumpState(); updateTop(); renderMem(); renderBreakpoints();

  // ---------- Input ----------
  input.addEventListener("keydown", (e)=>{
    if(e.key==="Enter"){
      e.preventDefault();
      const v = input.value; input.value="";
      print("> "+v,"muted"); runCmd(v);
    }
  });
}
