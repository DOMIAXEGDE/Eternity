<?php
require_once 'auth.php';
require_once 'VersionManager.php';

// Authenticate every API request
if (!isLoggedIn()) {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['success' => false, 'message' => 'Authentication required.']);
    exit;
}

// All responses are JSON
header('Content-Type: application/json');

// Get POST data
$action = $_POST['action'] ?? '';
$params = isset($_POST['params']) ? json_decode($_POST['params'], true) : [];

$response = ['success' => false, 'message' => 'Invalid action'];

try {
    // Define paths
    // Assumes the workbench is adjacent to the live platform directory
    $live_tr_path = realpath(__DIR__ . '/../tr');
    $versions_dir = __DIR__ . '/versions';

    if (!$live_tr_path) {
        throw new Exception('FATAL: Live BEP directory "berto-tools-platform" not found adjacent to the workbench.');
    }
    
    // ✅ FIXED: Moved manager instantiation inside the try block.
    // This ensures that if the constructor fails, the error is caught 
    // and formatted as a proper JSON response.
    $manager = new VersionManager($live_tr_path, $versions_dir);

    switch ($action) {
        case 'listVersions':
            $response = ['success' => true, 'data' => $manager->listVersions()];
            break;
        
        case 'createVersion':
            $versionName = $manager->createVersion();
            $response = ['success' => true, 'message' => "Version '$versionName' created successfully."];
            break;

        case 'listVersionFiles':
            $version = $params['version'] ?? null;
            $response = ['success' => true, 'data' => $manager->listVersionFiles($version)];
            break;
            
        case 'readFile':
            $version = $params['version'] ?? null;
            $file = $params['file'] ?? null;
            $response = ['success' => true, 'data' => $manager->readFile($version, $file)];
            break;

        case 'writeFile':
            $version = $params['version'] ?? null;
            $file = $params['file'] ?? null;
            $content = $params['content'] ?? '';
            $manager->writeFile($version, $file, $content);
            $response = ['success' => true, 'message' => 'File saved successfully.'];
            break;
            
        case 'runTests':
            $version = $params['version'] ?? null;
            $response = ['success' => true, 'data' => $manager->runTests($version)];
            break;

        case 'deployVersion':
            $version = $params['version'] ?? null;
            $manager->deployVersion($version);
            $response = ['success' => true, 'message' => "Version '$version' has been deployed to the live environment."];
            break;

        case 'deleteVersion':
            $version = $params['version'] ?? null;
            $manager->deleteVersion($version);
            $response = ['success' => true, 'message' => "Version '$version' has been deleted."];
            break;
    }
} catch (Exception $e) {
    // Now, any error (including from the constructor) will be caught here.
    $response = ['success' => false, 'message' => $e->getMessage()];
}

echo json_encode($response);