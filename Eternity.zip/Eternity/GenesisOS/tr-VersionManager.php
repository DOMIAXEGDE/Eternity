<?php
class VersionManager {
    private string $livePath;
    private string $versionsPath;
    
    public function __construct(string $livePath, string $versionsPath) {
        if (!is_dir($livePath)) throw new Exception("Live BEP path does not exist: $livePath");
        if (!is_writable($versionsPath)) throw new Exception("Versions directory is not writable: $versionsPath");
        
        $this->livePath = rtrim($livePath, '/');
        $this->versionsPath = rtrim($versionsPath, '/');
    }
    
    private function getVersionPath(string $version): string {
        if (empty($version) || str_contains($version, '..') || str_contains($version, '/')) {
            throw new Exception("Invalid version name provided.");
        }
        $path = $this->versionsPath . '/' . $version;
        if (!is_dir($path)) {
            throw new Exception("Version '$version' not found.");
        }
        return $path;
    }
    
    public function listVersions(): array {
        $dirs = array_filter(scandir($this->versionsPath), fn($d) => $d[0] !== '.' && is_dir($this->versionsPath . '/' . $d));
        rsort($dirs); // Show newest first
        return array_values($dirs);
    }
    
    // ✅ FIXED: Changed 'string' to '?string' to explicitly declare the parameter as nullable.
    public function createVersion(?string $name = null): string {
        $versionName = $name ?: date('Ymd_His');
        $targetPath = $this->versionsPath . '/' . $versionName;
        if (is_dir($targetPath)) throw new Exception("Version '$versionName' already exists.");
        
        $this->recursiveCopy($this->livePath, $targetPath);
        return $versionName;
    }

    public function listVersionFiles(string $version): array {
        $versionPath = $this->getVersionPath($version);
        $files = [];
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($versionPath, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $item) {
            $files[] = [
                'path' => $iterator->getSubPathName(),
                'type' => $item->isDir() ? 'dir' : 'file'
            ];
        }
        return $files;
    }
    
    public function readFile(string $version, string $filePath): string {
        $versionPath = $this->getVersionPath($version);
        $fullPath = $versionPath . '/' . $filePath;

        if (str_contains($filePath, '..') || !file_exists($fullPath) || is_dir($fullPath)) {
            throw new Exception("File not found or invalid path.");
        }
        return file_get_contents($fullPath);
    }
    
    public function writeFile(string $version, string $filePath, string $content): void {
        $versionPath = $this->getVersionPath($version);
        $fullPath = $versionPath . '/' . $filePath;

        if (str_contains($filePath, '..')) {
            throw new Exception("Invalid file path.");
        }
        
        $dir = dirname($fullPath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        
        if (file_put_contents($fullPath, $content) === false) {
            throw new Exception("Failed to write to file.");
        }
    }
    
    public function runTests(string $version): array {
        $versionPath = $this->getVersionPath($version);
        $results = [];

        // Test 1: Check for PHP syntax errors in all .php files
        $php_files_ok = true;
        $syntax_errors = [];
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($versionPath));
        foreach ($iterator as $file) {
            if ($file->getExtension() === 'php') {
                $output = [];
                exec('php -l ' . escapeshellarg($file->getPathname()), $output, $return_var);
                if ($return_var !== 0) {
                    $php_files_ok = false;
                    $syntax_errors[] = implode("\n", $output);
                }
            }
        }
        $results['PHP Syntax Check'] = ['passed' => $php_files_ok, 'details' => $php_files_ok ? 'All files OK.' : implode("\n", $syntax_errors)];

        // Test 2: Essential file existence
        $essential_files = ['index.php', 'config.php', 'bootstrap.php', 'modules/auth.php', 'gos_files/system'];
        $missing_files = [];
        foreach ($essential_files as $file) {
            if (!file_exists($versionPath . '/' . $file)) {
                $missing_files[] = $file;
            }
        }
        $results['Essential Files Check'] = ['passed' => empty($missing_files), 'details' => empty($missing_files) ? 'All present.' : 'Missing: ' . implode(', ', $missing_files)];

        return $results;
    }
    
    public function deployVersion(string $version): void {
        $sourcePath = $this->getVersionPath($version);
        
        // 1. Create a backup before deploying
        $this->createVersion('backup_before_deploy_' . $version . '_' . date('His'));
        
        // 2. Delete current live files
        $this->recursiveDelete($this->livePath);
        
        // 3. Copy new version to live
        $this->recursiveCopy($sourcePath, $this->livePath);
    }
    
    public function deleteVersion(string $version): void {
        $path = $this->getVersionPath($version);
        $this->recursiveDelete($path, true);
    }
    
    public function downloadVersion(string $version): void {
        $versionPath = $this->getVersionPath($version);
        
        $zipFile = sys_get_temp_dir() . '/' . $version . '.zip';
        if (file_exists($zipFile)) {
            unlink($zipFile);
        }

        $zip = new ZipArchive();
        $zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE);
        
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($versionPath),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($files as $name => $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($versionPath) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
        
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $version . '.zip"');
        header('Content-Length: ' . filesize($zipFile));
        readfile($zipFile);
        unlink($zipFile);
        exit;
    }

    private function recursiveCopy(string $source, string $dest): void {
        if (!is_dir($dest)) mkdir($dest, 0755, true);
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $item) {
            $destPath = $dest . '/' . $iterator->getSubPathName();
            if ($item->isDir()) {
                if (!is_dir($destPath)) mkdir($destPath);
            } else {
                copy($item, $destPath);
            }
        }
    }

    private function recursiveDelete(string $dir, bool $deleteSelf = false): void {
        if (!is_dir($dir)) return;
        
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($files as $fileinfo) {
            $todo = ($fileinfo->isDir() ? 'rmdir' : 'unlink');
            $todo($fileinfo->getRealPath());
        }
        
        if ($deleteSelf) {
            rmdir($dir);
        }
    }
}

// Special handler for download requests, which are not AJAX calls.
if (isset($_GET['action']) && $_GET['action'] === 'download' && isset($_GET['version'])) {
    require_once 'auth.php';
    if (isLoggedIn()) {
        $live_tr_path = realpath(__DIR__ . '/../tr');
        $versions_dir = __DIR__ . '/versions';
        $manager = new VersionManager($live_tr_path, $versions_dir);
        $manager->downloadVersion($_GET['version']);
    }
}