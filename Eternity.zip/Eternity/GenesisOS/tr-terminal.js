// tr-terminal.js — TR Terminal for Genesis OS (v1.0.0)
// Minimal centered REPL + admin-developer package system (patches/extensions).
// - Installs/Enables/Disables/Uninstalls .js packages
// - Manages tr-terminal-config.json (next to the app), also mirrors in localStorage
// - Discovers packaged assets via ?api=apps&method=getAppAsset&appId=tr-terminal&file=...
//
// Package format (ESM or classic IIFE both supported):
//   ESM:     export function register(tr) { tr.registerCommand('hello', (argv, api)=>api.print('hi')); }
//   Classic: window.trTerminalPackage = { register(tr){ /* ... */ } }
//
// Provided API to packages:
//   tr.registerCommand(name, fn)
//   tr.unregisterCommand(name)
//   tr.api.print(msg, cls?)     // cls: "ok","err","muted"
//   tr.api.getState()           // { admin, version, config }
//   tr.api.getConfig() / setConfig(cb) / saveConfig()
//   tr.api.fetchSelf(file)      // fetch packaged asset
//   tr.api.addAlias(alias, targetCommandLine)
//
// Admin-only mutating ops are gated by admin mode.
//
// ---------------------------------------------------------------------------

export function initialize(gosApiProxy) {
  const appId = "tr-terminal";
  const PKG_DIR = "extend/";
  const CONFIG_FILE = PKG_DIR + "tr-terminal-config.json";

  function normalizePkgPath(file) {
    if (!file) return "";
    const clean = String(file).replace(/^\/+/, "").replace(/^extend\//, "");
    return PKG_DIR + clean;
  }

  const container = gosApiProxy.window.getContainer();
  const doc = container.ownerDocument;

  // ---------- Styles (single centered rectangle, topbar inside) ----------
  const style = doc.createElement("style");
  style.textContent = [
    ":root{",
    "  --bg:#1e1e2e; --panel:#282a36; --text:#cdd6f4; --muted:#6c7086;",
    "  --border:#313244; --focus:#f5c2e7; --ok:#70d392; --err:#e74c3c;",
    "  --topbar-h:36px;",
    "}",
    ".root{font-family:'Fira Code','Cascadia Code','JetBrains Mono',monospace; background:var(--bg);",
    "  min-height:100%; display:flex; align-items:center; justify-content:center; color:var(--text); padding:20px}",
    ".editor{width:94%; max-width:940px; height:76vh; background:var(--panel);",
    "  border:2px solid var(--border); border-radius:8px; box-shadow:0 4px 30px rgba(0,0,0,.3);",
    "  display:grid; grid-template-rows:var(--topbar-h) 1fr; overflow:hidden; position:relative}",
    ".editor:focus-within{border-color:var(--focus); box-shadow:0 0 0 3px rgba(245,194,231,.3), 0 4px 30px rgba(0,0,0,.3)}",
    ".topbar{grid-row:1/2; display:flex; align-items:center; gap:8px; padding:6px 10px; border-bottom:1px solid var(--border)}",
    ".tag{display:inline-block; border:1px solid var(--border); padding:2px 6px; border-radius:999px; color:#aeb3cf; margin-right:6px}",
    ".pill{display:inline-flex; align-items:center; gap:6px; padding:4px 8px; border:1px solid var(--border); border-radius:999px; background:#1f2023; color:#bfc3df; cursor:pointer}",
    ".shell{grid-row:2/3; display:flex; overflow:hidden}",
    ".left{min-width:45px; border-right:1px solid var(--border); color:var(--muted);",
    "  padding:15px 10px 15px 15px; line-height:1.6; user-select:none; overflow:auto; white-space:pre}",
    ".right{flex:1; display:flex; flex-direction:column; min-width:0}",
    ".log{flex:1; padding:12px 15px; overflow:auto; line-height:1.6; white-space:pre-wrap}",
    ".input{border-top:1px solid var(--border); display:flex; gap:8px; padding:10px}",
    ".cmd{flex:1; background:transparent; color:var(--text); border:none; outline:none; font-size:16px}",
    ".cmd::placeholder{color:var(--muted)}",
    ".ok{color:var(--ok)} .err{color:var(--err)} .muted{color:var(--muted)}",
    ".panel{position:absolute; right:0; top:var(--topbar-h); height:calc(100% - var(--topbar-h)); width:0; overflow:hidden;",
    "  transition:width .25s ease; border-left:1px solid var(--border); background:var(--panel); z-index:2}",
    ".panel.open{width:min(54%,520px)}",
    ".panel-inner{display:flex; flex-direction:column; height:100%}",
    ".tabs{display:flex; gap:6px; border-bottom:1px solid var(--border); padding:8px}",
    ".tab{padding:6px 10px; border:1px solid var(--border); border-bottom:none; border-radius:8px 8px 0 0; background:#222432; color:#cfd3f4; cursor:pointer}",
    ".tab.active{background:#1e2030}",
    ".pane{flex:1; display:none; min-height:0}",
    ".pane.active{display:flex; overflow:auto}",
    ".mini{width:100%; background:#202233; color:#e9ecff; border:1px solid var(--border); border-radius:8px; padding:6px 8px; outline:none; font-size:13px}",
    ".btn{background:#202124; color:#f1f1f1; border:1px solid var(--border); padding:7px 10px; border-radius:8px; cursor:pointer}",
    ".btn:hover{filter:brightness(1.06)}",
    ".list{flex:1; padding:8px; overflow:auto; font-size:13px}",
    ".row{display:flex; gap:8px; align-items:center}",
    ".hint{position:absolute; bottom:14px; left:50%; transform:translateX(-50%); color:var(--muted); font-size:12px; opacity:.8}"
  ].join("\n");
  doc.head.appendChild(style);

  // ---------- DOM ----------
  container.innerHTML = "";
  const root = doc.createElement("div");
  root.className = "root";
  root.innerHTML = [
    '<div class="editor" id="editor">',
    '  <div class="topbar">',
    '    <span class="tag" id="modeTag">MODE: user</span>',
    '    <span class="tag" id="pkgTag">PKGS: 0</span>',
    '    <span class="tag" id="verTag">TR v1.0.0</span>',
    '    <span class="pill" id="panelBtn">Packages</span>',
    '    <span class="pill" id="adminBtn">Admin: off</span>',
    '  </div>',
    '  <div class="shell">',
    '    <div class="left" id="lines">1</div>',
    '    <div class="right">',
    '      <div class="log" id="log"></div>',
    '      <div class="input">',
    '        <input class="cmd" id="cmd" placeholder=":help — install/enable/disable/list/export/import packages; (:panel toggles package panel)" autocomplete="off"/>',
    '      </div>',
    '    </div>',
    '    <div class="panel" id="panel">',
    '      <div class="panel-inner">',
    '        <div class="tabs">',
    '          <div class="tab active" data-pane="pkgs">Packages</div>',
    '          <div class="tab" data-pane="config">Config</div>',
    '        </div>',
    '        <div class="pane active" id="pane-pkgs">',
    '          <div class="list" id="pkgList"></div>',
    '          <div class="row" style="padding:8px;border-top:1px solid var(--border)">',
    '            <input class="mini" id="fileName" placeholder="new-package.js (optional hint)"/>',
    '            <button class="btn" id="installBtn">Install .js</button>',
    '            <button class="btn" id="reloadBtn">Reload enabled</button>',
    '          </div>',
    '        </div>',
    '        <div class="pane" id="pane-config">',
    '          <div class="list" id="configView"></div>',
    '          <div class="row" style="padding:8px;border-top:1px solid var(--border)">',
    '            <button class="btn" id="exportCfg">Export config</button>',
    '            <button class="btn" id="importCfg">Import config</button>',
    '            <button class="btn" id="resetCfg">Reset (local)</button>',
    '          </div>',
    '        </div>',
    '      </div>',
    '    </div>',
    '  </div>',
    '</div>',
    '<div class="hint">Type <code>:help</code> for documentation</div>'
  ].join("\n");
  container.appendChild(root);

  // ---------- Small helpers ----------
  const $ = s => root.querySelector(s);
  const on = (el, ev, fn) => el.addEventListener(ev, fn);
  const linesEl = $("#lines");
  const logEl = $("#log");
  const cmdEl = $("#cmd");
  const panel = $("#panel");
  const pkgList = $("#pkgList");
  const configView = $("#configView");

  let lineCount = 1;
  const print = (msg, cls="") => {
    const div = doc.createElement("div");
    if (cls) div.className = cls;
    div.textContent = msg;
    logEl.appendChild(div);
    logEl.scrollTop = logEl.scrollHeight;
    lineCount += String(msg).split("\n").length;
    linesEl.textContent = Array.from({length: lineCount}, (_, i) => i+1).join("\n");
  };

  const setTag = (id, text) => { const el = $("#"+id); if (el) el.textContent = text; };

  // ---------- Admin gating ----------
  const CTRL = { admin: false };
  function requireAdmin() {
    if (!CTRL.admin) { print("admin-developer required. Use :admin on or click Admin button.","err"); return false; }
    return true;
  }

  // appId already defined globally elsewhere as "tr-terminal"

  async function fetchSelf(file) {
    // 1) Compute the *directory* of the current document (e.g. "/tr/")
    const path = location.pathname || "/";
    const baseDir = path.endsWith("/")
      ? path
      : path.replace(/\/[^\/]*$/, "/"); // strip last segment (e.g. "sandbox.html")

    // 2) Always target that dir's index.php (e.g. "/tr/index.php")
    const basePath = baseDir + "index.php";

    // 3) Preserve slashes in the file param
    const fileParam = encodeURI(file); // encodes spaces, NOT '/'

    // 4) Build a strictly relative, same-origin URL (no protocol/host)
    const url = `${basePath}?api=apps&method=getAppAsset&appId=${encodeURIComponent(appId)}&file=${fileParam}&v=${Date.now()}`;

    const res = await fetch(url, {
      cache: "no-store",
      credentials: "same-origin",
      redirect: "follow"
    });

    if (!res.ok) throw new Error(`asset fetch failed: ${res.status}`);
    const text = await res.text();
    if (!text.trim()) throw new Error("empty response");
    return text;
  }


  // ---------- Config (disk-like via import/export + local mirror) ----------
  const LS_KEY = "tr-terminal.config";
  const DEFAULT_CFG = {
    version: "1.0.0",
    installed: { /* name: { filename, enabled, type: 'patch'|'ext', hash, installedAt, updatedAt } */ },
    order: []
  };

  let CONFIG = loadConfigLocal();

  // Try to merge packaged config if present
  (async () => {
    try {
      const cfgTxt = await fetchSelf("extend/tr-terminal-config.json");
      const packaged = JSON.parse(cfgTxt);
      mergeConfig(packaged);
      saveConfigLocal();
      print(`Loaded config from extend/tr-terminal-config.json`, "muted");
    } catch {
      print(`No packaged config in extend/tr-terminal-config.json (using local mirror)`, "muted");
    }
    refreshBadges();
    renderPkgList();
    renderConfigView();
  })();

  function loadConfigLocal() {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (!raw) return structuredClone(DEFAULT_CFG);
      const obj = JSON.parse(raw);
      return { ...structuredClone(DEFAULT_CFG), ...obj, installed: obj.installed || {}, order: obj.order || [] };
    } catch (_) { return structuredClone(DEFAULT_CFG); }
  }
  function saveConfigLocal() {
    localStorage.setItem(LS_KEY, JSON.stringify(CONFIG));
  }
  function mergeConfig(incoming) {
    if (!incoming || typeof incoming !== "object") return;
    CONFIG.version = CONFIG.version || incoming.version || "1.0.0";
    CONFIG.order = Array.isArray(CONFIG.order) ? CONFIG.order : [];
    const inc = incoming.installed || {};
    for (const name of Object.keys(inc)) {
      if (!CONFIG.installed[name]) {
        CONFIG.installed[name] = inc[name];
        CONFIG.order.push(name);
      }
    }
    // keep existing enabled flags as-is
  }

  function download(name, content, mime="application/json") {
    const blob = new Blob([content], { type: mime });
    const a = doc.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    doc.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 0);
  }

  function refreshBadges() {
    setTag("pkgTag", `PKGS: ${Object.keys(CONFIG.installed).length}`);
    setTag("modeTag", `MODE: ${CTRL.admin ? "admin" : "user"}`);
  }

  // ---------- Package registry / REPL commands ----------
  const registry = {
    commands: Object.create(null),
    aliases: Object.create(null)
  };

  function registerCommand(name, fn) {
    if (!name || typeof fn !== "function") return false;
    registry.commands[name] = fn;
    return true;
  }
  function unregisterCommand(name) {
    delete registry.commands[name];
  }
  function addAlias(alias, target) {
    if (!alias || !target) return false;
    registry.aliases[alias] = target;
    return true;
  }

  // Built-in commands
  registerCommand("echo", (argv, api) => api.print(argv.join(" ")));
  registerCommand("help", (argv, api) => api.print(coreHelp));
  registerCommand("state", (argv, api) => api.print(JSON.stringify({ admin: CTRL.admin, version: "1.0.0" }, null, 2)));
  registerCommand("version", (argv, api) => api.print("TR Terminal v1.0.0"));

  const coreHelp = [
    "TR TERMINAL — core commands",
    "  :help                     Show this help.",
    "  :admin on|off             Toggle admin developer mode.",
    "  :panel                    Toggle Packages panel.",
    "  :list                     List installed packages.",
    "  :install                  Pick a .js file (admin).",
    "  :enable <name>            Enable a package (admin).",
    "  :disable <name>           Disable a package (admin).",
    "  :uninstall <name>         Remove a package (admin).",
    "  :reload                   Reload all enabled packages.",
    "  :config export            Download tr-terminal-config.json.",
    "  :config import            Load config from file (admin).",
    "  :config reset             Reset local config (admin).",
    "",
    "Packages can register REPL commands; try :help again after install.",
  ].join("\n");

  function apiObject() {
    return {
      print,
      getState: () => ({ admin: CTRL.admin, version: "1.0.0", config: CONFIG }),
      getConfig: () => JSON.parse(JSON.stringify(CONFIG)),
      setConfig: (cb) => { if (typeof cb === "function") { const next = cb(JSON.parse(JSON.stringify(CONFIG))); if (next) CONFIG = next; } },
      saveConfig: () => { saveConfigLocal(); renderPkgList(); renderConfigView(); refreshBadges(); },
      fetchSelf: fetchSelf,
      addAlias
    };
  }

  const tr = {
    registerCommand,
    unregisterCommand,
    api: apiObject()
  };

  async function evalPackageText(name, codeText) {
    // 1) Try ESM via blob url
    try {
      const url = URL.createObjectURL(new Blob([codeText], { type: "text/javascript" }));
      try {
        const mod = await import(/* @vite-ignore */ url);
        if (mod && typeof mod.register === "function") {
          URL.revokeObjectURL(url);
          mod.register(tr);
          return "esm";
        }
      } finally {
        URL.revokeObjectURL(url);
      }
    } catch (_) { /* ignore and try classic */ }

    // 2) If classic path sees 'export', shim it into a classic wrapper
    let classicText = codeText;
    if (/^\s*export\s+function\s+register\s*\(/m.test(codeText)) {
      classicText =
        "window.trTerminalPackage={register:" +
        codeText
          .replace(/^\s*export\s+function\s+register\s*\(/m, "function(")
          .replace(/\}\s*$/, "}") + // keep body
        "};";
    } else if (/^\s*export\s+default\s+function\s*\(/m.test(codeText)) {
      classicText =
        "window.trTerminalPackage={register:" +
        codeText
          .replace(/^\s*export\s+default\s+function\s*\(/m, "function(")
          .replace(/\}\s*$/, "}") +
        "};";
    }

    // 3) Classic eval
    const fn = new Function("window", classicText + "\n;return window.trTerminalPackage;");
    const pkg = fn(window);
    if (pkg && typeof pkg.register === "function") {
      pkg.register(tr);
      try { delete window.trTerminalPackage; } catch { window.trTerminalPackage = undefined; }
      return "classic";
    }
    throw new Error("package has no register() export");
  }


  async function loadEnabledPackages() {
    // Load in CONFIG.order order
    for (const name of CONFIG.order) {
      const meta = CONFIG.installed[name];
      if (!meta || !meta.enabled) continue;
      try {
        // Prefer packaged asset; otherwise localStorage blob
        let codeText = null;
        if (meta.filename) {
          try {
            const path = normalizePkgPath(meta.filename);
            codeText = await fetchSelf(path);
          } catch (_) { /* ignore */ }
        }
        if (!codeText && meta.local) {
          codeText = base64DecodeUtf8(meta.local);
        }
        if (!codeText) { print(`skip: ${name} (file not found)`, "muted"); continue; }
        const mode = await evalPackageText(name, codeText);
        print(`loaded: ${name} (${mode})`, "ok");
      } catch (e) {
        print(`load failed: ${name} — ${String(e.message || e)}`, "err");
      }
    }
  }

  // ---------- Panel: list + actions ----------
  function renderPkgList() {
    pkgList.innerHTML = "";
    if (CONFIG.order.length === 0) {
      const d = doc.createElement("div"); d.className = "muted"; d.textContent = "(no packages installed)";
      pkgList.appendChild(d); return;
    }
    CONFIG.order.forEach(name => {
      const meta = CONFIG.installed[name];
      if (!meta) return;
      const row = doc.createElement("div"); row.className = "row"; row.style.padding = "6px 8px";
      const tag = doc.createElement("span"); tag.className = "tag"; tag.textContent = `${meta.enabled ? "EN" : "DIS"} • ${name}`;
      const fn = doc.createElement("span"); fn.className = "muted"; fn.textContent = ` ${meta.filename || "(local only)"} `;
      const eb = doc.createElement("button"); eb.className = "btn"; eb.textContent = meta.enabled ? "Disable" : "Enable";
      const rb = doc.createElement("button"); rb.className = "btn"; rb.textContent = "Uninstall";
      eb.onclick = () => { if (!requireAdmin()) return; meta.enabled = !meta.enabled; meta.updatedAt = new Date().toISOString(); saveConfigLocal(); renderPkgList(); refreshBadges(); };
      rb.onclick = () => { if (!requireAdmin()) return; delete CONFIG.installed[name]; CONFIG.order = CONFIG.order.filter(n => n !== name); saveConfigLocal(); renderPkgList(); refreshBadges(); };
      row.append(tag, fn, eb, rb);
      pkgList.appendChild(row);
    });
  }

  function renderConfigView() {
    configView.innerHTML = "";
    const pre = doc.createElement("pre");
    pre.textContent = JSON.stringify(CONFIG, null, 2);
    configView.appendChild(pre);
  }

  // ---------- File pickers ----------
  function pickFile(accept, cb) {
    const inp = doc.createElement("input");
    inp.type = "file"; inp.accept = accept;
    inp.onchange = async () => { const f = inp.files && inp.files[0]; if (!f) return; const txt = await f.text(); cb(f, txt); };
    inp.click();
  }

  // ---------- Topbar buttons ----------
  on($("#panelBtn"), "click", () => panel.classList.toggle("open"));
  on($("#adminBtn"), "click", () => { CTRL.admin = !CTRL.admin; $("#adminBtn").textContent = `Admin: ${CTRL.admin ? "on" : "off"}`; refreshBadges(); });

  // Panel actions
  on($("#installBtn"), "click", () => {
    if (!requireAdmin()) return;
    pickFile(".js", async (file, text) => {
      const nameHint = ($("#fileName").value || file.name || "package.js").replace(/\s+/g, "-");
      const base = nameHint.replace(/\.js$/i, "");
      const name = uniqueName(base);
      const now = new Date().toISOString();
      const packagedFilename = normalizePkgPath(file.name || (base + ".js"));
      CONFIG.installed[name] = {
        filename: packagedFilename,
        enabled: true,
        type: "ext",
        hash: simpleHash(text),
        installedAt: now,
        updatedAt: now,
        local: base64EncodeUtf8(text)
      };
      if (!CONFIG.order.includes(name)) CONFIG.order.push(name);
      saveConfigLocal();
      renderPkgList(); refreshBadges();
      print(`installed: ${name} • ${packagedFilename}  (place file under /extend/ when packaging)`, "ok");
      // Offer export so the file can be placed next to the app on disk
      download((file.name || (base + ".js")), text, "text/javascript");
    });
  });

  function clearRegistry() {
    registry.commands = Object.create(null);
    registry.aliases  = Object.create(null);
    // re-register built-ins
    registerCommand("echo", (argv, api) => api.print(argv.join(" ")));
    registerCommand("help", (argv, api) => api.print(coreHelp));
    registerCommand("state", (argv, api) => api.print(JSON.stringify({ admin: CTRL.admin, version: "1.0.0" }, null, 2)));
    registerCommand("version", (argv, api) => api.print("TR Terminal v1.0.0"));
  }

  on($("#reloadBtn"), "click", async () => {
    clearRegistry();                 // <— add this line
    await loadEnabledPackages();
    print("reload complete", "muted");
  });

  on($("#exportCfg"), "click", () => {
    download("tr-terminal-config.json", JSON.stringify(CONFIG, null, 2));
  });

  function normalizeConfigPaths() {
    for (const name of Object.keys(CONFIG.installed)) {
      const meta = CONFIG.installed[name];
      if (meta && meta.filename) meta.filename = normalizePkgPath(meta.filename);
    }
  }

  on($("#importCfg"), "click", () => {
    if (!requireAdmin()) return;
    pickFile("application/json,.json", async (file, text) => {
      try {
        const obj = JSON.parse(text);
        mergeConfig(obj);
        normalizeConfigPaths();        // <— add this
        saveConfigLocal();
        renderPkgList(); renderConfigView(); refreshBadges();
        print(`config merged: ${file.name}`, "ok");
      } catch (e) {
        print("config import failed: " + String(e.message || e), "err");
      }
    });
  });
  on($("#resetCfg"), "click", () => {
    if (!requireAdmin()) return;
    CONFIG = structuredClone(DEFAULT_CFG);
    saveConfigLocal(); renderPkgList(); renderConfigView(); refreshBadges();
    print("local config reset", "muted");
  });

  // ---------- Utilities ----------
  // --- UTF-8 safe Base64 helpers ---
  function base64EncodeUtf8(str) {
    if (window.TextEncoder) {
      const bytes = new TextEncoder().encode(str);
      let bin = "";
      for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
      return btoa(bin);
    }
    // Fallback (older engines)
    return btoa(unescape(encodeURIComponent(str)));
  }

  function base64DecodeUtf8(b64) {
    if (!b64) return "";
    if (window.TextDecoder) {
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new TextDecoder().decode(bytes);
    }
    // Fallback (older engines)
    return decodeURIComponent(escape(atob(b64)));
  }

  function uniqueName(base) {
    let n = base.replace(/[^a-z0-9\-_.]/ig, "");
    if (!n) n = "pkg";
    let k = n, i = 1;
    while (CONFIG.installed[k]) { k = `${n}-${i++}`; }
    return k;
  }
  function simpleHash(text) {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < text.length; i++) {
      h ^= text.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return ("00000000" + h.toString(16)).slice(-8);
  }

  // ---------- REPL ----------
  const helpText = [
    "OVERVIEW",
    "  Minimal TR Terminal with admin developer mode and package system.",
    "  Packages live next to tr-terminal.js (preferred) or in local storage (dev).",
    "",
    "REPL COMMANDS",
    "  :help",
    "  :admin on|off               Toggle admin mode",
    "  :panel                      Toggle Packages panel",
    "  :list                       List installed packages",
    "  :install                    Pick a .js package file (admin)",
    "  :enable <name>              Enable package (admin)",
    "  :disable <name>             Disable package (admin)",
    "  :uninstall <name>           Remove package (admin)",
    "  :reload                     Reload all enabled packages",
    "  :config export|import|reset Config ops (import/reset are admin)",
    "  :echo <...>                 Built-in test command",
    "  :state                      Show terminal state",
    "  :version                    Show version",
    "",
    "Packages may add more commands (run :help afterwards)."
  ].join("\n");

  function runLine(line) {
    const raw = String(line || "").trim();
    if (!raw) return;
    if (!raw.startsWith(":")) {
      print("(data) " + raw, "muted");
      return;
    }
    const parts = raw.slice(1).split(/\s+/);
    const cmd = parts.shift().toLowerCase();
    const args = parts;

    // First try built-ins
    switch (cmd) {
      case "help": return print(helpText);
      case "panel": panel.classList.toggle("open"); return;
      case "admin": {
        const onOff = (args[0] || "").toLowerCase();
        CTRL.admin = onOff === "on";
        $("#adminBtn").textContent = `Admin: ${CTRL.admin ? "on" : "off"}`;
        refreshBadges();
        return print("admin=" + (CTRL.admin ? "on" : "off"), "ok");
      }
      case "list": {
        const items = CONFIG.order.map(n => {
          const m = CONFIG.installed[n];
          return ` - ${n} [${m.enabled ? "enabled" : "disabled"}]  ${m.filename || "(local)"}`;
        }).join("\n") || "(none)";
        return print(items);
      }
      case "install": {
        if (!requireAdmin()) return;
        $("#panelBtn").click(); // open panel to install
        return;
      }
      case "enable": {
        if (!requireAdmin()) return;
        const name = args[0]; if (!name) return print("usage: :enable <name>", "muted");
        const m = CONFIG.installed[name]; if (!m) return print("not found: " + name, "err");
        m.enabled = true; m.updatedAt = new Date().toISOString(); saveConfigLocal(); renderPkgList(); refreshBadges();
        return print("enabled: " + name, "ok");
      }
      case "disable": {
        if (!requireAdmin()) return;
        const name = args[0]; if (!name) return print("usage: :disable <name>", "muted");
        const m = CONFIG.installed[name]; if (!m) return print("not found: " + name, "err");
        m.enabled = false; m.updatedAt = new Date().toISOString(); saveConfigLocal(); renderPkgList(); refreshBadges();
        return print("disabled: " + name, "ok");
      }
      case "uninstall": {
        if (!requireAdmin()) return;
        const name = args[0]; if (!name) return print("usage: :uninstall <name>", "muted");
        if (!CONFIG.installed[name]) return print("not found: " + name, "err");
        delete CONFIG.installed[name];
        CONFIG.order = CONFIG.order.filter(n => n !== name);
        saveConfigLocal(); renderPkgList(); refreshBadges();
        return print("uninstalled: " + name, "ok");
      }
      case "reload": return loadEnabledPackages().then(() => print("reload complete", "muted"));
      case "config": {
        const sub = (args[0] || "").toLowerCase();
        if (sub === "export") { download("tr-terminal-config.json", JSON.stringify(CONFIG, null, 2)); return; }
        if (sub === "import") {
          if (!requireAdmin()) return;
          pickFile("application/json,.json", async (file, text) => {
            try { const obj = JSON.parse(text); mergeConfig(obj); saveConfigLocal(); renderPkgList(); renderConfigView(); refreshBadges(); print(`config merged: ${file.name}`, "ok"); }
            catch (e) { print("config import failed: " + String(e.message || e), "err"); }
          });
          return;
        }
        if (sub === "reset") {
          if (!requireAdmin()) return;
          CONFIG = structuredClone(DEFAULT_CFG);
          saveConfigLocal(); renderPkgList(); renderConfigView(); refreshBadges();
          return print("local config reset", "muted");
        }
        return print("usage: :config export|import|reset", "muted");
      }
      default:
        // Aliases?
        if (registry.aliases[cmd]) {
          const expanded = registry.aliases[cmd] + (args.length ? (" " + args.join(" ")) : "");
          return runLine(":" + expanded);
        }
        // Packages?
        const fn = registry.commands[cmd];
        if (typeof fn === "function") {
          try { return fn(args, apiObject()); }
          catch (e) { return print("cmd error: " + String(e.message || e), "err"); }
        }
        return print("unknown command: :" + cmd + " (try :help)", "err");
    }
  }

  // ---------- Boot ----------
  print("TR Terminal ready. Type :help");
  refreshBadges();
  renderPkgList();
  renderConfigView();
  loadEnabledPackages();

  // ---------- Input ----------
  doc.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "p") {
      e.preventDefault(); panel.classList.toggle("open");
    }
  });
  on(cmdEl, "keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const v = cmdEl.value; cmdEl.value = "";
      print("> " + v, "muted");
      runLine(v);
    }
  });
}
