/**
 * @file solution.cpp
 * @brief Permutation Generator in C++, architected to safety-critical standards.
 *
 * @author Dominic Alexander Cooper (Original Algorithm)
 * @author Gemini / ChatGPT (C++ Architectural Refactoring)
 *
 * @details
 * This program generates all possible character combinations for a given set
 * of lengths, based on a character set provided at runtime.
 *
 * It is designed to align with principles of safety-critical software design,
 * including robust error checking, bounds checking, and abstraction of
 * I/O operations using a C++ interface.
 *
 * This version creates a separate .txt file for each permutation length
 * requested. For example, running:
 *
 *   solution.exe "@dom98" 1 2
 *
 * will generate:
 *
 *   permutations_len_1.txt
 *   permutations_len_2.txt
 *
 * containing all permutations of length 1 and 2 respectively over the chosen
 * alphabet.
 */

#include <iostream>  // For std::cout, std::cerr, std::endl
#include <fstream>   // For std::ofstream
#include <string>    // For std::string
#include <sstream>   // For std::stringstream (filename generation)
#include <cstdint>   // For std::uint64_t
#include <limits>    // For std::numeric_limits
#include <stdexcept> // For std::invalid_argument, std::out_of_range, std::runtime_error
#include <cstdlib>   // For EXIT_SUCCESS, EXIT_FAILURE

//==============================================================================
// 1. CONFIGURATION AND DATA DEFINITIONS
//==============================================================================

/**
 * @def MAX_PERMUTATION_LENGTH
 * @brief Hard-coded safety limit for the maximum permutation length.
 *
 * This prevents extreme memory usage or unbounded runtime by limiting how
 * long individual permutations may be.
 */
constexpr std::uint64_t MAX_PERMUTATION_LENGTH = 26;

//==============================================================================
// 1.1 DOMINIC'S 98-SYMBOL ALPHABET
//==============================================================================
//
// Index mapping (1-based, conceptual):
//  1–26  : a–z
// 27–52  : A–Z
// 53–62  : 0–9
// 63     : +
// 64     : -
// 65     : *
// 66     : /
// 67     : %
// 68     : =
// 69     : !
// 70     : <
// 71     : >
// 72     : &
// 73     : |
// 74     : ^
// 75     : ~
// 76     : ?
// 77     : :
// 78     : ;
// 79     : ,
// 80     : .
// 81     : (
// 82     : )
// 83     : [
// 84     : ]
// 85     : {
// 86     : }
// 87     : #
// 88     : "
// 89     : '
// 90     : bslash
// 91     : _
// 92     : @
// 93     : $
// 94     : `
// 95     : bslasht   (tab)
// 96     : ' '  (space)
// 97     : bslashn   (newline)
// 98     : bslash0   (null byte)
//
// Note: This is stored as a raw char array (not a C-string). We always
// pass an explicit length when constructing std::string so that the '\0'
// symbol is treated as just another valid alphabet character.
static const char DOMINIC_ALPHABET_98[] = {
    'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t',
    'u','v','w','x','y','z',
    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T',
    'U','V','W','X','Y','Z',
    '0','1','2','3','4','5','6','7','8','9',
    '+','-','*','/','%','=','!','<','>','&','|','^','~','?',
    ':',';',
    ',', '.',
    '(', ')','[',']','{','}','#','\"','\'','\\','_','@','$','`',
    '\t',' ','\n','\0'
};

//==============================================================================
// 2. ABSTRACT INTERFACE FOR OUTPUT (IOutputSink)
//==============================================================================

/**
 * @class IOutputSink
 * @brief An abstract interface for writing output.
 *
 * This decouples the core permutation logic from the output destination
 * (e.g., file, console, network socket). The core logic does not need to
 * know *where* it is writing, only *how* to write via this interface.
 */
class IOutputSink {
public:
    virtual ~IOutputSink() = default;

    /**
     * @brief Write a buffer of bytes.
     * @param buffer Pointer to the character buffer to write.
     * @param size Number of bytes to write.
     * @return true on success, false on failure.
     */
    virtual bool Write(const char* buffer, std::uint64_t size) = 0;

    /**
     * @brief Write a single character.
     * @param c The character to write.
     * @return true on success, false on failure.
     */
    virtual bool WriteChar(char c) = 0;
};

//==============================================================================
// 3. FILE-BASED OUTPUT IMPLEMENTATION (FileSink)
//==============================================================================

/**
 * @class FileSink
 * @brief Concrete implementation of IOutputSink that writes to a file.
 */
class FileSink : public IOutputSink {
public:
    /**
     * @brief Constructs a FileSink and opens the underlying file.
     * @param filename Path to the output file.
     *
     * @throws std::runtime_error if the file cannot be opened.
     */
    explicit FileSink(const std::string& filename)
        : m_file_stream(filename, std::ios::binary | std::ios::trunc)
    {
        if (!m_file_stream.is_open()) {
            throw std::runtime_error("Failed to open output file: " + filename);
        }
    }

    ~FileSink() override {
        if (m_file_stream.is_open()) {
            m_file_stream.close();
        }
    }

    bool Write(const char* buffer, std::uint64_t size) override {
        m_file_stream.write(buffer, static_cast<std::streamsize>(size));
        return m_file_stream.good();
    }

    bool WriteChar(char c) override {
        m_file_stream.put(c);
        return m_file_stream.good();
    }

    FileSink(const FileSink&) = delete;
    FileSink& operator=(const FileSink&) = delete;

private:
    std::ofstream m_file_stream;
};

//==============================================================================
// 4. SAFE ARITHMETIC HELPERS
//==============================================================================

/**
 * @brief Safely multiply two std::uint64_t values with overflow detection.
 * @return true if result is valid, false if overflow would occur.
 */
static bool safe_uint64_mul(std::uint64_t a, std::uint64_t b, std::uint64_t& result) {
    if (a == 0 || b == 0) {
        result = 0;
        return true;
    }
    if (a > (std::numeric_limits<std::uint64_t>::max() / b)) {
        return false; // Overflow
    }
    result = a * b;
    return true;
}

/**
 * @brief Safely compute base^exp for std::uint64_t with overflow detection.
 * @param base The base value.
 * @param exp The exponent.
 * @param result Output parameter for the result if successful.
 * @return true on success, false on overflow.
 */
static bool safe_uint64_power(std::uint64_t base, std::uint64_t exp, std::uint64_t& result) {
    result = 1;
    for (std::uint64_t i = 0; i < exp; ++i) {
        std::uint64_t tmp = 0;
        if (!safe_uint64_mul(result, base, tmp)) {
            return false; // Overflow
        }
        result = tmp;
    }
    return true;
}

//==============================================================================
// 5. CORE PERMUTATION GENERATION LOGIC
//==============================================================================

/**
 * @brief Generate all permutations of a given length over the provided charset.
 *
 * Each permutation is written as a sequence of bytes of length @p length,
 * followed by a newline character ('\n'). Note that because the alphabet
 * may itself contain '\n' and '\0', the resulting file should be treated
 * as a binary file if using @dom98.
 *
 * @param length  Length of permutations to generate (e.g., 3 for "aaa").
 * @param charset Character set to use for generation.
 * @param sink    Output sink to receive the permutations.
 * @return true on success, false on I/O error or arithmetic overflow.
 */
static bool generate_permutations(
    std::uint64_t length,
    const std::string& charset,
    IOutputSink& sink
) {
    const std::uint64_t charset_size = charset.size();

    if (charset_size == 0) {
        std::cerr << "Error: Charset size is zero.\n";
        return false;
    }

    std::uint64_t num_combinations = 0;
    if (!safe_uint64_power(charset_size, length, num_combinations)) {
        std::cerr << "Error: Overflow computing number of combinations for length "
                  << length << ".\n";
        return false;
    }

    if (num_combinations == 0) {
        // Trivial case: nothing to generate.
        return true;
    }

    // Preallocate a buffer for one permutation line (without newline).
    std::string buffer(length, '\0');

    for (std::uint64_t index = 0; index < num_combinations; ++index) {
        std::uint64_t value = index;

        // Convert `index` into base-charset_size representation.
        for (std::int64_t pos = static_cast<std::int64_t>(length) - 1; pos >= 0; --pos) {
            const std::uint64_t digit = value % charset_size;
            value /= charset_size;
            buffer[static_cast<std::size_t>(pos)] = charset[static_cast<std::size_t>(digit)];
        }

        if (!sink.Write(buffer.data(), length)) {
            std::cerr << "Error: Failed to write permutation to sink.\n";
            return false;
        }
        if (!sink.WriteChar('\n')) {
            std::cerr << "Error: Failed to write newline to sink.\n";
            return false;
        }
    }

    return true;
}

//==============================================================================
// 6. USAGE / HELP
//==============================================================================

/**
 * @brief Print usage information for this executable.
 */
static void print_usage(const char* program_name) {
    std::cerr << "Usage:\n"
              << "  " << program_name << " <charset|@dom98> <min_length> <max_length>\n\n"
              << "Examples:\n"
              << "  " << program_name << " \"abc\" 1 3\n"
              << "      # Use explicit charset 'a', 'b', 'c' with lengths 1 to 3.\n\n"
              << "  " << program_name << " @dom98 1 4\n"
              << "      # Use Dominic's 98-symbol alphabet (built in) with lengths 1 to 4.\n";
}

//==============================================================================
// 7. MAIN ENTRY POINT
//==============================================================================

int main(int argc, char* argv[]) {
    // --- 1. Argument Validation ---
    if (argc != 4) {
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }

    std::string charset;
    std::uint64_t min_length = 0;
    std::uint64_t max_length = 0;

    // --- 2. Parse Runtime Parameters (with C++ exceptions) ---
    try {
        std::string charset_arg = argv[1];

        // Special mode: use Dominic's 98-symbol alphabet (size 98).
        // This includes printable ASCII, operators, space, tab, newline, and a
        // literal '\0' symbol as the 98th character.
        if (charset_arg == "@dom98") {
            charset.assign(
                DOMINIC_ALPHABET_98,
                DOMINIC_ALPHABET_98 + sizeof(DOMINIC_ALPHABET_98)
            );
        } else {
            // Original behaviour: use argv[1] literally as the charset string.
            charset = charset_arg;
        }

        // Use std::stoull for robust parsing of lengths.
        min_length = std::stoull(argv[2]);
        max_length = std::stoull(argv[3]);
    }
    catch (const std::invalid_argument&) {
        std::cerr << "Error: Invalid characters in length arguments. Must be integers.\n";
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }
    catch (const std::out_of_range&) {
        std::cerr << "Error: Length arguments are out of range for a 64-bit integer.\n";
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }

    // --- 3. Safety-Critical Parameter Validation ---

    if (charset.empty()) {
        std::cerr << "Error: Charset cannot be empty.\n";
        return EXIT_FAILURE;
    }

    if (min_length == 0) {
        std::cerr << "Error: min_length must be at least 1.\n";
        return EXIT_FAILURE;
    }

    if (max_length < min_length) {
        std::cerr << "Error: max_length (" << max_length
                  << ") is less than min_length (" << min_length << ").\n";
        return EXIT_FAILURE;
    }

    if (max_length > MAX_PERMUTATION_LENGTH) {
        std::cerr << "Error: Requested max_length (" << max_length
                  << ") exceeds safety limit MAX_PERMUTATION_LENGTH ("
                  << MAX_PERMUTATION_LENGTH << ").\n";
        return EXIT_FAILURE;
    }

    // --- 4. Generate permutations for each requested length ---

    bool success = true;

    for (std::uint64_t length = min_length; length <= max_length; ++length) {
        std::stringstream filename_builder;
        filename_builder << "permutations_len_" << length << ".txt";
        const std::string filename = filename_builder.str();

        std::cout << "Generating permutations of length " << length
                  << " into file: " << filename << " ...\n";

        try {
            FileSink sink(filename);

            if (!generate_permutations(length, charset, sink)) {
                std::cerr << "Error: Generation failed for length " << length << ".\n";
                success = false;
                break;
            }
        }
        catch (const std::runtime_error& e) {
            std::cerr << "Error: " << e.what() << "\n";
            success = false;
            break;
        }
    }

    if (success) {
        std::cout << "All generations complete.\n";
        return EXIT_SUCCESS;
    } else {
        std::cerr << "Generation failed and was halted.\n";
        return EXIT_FAILURE;
    }
}
