<?php
require_once 'auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    logout();
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TR Admin Workbench</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="main-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>TR Workbench</h2>
                <a href="index.php?action=logout">Logout</a>
            </div>
            <div class="sidebar-content">
                <h3>Versions</h3>
                <button id="create-version-btn" class="button-primary">Create New Version</button>
                <ul id="versions-list">
                    </ul>
            </div>
        </aside>

        <main class="main-content">
            <div class="content-panel" id="file-browser-panel">
                <div class="panel-header">
                    <h3 id="file-browser-heading">Select a Version</h3>
                </div>
                <div class="panel-body" id="file-tree">
                    </div>
            </div>

            <div class="content-panel" id="editor-panel">
                <div class="panel-header">
                    <h3 id="editor-heading">Editor</h3>
                    <div id="editor-actions" style="display: none;">
                        <button id="save-file-btn">Save Changes</button>
                    </div>
                </div>
                <div class="panel-body">
                    <div id="editor-container"></div>
                    <div id="editor-placeholder">
                        <p>Select a file from the browser to view or edit its contents.</p>
                    </div>
                </div>
            </div>
            
            <div class="content-panel" id="actions-panel">
                <div class="panel-header">
                    <h3>Actions & Testing</h3>
                </div>
                <div class="panel-body" id="actions-body">
                    <div id="actions-placeholder"><p>Select a version to see available actions.</p></div>
                    <div id="actions-content" style="display:none;">
                        <h4>Run Automated Tests</h4>
                        <p>Verify the integrity and stability of this version before deployment.</p>
                        <button id="run-tests-btn">Run Tests</button>
                        <pre id="test-results-output"></pre>
                        
                        <hr>
                        
                        <h4>Deployment</h4>
                        <p>Deploy this version to the live environment. The current live version will be backed up automatically.</p>
                        <button id="deploy-btn" class="button-danger" disabled>Deploy Version</button>

                        <hr>

                        <h4>Other Actions</h4>
                        <button id="download-btn">Download (.zip)</button>
                        <button id="delete-btn" class="button-danger">Delete Version</button>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <div id="modal" class="modal-backdrop" style="display:none;">
        <div class="modal-content">
            <h3 id="modal-title">Notice</h3>
            <p id="modal-message"></p>
            <div class="modal-actions">
                <button id="modal-confirm-btn">OK</button>
                <button id="modal-cancel-btn" style="display:none;">Cancel</button>
            </div>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.15/codemirror.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.15/codemirror.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.15/mode/php/php.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.15/mode/xml/xml.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.15/mode/javascript/javascript.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.15/mode/css/css.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.15/mode/htmlmixed/htmlmixed.js"></script>

    <script src="assets/script.js"></script>
</body>
</html>