export function initialize(gosApiProxy) {
    const container = gosApiProxy.window.getContainer();
    const doc = container.ownerDocument;

    // 1. Inject CSS Styles
    const style = doc.createElement('style');
    style.textContent = `
        :root {
            --primary-color: #007bff; --secondary-color: #6c757d; --bg-color: #f8f9fa;
            --surface-color: #ffffff; --border-color: #dee2e6; --text-color: #212529;
            --header-color: #343a40; --pre-bg-color: #e9ecef; --success-color: #28a745;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--bg-color); color: var(--text-color); margin: 0; padding: 1rem;
            height: 100vh; box-sizing: border-box;
        }
        .workstation-grid {
            display: grid; grid-template-columns: 400px 1fr; gap: 1.5rem; max-width: 1400px; margin: auto; height: 100%;
        }
        .panel {
            background-color: var(--surface-color); border: 1px solid var(--border-color);
            border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); padding: 1.5rem;
            display: flex; flex-direction: column;
        }
        #controls-panel {
            overflow-y: auto;
        }
        h1, h2, h3 { color: var(--header-color); border-bottom: 2px solid var(--border-color); padding-bottom: 0.5rem; margin-top: 0; }
        h3 { margin-top: 1.5rem; }
        .control-group { display: flex; flex-direction: column; margin-bottom: 1rem; }
        label { font-weight: 600; margin-bottom: 0.5rem; color: #555; }
        input, select, textarea {
            padding: 0.75rem; border: 1px solid var(--border-color); border-radius: 4px; font-size: 1rem;
            width: 100%; box-sizing: border-box; background-color: #fff;
        }
        textarea { min-height: 80px; font-family: "Courier New", monospace; }
        button {
            padding: 0.75rem 1rem; font-size: 1rem; font-weight: 600; color: #fff; background-color: var(--primary-color);
            border: none; border-radius: 4px; cursor: pointer; transition: background-color 0.2s; display: block; width: 100%; margin-top: 0.5rem;
        }
        button:hover { background-color: #0056b3; }
        button:disabled { background-color: #a0c7e4; cursor: not-allowed; }
        .button-group { display: flex; gap: 0.5rem; }
        .secondary-button { background-color: var(--secondary-color); }
        .secondary-button:hover { background-color: #5a6268; }
        .success-button { background-color: var(--success-color); }
        .success-button:hover { background-color: #218838; }
        pre {
            background-color: var(--pre-bg-color); padding: 1rem; border-radius: 4px; white-space: pre-wrap;
            word-wrap: break-word; font-family: "Courier New", Courier, monospace; font-size: 0.95rem; max-height: 200px; overflow-y: auto;
        }
        #status { font-style: italic; color: #555; margin-bottom: 1rem; height: 20px; }
        .file-input { display: none; }
        .composition-box { border: 2px dashed var(--border-color); padding: 1rem; border-radius: 6px; margin-top: 1rem;}
        .ratio-display { font-weight: bold; color: var(--primary-color); text-align: center; background: var(--pre-bg-color); padding: 0.5rem; border-radius: 4px; margin-top: 0.5rem; }
    `;
    doc.head.appendChild(style);

    // 2. Inject HTML Structure
    container.style.height = '100%';
    container.style.overflow = 'hidden';
    container.innerHTML = `
        <div class="workstation-grid">
            <div id="controls-panel" class="panel">
                <h2>System Network Controls</h2>
                <div class="control-group">
                    <label for="system-select">Managed Systems</label>
                    <select id="system-select"></select>
                    <div class="button-group">
                        <button id="new-system-btn" class="secondary-button">New</button>
                        <button id="delete-system-btn" class="secondary-button">Delete</button>
                    </div>
                </div>
                <div class="control-group">
                    <label for="system-name">System Name</label>
                    <input type="text" id="system-name" value="Default System">
                </div>

                <h3>Geometric Ratio (1:d³)</h3>
                <div class="control-group">
                    <label for="d_value">Cube Dimension ('d')</label>
                    <input type="number" id="d_value" value="2" min="2" step="1">
                    <div id="ratio-display-output" class="ratio-display">Target Ratio: 1/9 (11.11%)</div>
                </div>

                <h3>Genetic Algorithm Parameters</h3>
                <div class="control-group">
                    <label for="permLength">Permutation Length</label>
                    <input type="number" id="permLength" value="50" min="10" max="200">
                </div>
                <div class="control-group">
                    <label for="populationSize">Population Size</label>
                    <input type="number" id="populationSize" value="100" min="10" max="500">
                </div>
                <div class="control-group">
                    <label for="numGenerations">Number of Generations</label>
                    <input type="number" id="numGenerations" value="100" min="10" max="1000">
                </div>

                <h3>Alphabet Configuration</h3>
                <div class="control-group">
                    <label for="alphabet-g">Target Alphabet (Component G)</label>
                    <textarea id="alphabet-g">abcdefghijklm</textarea>
                </div>

                <div class="composition-box">
                    <h3>System Composition</h3>
                    <div class="control-group">
                        <label for="parent-a-select">Parent System A</label>
                        <select id="parent-a-select"></select>
                    </div>
                    <div class="control-group">
                        <label for="parent-b-select">Parent System B</label>
                        <select id="parent-b-select"></select>
                    </div>
                    <div class="control-group">
                        <label for="alphabet-op-select">Alphabet Composition</label>
                        <select id="alphabet-op-select">
                            <option value="union">Union (A ∪ B)</option>
                            <option value="intersection">Intersection (A ∩ B)</option>
                        </select>
                    </div>
                    <button id="compose-btn" class="success-button">Compose New System</button>
                </div>
                <h3 style="margin-top: 2rem;">Execution & File I/O</h3>
                <button id="run-btn">▶️ Run Active System</button>
                <div class="button-group">
                     <button id="save-btn" class="secondary-button">Save Session</button>
                     <button id="load-btn" class="secondary-button">Load Session</button>
                </div>
                <input type="file" id="file-loader" class="file-input" accept=".json">
            </div>

            <div id="results-panel" class="panel">
                <h2>Results & Analysis</h2>
                <div id="status">Status: Idle. Configure a system and press 'Run'.</div>
                <h3>Best Found Permutation:</h3>
                <pre id="output">---</pre>
                <h3>Best Fitness Score (Closer to 0 is better):</h3>
                <pre id="fitness">---</pre>
                <h3>Final Ratio of Target Characters:</h3>
                <pre id="ratio">---</pre>
            </div>
        </div>
    `;

    // 3. Application Logic
    class GAWorkstation {
        constructor() {
            this.DOM = {
                systemSelect: doc.getElementById('system-select'),
                newSystemBtn: doc.getElementById('new-system-btn'),
                deleteSystemBtn: doc.getElementById('delete-system-btn'),
                systemName: doc.getElementById('system-name'),
                d_value: doc.getElementById('d_value'),
                ratioDisplay: doc.getElementById('ratio-display-output'),
                permLength: doc.getElementById('permLength'),
                populationSize: doc.getElementById('populationSize'),
                numGenerations: doc.getElementById('numGenerations'),
                alphabetG: doc.getElementById('alphabet-g'),
                parentASelect: doc.getElementById('parent-a-select'),
                parentBSelect: doc.getElementById('parent-b-select'),
                alphabetOpSelect: doc.getElementById('alphabet-op-select'),
                composeBtn: doc.getElementById('compose-btn'),
                runBtn: doc.getElementById('run-btn'),
                saveBtn: doc.getElementById('save-btn'),
                loadBtn: doc.getElementById('load-btn'),
                fileLoader: doc.getElementById('file-loader'),
                status: doc.getElementById('status'),
                output: doc.getElementById('output'),
                fitness: doc.getElementById('fitness'),
                ratio: doc.getElementById('ratio')
            };
           
            this.FULL_ALPHABET = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 _'.split('');
            this.state = {
                managedSystems: {},
                activeSystemId: null
            };
           
            this.init();
        }

        init() {
            this.createNewSystem({ name: "Default System d=2" });
            this.bindEventListeners();
        }
       
        bindEventListeners() {
            this.DOM.newSystemBtn.addEventListener('click', () => this.createNewSystem({ name: "New System" }));
            this.DOM.deleteSystemBtn.addEventListener('click', () => this.deleteActiveSystem());
            this.DOM.composeBtn.addEventListener('click', () => this.composeSystem());
            this.DOM.systemSelect.addEventListener('change', (e) => this.setActiveSystem(e.target.value));
            this.DOM.d_value.addEventListener('input', () => this.updateRatioDisplay());

            this.DOM.runBtn.addEventListener('click', () => this.runEvolution());
            this.DOM.saveBtn.addEventListener('click', () => this.saveSession());
            this.DOM.loadBtn.addEventListener('click', () => this.DOM.fileLoader.click());
            this.DOM.fileLoader.addEventListener('change', (e) => this.loadSession(e));

            const inputs = doc.querySelectorAll('#controls-panel input, #controls-panel textarea');
            inputs.forEach(input => {
                input.addEventListener('change', () => this.updateSystemFromUI());
            });
        }

        createNewSystem(options = {}) {
            const newId = `system_${Date.now()}`;
            const newSystem = {
                id: newId,
                name: options.name || "Composed System",
                createdAt: new Date().toISOString(),
                config: options.config || {
                    d_value: 2,
                    permLength: 50,
                    populationSize: 100,
                    numGenerations: 100,
                    mutationRate: 0.02,
                    elitismRate: 0.1,
                    alphabetG: "abcdefghijklm"
                },
                results: null
            };
            this.state.managedSystems[newId] = newSystem;
            this.updateSystemSelects();
            this.setActiveSystem(newId);
        }

        setActiveSystem(id) {
            if (!this.state.managedSystems[id]) return;
            this.state.activeSystemId = id;
            this.updateUIFromState();
            this.DOM.systemSelect.value = id;
        }
       
        deleteActiveSystem() {
            if (Object.keys(this.state.managedSystems).length <= 1) {
                gosApiProxy.ui.showNotification('Action Denied', 'Cannot delete the last system.', 3000);
                return;
            }
            delete this.state.managedSystems[this.state.activeSystemId];
            this.updateSystemSelects();
            const newActiveId = Object.keys(this.state.managedSystems)[0];
            this.setActiveSystem(newActiveId);
        }

        updateSystemSelects() {
            const selects = [this.DOM.systemSelect, this.DOM.parentASelect, this.DOM.parentBSelect];
            const currentSystemValue = this.DOM.systemSelect.value;
            selects.forEach(sel => sel.innerHTML = '');
           
            for (const id in this.state.managedSystems) {
                const system = this.state.managedSystems[id];
                const option = doc.createElement('option');
                option.value = id;
                option.textContent = system.name;
                selects.forEach(sel => sel.appendChild(option.cloneNode(true)));
            }
           
            this.DOM.systemSelect.value = currentSystemValue;
            if (this.DOM.parentASelect.options.length > 0) this.DOM.parentASelect.selectedIndex = 0;
            if (this.DOM.parentBSelect.options.length > 1) this.DOM.parentBSelect.selectedIndex = 1;
        }

        updateUIFromState() {
            const system = this.state.managedSystems[this.state.activeSystemId];
            if (!system) return;
           
            this.DOM.systemName.value = system.name;
            this.DOM.d_value.value = system.config.d_value;
            this.DOM.permLength.value = system.config.permLength;
            this.DOM.populationSize.value = system.config.populationSize;
            this.DOM.numGenerations.value = system.config.numGenerations;
            this.DOM.alphabetG.value = system.config.alphabetG;
            this.updateRatioDisplay();
           
            if (system.results) {
                this.DOM.output.textContent = system.results.bestPermutation;
                this.DOM.fitness.textContent = system.results.bestFitness.toExponential(4);
                this.DOM.ratio.textContent = `${system.results.finalRatio.toFixed(4)} (Target: ${system.results.targetRatio.toFixed(4)})`;
            } else {
                this.DOM.output.textContent = "---";
                this.DOM.fitness.textContent = "---";
                this.DOM.ratio.textContent = "---";
            }
        }

        updateSystemFromUI() {
            const system = this.state.managedSystems[this.state.activeSystemId];
            if (!system) return;

            system.name = this.DOM.systemName.value;
            system.config.d_value = parseInt(this.DOM.d_value.value, 10);
            system.config.permLength = parseInt(this.DOM.permLength.value, 10);
            system.config.populationSize = parseInt(this.DOM.populationSize.value, 10);
            system.config.numGenerations = parseInt(this.DOM.numGenerations.value, 10);
            system.config.alphabetG = this.DOM.alphabetG.value;
           
            this.updateSystemSelects();
            this.updateRatioDisplay();
        }

        updateRatioDisplay() {
            const d = parseInt(this.DOM.d_value.value, 10);
            if (isNaN(d) || d < 2) {
                this.DOM.ratioDisplay.textContent = "Invalid 'd' value.";
                return;
            }
            const denominator = 1 + Math.pow(d, 3);
            const ratio = 1 / denominator;
            this.DOM.ratioDisplay.textContent = `Target Ratio: 1/${denominator} (${(ratio * 100).toFixed(2)}%)`;
        }
       
        composeSystem() {
            const parentAId = this.DOM.parentASelect.value;
            const parentBId = this.DOM.parentBSelect.value;

            if (parentAId === parentBId) {
                gosApiProxy.ui.showNotification('Error', 'Please select two different parent systems.', 4000);
                return;
            }

            const parentA = this.state.managedSystems[parentAId];
            const parentB = this.state.managedSystems[parentBId];
           
            const newConfig = {
                d_value: Math.round((parentA.config.d_value + parentB.config.d_value) / 2),
                permLength: Math.round((parentA.config.permLength + parentB.config.permLength) / 2),
                populationSize: Math.round((parentA.config.populationSize + parentB.config.populationSize) / 2),
                numGenerations: Math.round((parentA.config.numGenerations + parentB.config.numGenerations) / 2),
                mutationRate: 0.02,
                elitismRate: 0.1,
                alphabetG: ""
            };

            const setA = new Set(parentA.config.alphabetG.split(''));
            const setB = new Set(parentB.config.alphabetG.split(''));
            const op = this.DOM.alphabetOpSelect.value;
            let resultSet = (op === 'union') ? new Set([...setA, ...setB]) : new Set([...setA].filter(x => setB.has(x)));
            newConfig.alphabetG = [...resultSet].sort().join('');
           
            const newName = `Composition of ${parentA.name} & ${parentB.name}`;
            this.createNewSystem({ name: newName, config: newConfig });
        }

        saveSession() {
            const system = this.state.managedSystems[this.state.activeSystemId];
            if (!system) return;
            const sessionData = JSON.stringify(system, null, 2);
            const schemaData = JSON.stringify(this.generateSchema(system), null, 2);
            this.downloadFile(sessionData, `${system.name.replace(/\s/g, '_')}.session.json`);
            this.downloadFile(schemaData, `${system.name.replace(/\s/g, '_')}.schema.json`);
        }

        loadSession(event) {
            const file = event.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const loadedSystem = JSON.parse(e.target.result);
                    if (loadedSystem.id && loadedSystem.name && loadedSystem.config) {
                        this.state.managedSystems[loadedSystem.id] = loadedSystem;
                        this.updateSystemSelects();
                        this.setActiveSystem(loadedSystem.id);
                    } else { gosApiProxy.ui.showNotification('Error', 'Invalid session file format.', 4000); }
                } catch (error) { gosApiProxy.ui.showNotification('Error', 'Error parsing JSON file: ' + error.message, 5000); }
            };
            reader.readAsText(file);
            this.DOM.fileLoader.value = '';
        }
       
        downloadFile(content, fileName) {
            const a = window.parent.document.createElement("a");
            const file = new Blob([content], {type: 'application/json'});
            a.href = URL.createObjectURL(file);
            a.download = fileName;
            window.parent.document.body.appendChild(a);
            a.click();
            window.parent.document.body.removeChild(a);
            URL.revokeObjectURL(a.href);
        }

        generateSchema(system) {
            const { results, config } = system;
            const schema = {
                "$schema": "http://json-schema.org/draft-07/schema#",
                title: "Genetic Algorithm Session Schema",
                description: "Describes the structure and semantic context of a GA workstation session file.",
                type: "object",
                properties: {
                    id: { type: "string", description: "Unique identifier for the system session." },
                    name: { type: "string", description: "User-defined name for the system." },
                    createdAt: { type: "string", format: "date-time", description: "ISO 8601 timestamp." },
                    config: {
                        type: "object",
                        properties: {
                            d_value: { type: "integer", description: "The 'd' dimension for the 1:d^3 ratio." },
                            permLength: { type: "integer" },
                            populationSize: { type: "integer" },
                            numGenerations: { type: "integer" },
                            alphabetG: { type: "string" }
                        }
                    },
                    results: {
                        type: "object",
                        properties: {
                            bestPermutation: { type: "string" },
                            bestFitness: { type: "number" },
                            finalRatio: { type: "number" },
                            targetRatio: { type: "number" },
                            fitnessHistory: { type: "array" },
                            runDurationMs: { type: "integer" }
                        },
                        statistics: results ? {
                            initialFitness: results.fitnessHistory[0],
                            finalFitness: results.fitnessHistory[results.fitnessHistory.length - 1],
                            maxImprovement: results.fitnessHistory[0] - results.fitnessHistory[results.fitnessHistory.length - 1],
                            averageFitness: results.fitnessHistory.reduce((a, b) => a + b, 0) / results.fitnessHistory.length
                        } : null
                    }
                }
            };
            return schema;
        }

        async runEvolution() {
            this.DOM.runBtn.disabled = true; this.DOM.runBtn.textContent = "Evolving...";
            const startTime = performance.now();
            const activeSystem = this.state.managedSystems[this.state.activeSystemId];
            const { config } = activeSystem;

            const d = config.d_value;
            const TARGET_RATIO = 1 / (1 + Math.pow(d, 3));

            const ALPHABET_G_SET = new Set(config.alphabetG.split(''));
            const calculateFitness = p => Math.abs(([...p].filter(c => ALPHABET_G_SET.has(c)).length / p.length) - TARGET_RATIO);
            const createIndividual = len => Array.from({ length: len }, () => this.FULL_ALPHABET[Math.floor(Math.random() * this.FULL_ALPHABET.length)]).join('');
           
            let population = Array.from({ length: config.populationSize }, () => createIndividual(config.permLength));
            let bestOverall = { permutation: '', fitness: Infinity };
            const fitnessHistory = [];

            for (let gen = 0; gen < config.numGenerations; gen++) {
                let ratedPop = population.map(p => ({ p, fitness: calculateFitness(p) })).sort((a, b) => a.fitness - b.fitness);
                if (ratedPop[0].fitness < bestOverall.fitness) bestOverall = { permutation: ratedPop[0].p, fitness: ratedPop[0].fitness };
                fitnessHistory.push(bestOverall.fitness);

                if (gen % 10 === 0 || gen === config.numGenerations - 1) {
                    this.DOM.status.textContent = `Status: Evolving... Gen ${gen + 1}/${config.numGenerations}`;
                    this.DOM.output.textContent = bestOverall.permutation;
                    this.DOM.fitness.textContent = bestOverall.fitness.toExponential(4);
                    const finalRatio = [...bestOverall.permutation].filter(c => ALPHABET_G_SET.has(c)).length / config.permLength;
                    this.DOM.ratio.textContent = `${finalRatio.toFixed(4)} (Target: ${TARGET_RATIO.toFixed(4)})`;
                    await new Promise(r => setTimeout(r, 0));
                }
               
                const newPopulation = ratedPop.slice(0, Math.floor(config.populationSize * config.elitismRate)).map(i => i.p);
                while (newPopulation.length < config.populationSize) {
                    const p1 = ratedPop[Math.floor(Math.random() * ratedPop.length / 2)].p;
                    const p2 = ratedPop[Math.floor(Math.random() * ratedPop.length / 2)].p;
                    const crossPoint = Math.floor(Math.random() * config.permLength);
                    let child = p1.substring(0, crossPoint) + p2.substring(crossPoint);
                    if (Math.random() < config.mutationRate) {
                       const i = Math.floor(Math.random() * config.permLength);
                       const char = this.FULL_ALPHABET[Math.floor(Math.random() * this.FULL_ALPHABET.length)];
                       child = child.substring(0, i) + char + child.substring(i + 1);
                    }
                    newPopulation.push(child);
                }
                population = newPopulation;
            }
           
            activeSystem.results = {
                bestPermutation: bestOverall.permutation,
                bestFitness: bestOverall.fitness,
                finalRatio: [...bestOverall.permutation].filter(c => ALPHABET_G_SET.has(c)).length / config.permLength,
                targetRatio: TARGET_RATIO,
                fitnessHistory: fitnessHistory,
                runDurationMs: Math.round(performance.now() - startTime)
            };
           
            this.DOM.status.textContent = `Status: Evolution complete in ${activeSystem.results.runDurationMs}ms.`;
            this.DOM.runBtn.disabled = false; this.DOM.runBtn.textContent = "▶️ Run Active System";
        }
    }

    new GAWorkstation();
}

