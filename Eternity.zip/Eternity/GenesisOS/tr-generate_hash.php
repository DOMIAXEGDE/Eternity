<?php
// Replace with the strong password you want to use.
echo password_hash('pwd', PASSWORD_DEFAULT);
?>