/**
 * @file fsm_pipeline.cpp
 * @brief A dynamic, range-based FSM for pipelined permutation lookups.
 *
 * @details
 * This program implements a streaming Finite State Machine (FSM) that
 * processes two input files (rule and data) to generate a sequence of outputs
 * based on a third set of files (the word directory).
 *
 * It operates based on the following new principles:
 *
 * 1. Rule Ranging: The FSM is initialized with a specific line range
 * (e.g., lines 1000-2000) from the <rule_file>. Only this "chunk"
 * of '0's and '1's is used as the FSM's transition logic, looping
 * within that chunk as needed.
 *
 * 2. Dynamic Lengths: The FSM no longer targets a specific digit length.
 * Instead, it collects digits ('1', '14', '147', '1472', ...)
 * from the <data_file> whenever the rule chunk "accepts" ('1').
 *
 * 3. Dynamic Lookup: After *every* accepted digit, the FSM checks its
 * current collected digit string.
 * - Let collected_digits = "147" (length 3).
 * - It checks if a file exists: <words_dir>/permutations_len_3.txt
 *
 * 4. Fallback Logic:
 * - If the file does NOT exist: The FSM continues. It will
 * collect the next digit (e.g., "1472") and try again.
 * - If the file DOES exist: The FSM attempts a lookup.
 * - On Success: (Line 147 exists) -> The word ("foo") is used.
 * - On Failure: (Line 147 is out of range) -> The *integer*
 * ("147") is used as a fallback.
 *
 * 5. Pipelining:
 * - When an output (word or integer) is successfully generated,
 * it is appended to the final output string, followed by the
 * <delimiter>.
 * - The FSM's digit buffer is cleared, and it begins collecting
 * a new number.
 * - This repeats until <num_outputs_to_generate> have been found.
 *
 * compile: g++ -std=c++17 -o fsm_pipeline fsm_pipeline.cpp
 *
 * Usage:
 * ./fsm_pipeline <rule_file> <rule_start> <rule_end> <data_file> <words_dir> <output_dir> <delimiter> <num_outputs>
 *
 * Example:
 * ./fsm_pipeline ./binary/permutations_len_8.txt 0 10000 ./numbers/permutations_len_8.txt ./words ./output "_" 10
 *
 * This will:
 * 1. Load lines 0-10000 from the rule file as the FSM logic.
 * 2. Read from the data file, looping as needed.
 * 3. Dynamically try to find lookups in ./words/
 * 4. Generate 10 outputs (words or fallback integers) separated by "_".
 * 5. Save the final string (e.g., "word_123_another_foo") to ./output/result.txt
 */

#include <iostream>
#include <fstream>
#include <string>
#include <stdexcept>
#include <cstdint>
#include <sstream>
#include <filesystem> // For std::filesystem (C++17)
#include <cstdlib>
#include <fstream>

//==============================================================================
// 1. UTILITY FUNCTIONS
//==============================================================================

/**
 * @brief Creates a directory if it does not already exist.
 * @param path The path of the directory to create.
 */
static void create_directory_if_not_exists(const std::string& path) {
    std::error_code ec;
    if (!std::filesystem::create_directory(path, ec) && ec) {
        if (ec != std::errc::file_exists) {
            throw std::runtime_error("Failed to create directory: " + path + " - " + ec.message());
        }
    }
}

/**
 * @brief Reads a specific line from a file (0-based index).
 * @param filepath The path to the file.
 * @param line_index The 0-based line index to retrieve.
 * @param[out] out_line String to store the result.
 * @return true on success, false if line_index is out of range.
 * @throws std::runtime_error if the file cannot be opened.
 */
static bool read_line_from_file(const std::string& filepath, std::uint64_t line_index, std::string& out_line) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open lookup file: " + filepath);
    }

    std::uint64_t current_index = 0;
    while (std::getline(file, out_line)) {
        if (current_index == line_index) {
            file.close();
            return true;
        }
        current_index++;
    }

    file.close();
    return false; // Line index was out of range
}

//==============================================================================
// 2. CORE LOGIC (PermutationFSM)
//==============================================================================

/**
 * @class PermutationFSM
 * @brief Implements the FSM logic for dynamic, pipelined lookups.
 */
class PermutationFSM {
private:
    // Input Streams
    std::ifstream m_data_stream;
    std::string m_data_filepath;
    std::string m_rule_chunk; // Holds the specified range of the rule file
    std::uint64_t m_rule_index = 0; // Cursor for m_rule_chunk

    // Configuration
    std::string m_words_dir;
    std::string m_delimiter;
    std::uint64_t m_num_outputs;

    /**
     * @brief Loads the specified line range from the rule file into memory.
     * @note This concatenates all '0's and '1's from the lines,
     * ignoring newlines within the range.
     */
    void load_rule_chunk(const std::string& rule_file, std::uint64_t start, std::uint64_t end) {
        std::ifstream file(rule_file);
        if (!file.is_open()) {
            throw std::runtime_error("Failed to open rule file: " + rule_file);
        }

        std::string line;
        std::uint64_t current_line = 0;
        std::stringstream ss;

        while (std::getline(file, line)) {
            if (current_line > end) {
                break; // We are past the specified range
            }
            if (current_line >= start) {
                ss << line; // Append the line's content
            }
            current_line++;
        }
        file.close();

        m_rule_chunk = ss.str();
        if (m_rule_chunk.empty()) {
            throw std::runtime_error("Rule chunk is empty. Check rule file and line range.");
        }
    }

    /**
     * @brief Gets the next '0' or '1' from the in-memory rule chunk.
     * @note Loops back to the start of the chunk on (chunk) EOF.
     */
    char get_next_rule_char() {
        if (m_rule_index >= m_rule_chunk.length()) {
            m_rule_index = 0; // Loop back to start
        }
        return m_rule_chunk[m_rule_index++];
    }

    /**
     * @brief Gets the next valid digit from the data stream.
     * @note Skips newlines and loops back to the start on (file) EOF.
     */
    char get_next_data_char() {
        char c;
        while (true) {
            if (m_data_stream.get(c)) {
                if (c == '\n' || c == '\r') {
                    continue; // Skip newlines
                }
                return c; // Got a valid character
            } else {
                // Reached End-of-File
                m_data_stream.clear();  // Clear EOF flags
                m_data_stream.seekg(0); // Rewind to the beginning of the file
            }
        }
    }

    /**
     * @brief Checks if a lookup file exists for the given length and,
     * if so, attempts to find the word.
     * @param digits The collected digit string (e.g., "147").
     * @return The found word, the fallback integer string, or an
     * empty string (if no file exists yet).
     */
    std::string attempt_lookup(const std::string& digits) {
        std::uint64_t len = digits.length();
        if (len == 0) {
            return ""; // Should not happen, but safe to check
        }

        // 1. Check if the required word file exists
        std::string word_filepath = m_words_dir + "/permutations_len_" + std::to_string(len) + ".txt";

        if (!std::filesystem::exists(word_filepath)) {
            return ""; // File does not exist for this length. Keep collecting.
        }

        // 2. File exists. Attempt the lookup.
        try {
            std::uint64_t line_index = std::stoull(digits);
            std::string result_word;

            if (read_line_from_file(word_filepath, line_index, result_word)) {
                // Success: Word was found
                return result_word;
            } else {
                // Failure: Line index out of range. Use fallback.
                return digits;
            }
        }
        catch (const std::exception& e) {
            // Failure: e.g., stoull overflow ("999...999"). Use fallback.
            return digits;
        }
    }

public:
    PermutationFSM(
        const std::string& rule_file,
        std::uint64_t rule_start,
        std::uint64_t rule_end,
        const std::string& data_file,
        const std::string& words_dir,
        const std::string& delimiter,
        std::uint64_t num_outputs)
        : m_data_filepath(data_file),
          m_words_dir(words_dir),
          m_delimiter(delimiter),
          m_num_outputs(num_outputs) {
        
        // 1. Load the rule chunk
        load_rule_chunk(rule_file, rule_start, rule_end);

        // 2. Open the data stream
        m_data_stream.open(m_data_filepath);
        if (!m_data_stream.is_open()) {
            throw std::runtime_error("Failed to open data file: " + m_data_filepath);
        }
    }

    ~PermutationFSM() {
        if (m_data_stream.is_open()) {
            m_data_stream.close();
        }
    }

    /**
     * @brief Runs the main FSM pipeline.
     * @return The final, concatenated output string.
     */
    std::string run_pipeline() {
        std::stringstream final_output_ss;
        std::string collected_digits;
        std::uint64_t outputs_generated = 0;

        while (outputs_generated < m_num_outputs) {
            // State: Get inputs
            char rule_c = get_next_rule_char();
            char data_c = get_next_data_char();

            // FSM Logic
            if (rule_c == '1') {
                // State: Accept
                collected_digits.push_back(data_c);

                // Action: Try to resolve the new digit string
                std::string result_item = attempt_lookup(collected_digits);

                if (!result_item.empty()) {
                    // A lookup was successful (found word or fallback int)
                    
                    if (outputs_generated > 0) {
                        final_output_ss << m_delimiter;
                    }
                    final_output_ss << result_item;
                    
                    outputs_generated++;
                    collected_digits.clear(); // Reset for next item
                }
                // else (result_item is empty)
                //   File for this length didn't exist.
                //   Do nothing; loop will continue collecting.
            }
            // else (rule_c == '0')
            //   State: Reject
            //   Action: Do nothing.
        }

        return final_output_ss.str();
    }

    // Disable copy and assignment
    PermutationFSM(const PermutationFSM&) = delete;
    PermutationFSM& operator=(const PermutationFSM&) = delete;
};

//==============================================================================
// 3. SYSTEM ASSEMBLER (main)
//==============================================================================

static void print_usage(const char* program_name) {
    std::cerr << "Usage: " << program_name
              << " <rule_file> <rule_start_line> <rule_end_line> <data_file>"
              << " <words_dir> <output_dir> <delimiter> <num_outputs_to_generate>\n\n"
              << "Example: " << program_name
              << " ./binary/permutations_len_8.txt 0 10000"
              << " ./numbers/permutations_len_8.txt"
              << " ./words ./output \"_\" 10\n\n"
              << "This generates 10 outputs (words or integers) separated by \"_\".\n";
}

int main(int argc, char* argv[]) {
    // --- DEBUG: basic lifecycle logging ---
    {
        std::ofstream dbg("fsm_debug.txt", std::ios::app);
        dbg << "fsm_pipeline started. argc = " << argc << "\n";
    }

    // --- 1. Argument Validation ---
    if (argc != 9) {
        {
            std::ofstream dbg("fsm_debug.txt", std::ios::app);
            dbg << "argc != 9, calling print_usage and exiting.\n";
        }
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }

    // --- 2. Parse Runtime Parameters ---
    try {
        std::string rule_file = argv[1];
        std::uint64_t rule_start = std::stoull(argv[2]);
        std::uint64_t rule_end   = std::stoull(argv[3]);
        std::string data_file    = argv[4];
        std::string words_dir    = argv[5];
        std::string output_dir   = argv[6];
        std::string delimiter    = argv[7];
        std::uint64_t num_outputs = std::stoull(argv[8]);

        {
            std::ofstream dbg("fsm_debug.txt", std::ios::app);
            dbg << "Parsed args OK. rule_file = " << rule_file
                << ", data_file = " << data_file
                << ", num_outputs = " << num_outputs << "\n";
        }

        // --- 3. Safety Checks ---
        if (rule_end < rule_start) {
            throw std::invalid_argument("rule_end_line must be >= rule_start_line.");
        }
        if (num_outputs == 0) {
            throw std::invalid_argument("num_outputs_to_generate must be > 0.");
        }

        // --- 4. System Assembly & Execution ---
        std::cout << "Initializing FSM Pipeline...\n"
                  << "  Rule File: " << rule_file << "\n"
                  << "  Rule Range: " << rule_start << " to " << rule_end << "\n"
                  << "  Data File: " << data_file << "\n"
                  << "  Words Dir: " << words_dir << "\n"
                  << "  Output Dir: " << output_dir << "\n"
                  << "  Delimiter: \"" << delimiter << "\"\n"
                  << "  Target Outputs: " << num_outputs << "\n\n";

        // a. Instantiate FSM (loads rule chunk, opens data file)
        PermutationFSM fsm(
            rule_file, rule_start, rule_end,
            data_file, words_dir, delimiter, num_outputs
        );

        // b. Run the pipeline
        std::cout << "Running pipeline to generate " << num_outputs << " outputs..." << std::flush;
        std::string final_output_string = fsm.run_pipeline();
        std::cout << " Done.\n";

        // c. Write the result to the output file
        create_directory_if_not_exists(output_dir);
        std::string output_filepath = output_dir + "/result.txt";

        std::ofstream out_stream(output_filepath, std::ios::out | std::ios::trunc);
        if (!out_stream.is_open()) {
            throw std::runtime_error("Failed to open output file: " + output_filepath);
        }
        out_stream << final_output_string << std::endl;
        out_stream.close();

        std::cout << "\nResult successfully saved to: " << output_filepath << "\n"
                  << "Output String: " << final_output_string.substr(0, 200) << "...\n";

    } catch (const std::exception& e) {
        {
            std::ofstream dbg("fsm_debug.txt", std::ios::app);
            dbg << "Exception caught: " << e.what() << "\n";
        }

        std::cerr << "\n\n--- A fatal error occurred ---\n"
                  << "Error: " << e.what() << "\n";
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
