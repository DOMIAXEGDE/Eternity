# Converts selected text-based files into KDP-ready PDFs (8.25" x 11")
# with a left/right gutter column for line numbers (mirrored margins).
#
# Target: KDP 8.25" x 11" (no bleed), ~424 pages.
#
# This version uses *wide* margins for a more spacious layout:
#   - Inside (gutter): 1.0"
#   - Outside (other horizontal edge): 0.875"
#   - Top: 1.0"
#   - Bottom: 1.0"
#
# Mirroring:
#   - Odd pages  (right-hand):  inside on LEFT, outside on RIGHT
#   - Even pages (left-hand):   inside on RIGHT, outside on LEFT
#
# Supported file types (case-insensitive):
#   .css, .cmd, .env, .gitignore, .js, .php, .hpp, .cpp, .md, .py, .txt, .ps1, .json, .html
#
# Output: ./docpdf/<basename>.pdf
#
# Usage:
#   pip install reportlab
#   python make_docs_pdf.py

RECURSIVE = False        # set True to scan subfolders
INCLUDE_DOTFILES = True  # include dotfiles like .gitignore, .env

import os
import io
import textwrap
from typing import List, Tuple

from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics

# --------------------------------------------------------------------
# PAGE + MARGINS (KDP 8.25" x 11", WIDE)
# --------------------------------------------------------------------
DPI = 72  # PDF points per inch

TRIM_WIDTH_IN = 8.25
TRIM_HEIGHT_IN = 11.0
PAGE_SIZE = (TRIM_WIDTH_IN * DPI, TRIM_HEIGHT_IN * DPI)  # 8.25" x 11"

# Wide but KDP-safe margins
INSIDE_MARGIN_IN = 1.0     # gutter (spine side)
OUTSIDE_MARGIN_IN = 0.875  # other horizontal edge
TOP_MARGIN_IN = 1.0
BOTTOM_MARGIN_IN = 1.0

INSIDE_MARGIN = INSIDE_MARGIN_IN * DPI
OUTSIDE_MARGIN = OUTSIDE_MARGIN_IN * DPI
MARGIN_TOP = TOP_MARGIN_IN * DPI
MARGIN_BOTTOM = BOTTOM_MARGIN_IN * DPI

# Gutter column for line numbers
GUTTER_WIDTH = 0.6 * DPI   # reserved column width
GUTTER_GAP = 0.15 * DPI    # gap between gutter and text

# Header/Footer band heights
HEADER_HEIGHT = 0.4 * DPI
FOOTER_HEIGHT = 0.4 * DPI

# Typography
FONT_NAME = "Courier"  # built-in monospaced font
FONT_SIZE = 10
LINE_LEADING = 1.2     # line spacing multiplier

OUTPUT_DIR = "docpdf"

# Supported extensions and special filenames
EXTS = {
    ".css", ".cmd", ".js", ".php", ".hpp", ".cpp", ".md",
    ".py", ".txt", ".ps1", ".json", ".html", "json"  # include bare 'json' just in case
}
SPECIAL_FILES = {".gitignore", ".env"}


def is_supported_file(path: str) -> bool:
    name = os.path.basename(path)
    lower = name.lower()
    # include special dotfiles regardless of extension
    if lower in SPECIAL_FILES and INCLUDE_DOTFILES:
        return True
    # include if extension matches supported list
    _, ext = os.path.splitext(lower)
    if ext in EXTS or (lower.endswith("json") and ".json" not in ext):
        return True
    return False


def iter_candidate_files(root: str = ".") -> List[str]:
    files = []
    if RECURSIVE:
        for dirpath, _, filenames in os.walk(root):
            for fn in filenames:
                full = os.path.join(dirpath, fn)
                if os.path.isfile(full) and is_supported_file(full):
                    files.append(full)
    else:
        for fn in os.listdir(root):
            full = os.path.join(root, fn)
            if os.path.isfile(full) and is_supported_file(full):
                files.append(full)
    return files


def numeric_key(file: str):
    """Numeric-aware sort: if basename (without ext) is an int, sort by int; else alpha."""
    base = os.path.basename(file)
    stem, _ = os.path.splitext(base)
    try:
        return (0, int(stem))
    except ValueError:
        return (1, base.lower())


def measure_char_width() -> float:
    """Width of one monospaced character in chosen font/size."""
    return pdfmetrics.stringWidth("M", FONT_NAME, FONT_SIZE)


def wrap_text_line(line: str, max_chars: int) -> List[str]:
    """Soft-wrap a line to max_chars; tabs -> 4 spaces; keep spacing."""
    line = line.replace("\t", "    ").rstrip("\n\r")
    if max_chars <= 0:
        return [line]
    wrapped = textwrap.wrap(
        line,
        width=max_chars,
        break_long_words=True,
        replace_whitespace=False,
        drop_whitespace=False,
    )
    return wrapped if wrapped else [""]


def draw_header_footer(
    c: canvas.Canvas,
    width: float,
    height: float,
    title: str,
    page_num: int,
    margin_left: float,
    margin_right: float,
):
    """Header: title near left margin, page number near right margin.
       Footer: centered credit line."""
    c.setFont(FONT_NAME, 9)

    # Header
    y_header = height - MARGIN_TOP + (HEADER_HEIGHT / 2) - 3
    c.drawString(margin_left, y_header, title[:120])
    c.drawRightString(width - margin_right, y_header, f"Page {page_num}")

    # Footer
    y_footer = MARGIN_BOTTOM / 2
    c.drawCentredString(
        width / 2,
        y_footer,
        "Prompt Engineered by Dominic Alexander Cooper Cert HE (Open) 2025",
    )


def create_pdf_for_textfile(src_path: str):
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    base = os.path.basename(src_path)
    stem, _ = os.path.splitext(base)
    out_path = os.path.join(OUTPUT_DIR, f"{stem}.pdf")

    # Read file as UTF-8 (replace invalid)
    with io.open(src_path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()

    c = canvas.Canvas(out_path, pagesize=PAGE_SIZE)
    width, height = PAGE_SIZE

    char_w = measure_char_width()
    line_h = FONT_SIZE * LINE_LEADING

    # Frame geometry that doesn't depend on left/right swapping
    y_top = height - MARGIN_TOP - HEADER_HEIGHT
    y_bottom = MARGIN_BOTTOM + FOOTER_HEIGHT

    # text frame width is the same on odd/even pages:
    frame_width = width - (INSIDE_MARGIN + OUTSIDE_MARGIN + GUTTER_WIDTH + GUTTER_GAP)
    max_chars = int(frame_width // char_w)

    # Will be set per page in start_page()
    x_text_left = x_text_right = 0.0
    x_gutter_left = x_gutter_right = 0.0

    c.setFont(FONT_NAME, FONT_SIZE)

    def start_page(page_no: int, title: str):
        nonlocal x_text_left, x_text_right, x_gutter_left, x_gutter_right

        is_odd = (page_no % 2 == 1)

        if is_odd:
            # Odd pages: inside on LEFT, outside on RIGHT
            margin_left = INSIDE_MARGIN
            margin_right = OUTSIDE_MARGIN

            x_gutter_left = margin_left
            x_gutter_right = x_gutter_left + GUTTER_WIDTH
            x_text_left = x_gutter_right + GUTTER_GAP
            x_text_right = width - margin_right
        else:
            # Even pages: inside on RIGHT, outside on LEFT
            margin_left = OUTSIDE_MARGIN
            margin_right = INSIDE_MARGIN

            x_text_left = margin_left
            x_gutter_right = width - margin_right
            x_gutter_left = x_gutter_right - GUTTER_WIDTH
            x_text_right = x_gutter_left - GUTTER_GAP

        draw_header_footer(
            c,
            width,
            height,
            title=title,
            page_num=page_no,
            margin_left=margin_left,
            margin_right=margin_right,
        )

        c.setLineWidth(0.5)
        # vertical line separating gutter from text
        c.line(x_gutter_right, height - MARGIN_TOP, x_gutter_right, y_bottom)

        return y_top

    page_no = 1
    y = start_page(page_no, title=os.path.relpath(src_path))
    page_no += 1

    lineno = 1
    for raw in lines:
        wrapped = wrap_text_line(raw, max_chars=max_chars)
        for i, seg in enumerate(wrapped):
            if y - line_h < y_bottom:
                c.showPage()
                y = start_page(page_no, title=os.path.relpath(src_path))
                page_no += 1
            # gutter number only on first visual segment
            num_str = f"{lineno:>5}" if i == 0 else ""
            if num_str:
                c.drawRightString(x_gutter_right - 3, y, num_str)
            c.drawString(x_text_left, y, seg)
            y -= line_h
        lineno += 1

    c.save()
    return out_path


def main():
    files = iter_candidate_files(".")
    files.sort(key=numeric_key)
    if not files:
        print("No supported files found.")
        return

    outputs: List[Tuple[str, str]] = []
    for path in files:
        try:
            out = create_pdf_for_textfile(path)
            outputs.append((path, out))
        except Exception as e:
            print(f"Skipped {path}: {e}")

    print("Generated PDFs:")
    for src, out in outputs:
        print(f"  {src} -> {out}")


if __name__ == "__main__":
    main()
