// extend/tr-programming.js — TR programming quick manual (classic, v1.0.3)
// Works without ESM. Provides :docs and contributes a help line.

(function () {
  function register(tr) {
    const manual = [
      "GENESIS OS — TR PROGRAMMING MANUAL (concise)",
      "",
      "OVERVIEW",
      "  TR Terminal is an extensible REPL. Packages (.js) live in /extend/",
      "  alongside tr-terminal-config.json.",
      "",
      "FILES & LAYOUT",
      "  /apps/tr-terminal.json",
      "  /apps/tr-terminal.js",
      "  /apps/extend/tr-terminal-config.json",
      "  /apps/extend/tr-programming.js   (this package)",
      "",
      "CONFIG SCHEMA (tr-terminal-config.json)",
      "  {",
      "    version: \"1.0.0\",",
      "    installed: {",
      "      name: { filename, enabled, type, hash, installedAt, updatedAt }",
      "    },",
      "    order: [\"name1\", \"name2\", ...]",
      "  }",
      "",
      "WRITING A PACKAGE (classic)",
      "  window.trTerminalPackage = {",
      "    register(tr){ tr.registerCommand('hello', (argv, api)=>api.print('hi')); }",
      "  };",
      "",
      "PACKAGE API",
      "  tr.registerCommand(name, fn)      # add :name",
      "  tr.unregisterCommand(name)        # remove",
      "  tr.api.print(text, cls?)          # ok|err|muted",
      "  tr.api.getState()                 # { admin, version, config }",
      "  tr.api.getConfig()",
      "  tr.api.setConfig(cb)",
      "  tr.api.saveConfig()",
      "  tr.api.fetchSelf(file)",
      "  tr.api.addAlias(alias, target)",
      "",
      "ADMIN WORKFLOW",
      "  :admin on • :install • :enable/:disable <name> • :uninstall <name> • :reload",
      "  :config export|import|reset",
      "",
      "QUICK TEST",
      "  :docs     # show this manual",
      "",
      "END."
    ].join("\n");  // ← real newlines

    tr.registerCommand("docs", (_argv, api) => api.print(manual));
    tr.api.addAlias("manual", "docs");

    try {
      const g = (typeof window !== "undefined" ? window : globalThis);
      if (!g.__trHelpAdditions) g.__trHelpAdditions = [];
      const line = "  :docs                       Show the TR programming manual (from tr-programming)";
      if (!g.__trHelpAdditions.includes(line)) g.__trHelpAdditions.push(line);
    } catch (_) {}

    tr.api.print("Tip: :docs — TR programming manual (from tr-programming)", "muted");
  }

  window.trTerminalPackage = { register };
})();
