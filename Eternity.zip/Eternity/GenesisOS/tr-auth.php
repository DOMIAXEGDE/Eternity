<?php
session_start();

// --- CONFIGURATION ---
// The username for the workbench administrator.
define('ADMIN_USERNAME', 'tr_admin');

// IMPORTANT: Replace this placeholder with a securely generated password hash.
// To generate a hash, run this PHP code once:
//echo password_hash('00EITA00', PASSWORD_DEFAULT);
define('ADMIN_PASSWORD_HASH', '$2y$10$zLx57y0qXPte0k9oaISIXu.JgDkBSayk2TL0foJry0aGtGrtRfmLy');
// --- END CONFIGURATION ---

/**
 * Checks if the current user is authenticated.
 * @return bool True if logged in, false otherwise.
 */
function isLoggedIn(): bool {
    return isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] === true;
}

/**
 * Attempts to log a user in.
 * @param string $username The submitted username.
 * @param string $password The submitted password.
 * @return bool True on successful login, false otherwise.
 */
function login(string $username, string $password): bool {
    if ($username === ADMIN_USERNAME && password_verify($password, ADMIN_PASSWORD_HASH)) {
        // Regenerate session ID to prevent session fixation attacks.
        session_regenerate_id(true);
        $_SESSION['is_logged_in'] = true;
        return true;
    }
    return false;
}

/**
 * Logs the current user out by destroying the session.
 */
function logout(): void {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}