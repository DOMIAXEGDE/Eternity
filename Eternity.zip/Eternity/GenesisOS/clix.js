// clix.js
export function initialize(gosApiProxy) {
    const container = gosApiProxy.window.getContainer();
    const doc = container.ownerDocument;

    // make the OS sandbox box behave like a normal full-height panel
    container.style.display = 'flex';
    container.style.flexDirection = 'column';
    container.style.width = '100%';
    container.style.height = '100%';  // parent window has a height, so we use it
    container.style.minHeight = '0';   // allow children to scroll
    container.style.overflow = 'hidden';
    // 1) inject scoped styles (based on original clix-repl.html) :contentReference[oaicite:5]{index=5}
    const style = doc.createElement('style');
    style.textContent = `
        #clix-app {
            background: #0a0a0a;
            color: #00ff00;
            font-family: 'Consolas', 'Courier New', monospace;
            height: 100vh;            /* ← fill the whole iframe viewport */
            max-height: 100vh;        /* ← don’t grow past it */
            box-sizing: border-box;   /* ← padding won’t push it past 100vh */
            display: flex;
            flex-direction: column;
            min-height: 0;            /* ← lets #terminal scroll */
            overflow: hidden;
        }

        #clix-app #terminal {
            flex: 1 1 0;              /* ← take all remaining space */
            padding: 20px;
            overflow: auto;           /* ← vertical + horizontal */
            background: #000;
            position: relative;
            min-height: 0;            /* ← actually enables scrolling in flex */
            min-width: 0;
        }

        #clix-app .terminal-line {
            white-space: pre;         /* ← no wrapping, so horizontal scroll shows */
            line-height: 1.4;
        }


        #clix-app .terminal-prompt {
            color: #4a9eff;
        }
        #clix-app .terminal-input-line {
            display: flex;
            align-items: flex-start;
        }
        #clix-app .terminal-cursor {
            display: inline-block;
            width: 8px;
            height: 16px;
            background: #00ff00;
            animation: clix-blink 1s infinite;
            margin-left: 2px;
        }
        @keyframes clix-blink {
            0%, 49% { opacity: 1; }
            50%, 100% { opacity: 0; }
        }
        #clix-app #hiddenInput {
            position: absolute;
            left: -9999px;
            opacity: 0;
        }
        #clix-app .error { color: #ff6666; }
        #clix-app .success { color: #66ff66; }
        #clix-app .warning { color: #ffff66; }
        #clix-app .info { color: #6666ff; }
        #clix-app .dim { color: #888; }
        #clix-app .highlight {
            color: #fff;
            background: #333;
            padding: 0 2px;
        }
        #clix-app .header-ascii {
            color: #4a9eff;
            margin-bottom: 10px;
            font-size: 12px;
            line-height: 1.2;
        }
        /* status bar stays at bottom */
        #clix-app .status-bar {
            background: #111;
            border-top: 1px solid #333;
            padding: 5px 20px;
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #888;
            flex: 0 0 auto;
        }

        #clix-app .status-dirty { color: #ffaa00; }
        #clix-app .status-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        #clix-app .file-list {
            background: #111;
            border: 1px solid #333;
            padding: 10px;
            margin: 10px 0;
            max-height: 200px;
            overflow-y: auto;
        }
        #clix-app .file-item {
            padding: 5px;
            cursor: pointer;
            transition: background 0.2s;
        }
        #clix-app .file-item:hover {
            background: #222;
        }
        #clix-app .file-item.selected {
            background: #333;
            color: #4a9eff;
        }
        #clix-app .modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.8);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        #clix-app .modal.active { display: flex; }
        #clix-app .modal-content {
            background: #1a1a1a;
            border: 2px solid #333;
            padding: 20px;
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            color: #00ff00;
        }
        #clix-app .modal-title {
            color: #4a9eff;
            margin-bottom: 15px;
            font-size: 16px;
        }
    `;
    doc.head.appendChild(style);

    // 2) build the same HTML structure as clix-repl.html’s <body> :contentReference[oaicite:6]{index=6}
    container.innerHTML = `
        <div id="clix-app">
            <div id="terminal"></div>
            <div class="status-bar">
                <div class="status-item">
                    <span id="currentBank">No bank loaded</span>
                    <span id="dirtyIndicator"></span>
                </div>
            <div class="status-item">
                <span id="configDisplay">prefix=x base=10</span>
            </div>
            </div>
            <input type="text" id="hiddenInput" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" />
            <a id="downloadLink" download style="display:none;"></a>
            <div class="modal" id="fileModal">
                <div class="modal-content">
                    <div class="modal-title">Select File to Load</div>
                    <div id="fileList" class="file-list"></div>
                    <div style="margin-top: 15px;">
                    <button id="clix-file-cancel">Cancel</button>
                    </div>
                </div>
            </div>

            <div class="modal" id="promptModal">
                <div class="modal-content">
                    <div class="modal-title" id="promptTitle">Input</div>
                    <div style="margin-bottom: 10px;" id="promptMessage">Enter value:</div>
                    <input type="text" id="promptInput" style="width: 100%; background:#000; color:#0f0; border:1px solid #333; padding:4px;" />
                    <div style="margin-top: 15px; display:flex; gap:10px; justify-content:flex-end;">
                    <button id="promptCancel">Cancel</button>
                    <button id="promptOk">OK</button>
                    </div>
                </div>
            </div>


        </div>
    `;

    const root = container.querySelector('#clix-app');

    // ===== Original CLIX classes, slightly adapted to be container-scoped =====
    class ClixConfig {
        constructor() {
            this.prefix = 'x';
            this.base = 10;
            this.width_bank = 5;
            this.width_reg = 2;
            this.width_addr = 4;
            this.allow_duplicate_values = false;
        }
        save() {
            localStorage.setItem('clix_config', JSON.stringify(this));
        }
        load() {
            const saved = localStorage.getItem('clix_config');
            if (saved) Object.assign(this, JSON.parse(saved));
        }
        toIniString() {
            return `prefix = ${this.prefix}
base = ${this.base}
width_bank = ${this.width_bank}
width_reg = ${this.width_reg}
width_addr = ${this.width_addr}
allow_duplicate_values = ${this.allow_duplicate_values}`;
        }
        fromIniString(ini) {
            const lines = ini.split('\n');
            for (const line of lines) {
                const match = line.match(/^\s*(\w+)\s*=\s*(.+)$/);
                if (!match) continue;
                const [, key, value] = match;
                switch (key) {
                    case 'prefix': this.prefix = value.trim(); break;
                    case 'base': this.base = parseInt(value); break;
                    case 'width_bank': this.width_bank = parseInt(value); break;
                    case 'width_reg': this.width_reg = parseInt(value); break;
                    case 'width_addr': this.width_addr = parseInt(value); break;
                    case 'allow_duplicate_values': this.allow_duplicate_values = value.trim() === 'true'; break;
                }
            }
        }
    }

    class ClixBank {
        constructor(id, title = '') {
            this.id = id;
            this.title = title;
            this.registers = {};
        }
        getRegister(regId) {
            if (!this.registers[regId]) this.registers[regId] = {};
            return this.registers[regId];
        }
        setValue(regId, addrId, value) {
            this.getRegister(regId)[addrId] = value;
        }
        getValue(regId, addrId) {
            return this.registers[regId]?.[addrId] || null;
        }
        deleteValue(regId, addrId) {
            if (!this.registers[regId]) return false;
            delete this.registers[regId][addrId];
            if (Object.keys(this.registers[regId]).length === 0) delete this.registers[regId];
            return true;
        }
        formatId(id, base, width) {
            return id.toString(base).padStart(width, '0');
        }
        toString(config) {
            let output = '';
            const bankStr = this.formatId(this.id, config.base, config.width_bank);
            output += `${config.prefix}${bankStr} (${this.title}) {\n`;
            const regIds = Object.keys(this.registers).map(Number).sort((a,b)=>a-b);
            for (const regId of regIds) {
                if (regIds.length > 1 || regId !== 1) {
                    const regStr = this.formatId(regId, config.base, config.width_reg);
                    output += `${regStr}\n`;
                }
                const addresses = this.registers[regId];
                const addrIds = Object.keys(addresses).map(Number).sort((a,b)=>a-b);
                for (const addrId of addrIds) {
                    const addrStr = this.formatId(addrId, config.base, config.width_addr);
                    output += `\t${addrStr}\t${addresses[addrId]}\n`;
                }
            }
            output += '}\n';
            return output;
        }
        static fromString(text, config) {
            const lines = text.split('\n');
            let bank = null;
            let currentReg = 1;
            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed) continue;
                const headerMatch = trimmed.match(new RegExp(`^${config.prefix}([0-9a-zA-Z]+)\\s*\\(([^)]*)\\)\\s*\\{`));
                if (headerMatch) {
                    const id = parseInt(headerMatch[1], config.base);
                    const title = headerMatch[2];
                    bank = new ClixBank(id, title);
                    continue;
                }
                if (trimmed === '}') break;
                if (!bank) continue;
                if (!line.startsWith('\t') && !line.startsWith(' ')) {
                    const regMatch = trimmed.match(/^([0-9a-zA-Z]+)$/);
                    if (regMatch) currentReg = parseInt(regMatch[1], config.base);
                } else {
                    const addrMatch = trimmed.match(/^([0-9a-zA-Z]+)\s+(.+)$/);
                    if (addrMatch) {
                        const addrId = parseInt(addrMatch[1], config.base);
                        const value = addrMatch[2];
                        bank.setValue(currentReg, addrId, value);
                    }
                }
            }
            return bank;
        }
    }

    class ClixWorkspace {
        constructor() {
            this.banks = {};
            this.currentBankId = null;
            this.dirty = false;
            this.config = new ClixConfig();
            this.resolver = new ClixResolver(this);
        }
        getBank(id) { return this.banks[id] || null; }
        createBank(id, title='') {
            const bank = new ClixBank(id, title);
            this.banks[id] = bank;
            this.dirty = true;
            return bank;
        }
        loadBank(id) {
            const key = `clix_bank_${id}`;
            const saved = localStorage.getItem(key);
            if (!saved) return null;
            try {
                const bank = ClixBank.fromString(saved, this.config);
                if (bank) {
                    this.banks[id] = bank;
                    return bank;
                }
            } catch(e) { console.error(e); }
            return null;
        }
        saveBank(id) {
            const bank = this.getBank(id);
            if (!bank) return false;
            const key = `clix_bank_${id}`;
            localStorage.setItem(key, bank.toString(this.config));
            let savedBanks = JSON.parse(localStorage.getItem('clix_saved_banks') || '[]');
            if (!savedBanks.includes(id)) {
                savedBanks.push(id);
                localStorage.setItem('clix_saved_banks', JSON.stringify(savedBanks));
            }
            this.dirty = false;
            return true;
        }
        getValue(b, r, a) {
            const bank = this.getBank(b);
            return bank ? bank.getValue(r,a) : null;
        }
        setValue(b, r, a, value) {
            if (!this.config.allow_duplicate_values && this.checkDuplicate(value)) {
                return { success:false, error:'Duplicate value not allowed' };
            }
            let bank = this.getBank(b);
            if (!bank) bank = this.createBank(b);
            bank.setValue(r,a,value);
            this.dirty = true;
            return { success:true };
        }
        deleteValue(b, r, a) {
            const bank = this.getBank(b);
            if (!bank) return false;
            const res = bank.deleteValue(r,a);
            if (res) this.dirty = true;
            return res;
        }
        checkDuplicate(value) {
            for (const b of Object.values(this.banks)) {
                for (const reg of Object.values(b.registers)) {
                    for (const v of Object.values(reg)) {
                        if (v === value) return true;
                    }
                }
            }
            return false;
        }
        getSavedBanks() {
            const savedBanks = JSON.parse(localStorage.getItem('clix_saved_banks') || '[]');
            return savedBanks.map(id => {
                const bankStr = id.toString(this.config.base).padStart(this.config.width_bank, '0');
                return { id, name: `${this.config.prefix}${bankStr}.txt` };
            });
        }
        exportBank(id) {
            const bank = this.getBank(id);
            if (!bank) return null;
            const content = bank.toString(this.config);
            const bankStr = id.toString(this.config.base).padStart(this.config.width_bank, '0');
            const filename = `${this.config.prefix}${bankStr}.txt`;
            return { filename, content };
        }
        importBankFromText(text) {
            try {
                const bank = ClixBank.fromString(text, this.config);
                if (bank) {
                    this.banks[bank.id] = bank;
                    this.currentBankId = bank.id;
                    this.dirty = true;
                    return bank;
                }
            } catch(e){ console.error(e); }
            return null;
        }
    }

    class ClixResolver {
        constructor(workspace) {
            this.workspace = workspace;
            this.maxDepth = 16;
        }
        resolve(bankId, value, depth=0, visited=new Set()) {
            if (depth >= this.maxDepth) return '[Resolver Depth Exceeded]';
            let output = '';
            let pos = 0;
            const config = this.workspace.config;
            while (pos < value.length) {
                let found = false;
                const remaining = value.substring(pos);

                // pattern: x<bank>.<reg>.<addr>
                const fullRefPattern = new RegExp(`^${config.prefix}([0-9a-zA-Z]+)\\.([0-9a-zA-Z]+)\\.([0-9a-zA-Z]+)`);
                let match = remaining.match(fullRefPattern);
                if (match) {
                    const bId = parseInt(match[1], config.base);
                    const rId = parseInt(match[2], config.base);
                    const aId = parseInt(match[3], config.base);
                    const key = `${bId}.${rId}.${aId}`;
                    if (visited.has(key)) {
                        output += '[Circular Ref]';
                    } else {
                        const refValue = this.workspace.getValue(bId, rId, aId);
                        if (refValue !== null) {
                            const newVisited = new Set(visited);
                            newVisited.add(key);
                            output += this.resolve(bId, refValue, depth+1, newVisited);
                        } else {
                            output += '[Missing Ref]';
                        }
                    }
                    pos += match[0].length;
                    found = true;
                }

                // pattern: r<reg>.<addr> (same bank)
                if (!found) {
                    match = remaining.match(/^r([0-9a-zA-Z]+)\.([0-9a-zA-Z]+)/);
                    if (match) {
                        const rId = parseInt(match[1], config.base);
                        const aId = parseInt(match[2], config.base);
                        const key = `${bankId}.${rId}.${aId}`;
                        if (visited.has(key)) {
                            output += '[Circular Ref]';
                        } else {
                            const refValue = this.workspace.getValue(bankId, rId, aId);
                            if (refValue !== null) {
                                const newVisited = new Set(visited);
                                newVisited.add(key);
                                output += this.resolve(bankId, refValue, depth+1, newVisited);
                            } else {
                                output += '[Missing Ref]';
                            }
                        }
                        pos += match[0].length;
                        found = true;
                    }
                }

                // pattern: <bank>.<reg>.<addr> numeric
                if (!found) {
                    match = remaining.match(/^(\d+)\.(\d+)\.(\d+)/);
                    if (match) {
                        const bId = parseInt(match[1]);
                        const rId = parseInt(match[2]);
                        const aId = parseInt(match[3]);
                        const key = `${bId}.${rId}.${aId}`;
                        if (visited.has(key)) {
                            output += '[Circular Ref]';
                        } else {
                            const refValue = this.workspace.getValue(bId, rId, aId);
                            if (refValue !== null) {
                                const newVisited = new Set(visited);
                                newVisited.add(key);
                                output += this.resolve(bId, refValue, depth+1, newVisited);
                            } else {
                                output += '[Missing Ref]';
                            }
                        }
                        pos += match[0].length;
                        found = true;
                    }
                }

                if (!found) {
                    output += value[pos];
                    pos++;
                }
            }

            return output;
        }
    }

    class ClixREPL {
        constructor(root, doc) {
            this.root = root;
            this.doc = doc;
            this.workspace = new ClixWorkspace();
            this.terminal = root.querySelector('#terminal');
            this.hiddenInput = root.querySelector('#hiddenInput');
            this.commandHistory = [];
            this.historyIndex = -1;
            this.currentInput = '';
            this.inputLine = null;
            this.cursorPosition = 0;
            this.init();
        }

        init() {
            this.workspace.config.load();
            this.printHeader();
            this.printLine('Type <span class="command">:help</span> for commands.', false);
            this.printLine('');
            this.newInputLine();

            // focus management, but scoped
            this.root.addEventListener('click', () => {
                this.hiddenInput.focus();
            });

            this.hiddenInput.addEventListener('input', e => this.handleInput(e));
            this.hiddenInput.addEventListener('keydown', e => this.handleKeyDown(e));
            this.hiddenInput.focus();

            // hook cancel in modal
            const cancelBtn = this.root.querySelector('#clix-file-cancel');
            if (cancelBtn) cancelBtn.addEventListener('click', () => this.closeFileModal());

            this.updateStatusBar();
        }

        printHeader() {
            const header = `<pre class="header-ascii">
   ▄████▄   ██▓     ██▓▒██   ██▒
  ▒██▀ ▀█  ▓██▒    ▓██▒▒▒ █ █ ▒░
  ▒▓█    ▄ ▒██░    ▒██▒░░  █   ░
  ▒▓▓▄ ▄██▒▒██░    ░██░ ░ █ █ ▒ 
  ▒ ▓███▀ ░░██████▒░██░▒██▒ ▒██▒
  ░ ░▒ ▒  ░░ ▒░▓  ░░▓  ▒▒ ░ ░▓ ░
    ░  ▒   ░ ░ ▒  ░ ▒ ░░░   ░▒ ░
  ░          ░ ░    ▒ ░ ░    ░  
  ░ ░          ░  ░ ░   ░    ░  
  ░                              </pre>`;
            this.printLine(header, false);
            this.printLine('<span class="info">CLIX HTML REPL - Safety-Critical Data System</span>', false);
            this.printLine('<span class="dim">Version 1.0.0 - GOS Edition</span>', false);
            this.printLine('');
        }

        printLine(text, escape = true) {
            const line = this.doc.createElement('div');
            line.className = 'terminal-line';
            if (escape) line.textContent = text;
            else line.innerHTML = text;
            this.terminal.appendChild(line);
            this.scrollToBottom();
        }

        scrollToBottom() {
            this.terminal.scrollTop = this.terminal.scrollHeight;
        }

        newInputLine() {
            this.inputLine = this.doc.createElement('div');
            this.inputLine.className = 'terminal-line terminal-input-line';
            this.updateInputLine();
            this.terminal.appendChild(this.inputLine);
            this.scrollToBottom();
        }

        updateInputLine() {
            const prompt = '<span class="terminal-prompt">&gt;&gt;</span> ';
            const beforeCursor = this.escapeHtml(this.currentInput.substring(0, this.cursorPosition));
            const afterCursor = this.escapeHtml(this.currentInput.substring(this.cursorPosition));
            this.inputLine.innerHTML = prompt + beforeCursor + '<span class="terminal-cursor"></span>' + afterCursor;
        }

        escapeHtml(text) {
            const div = this.doc.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        printError(msg) {
            const safe = this.escapeHtml(msg);
            const line = this.doc.createElement('div');
            line.className = 'terminal-line error';
            line.innerHTML = safe;
            this.terminal.appendChild(line);
            this.scrollToBottom();
        }

        handleInput(e) {
            const newChar = e.data;
            if (newChar) {
                this.currentInput = this.currentInput.slice(0, this.cursorPosition) + newChar + this.currentInput.slice(this.cursorPosition);
                this.cursorPosition++;
                this.updateInputLine();
            }
            this.hiddenInput.value = '';
        }

        showPrompt(message, title = 'Input', defaultValue = '', cb) {
            const modal = this.root.querySelector('#promptModal');
            const titleEl = this.root.querySelector('#promptTitle');
            const msgEl = this.root.querySelector('#promptMessage');
            const inputEl = this.root.querySelector('#promptInput');
            const okBtn = this.root.querySelector('#promptOk');
            const cancelBtn = this.root.querySelector('#promptCancel');

            titleEl.textContent = title;
            msgEl.textContent = message;
            inputEl.value = defaultValue || '';
            modal.classList.add('active');
            inputEl.focus();

            const close = () => {
                modal.classList.remove('active');
                okBtn.onclick = null;
                cancelBtn.onclick = null;
            };

            okBtn.onclick = () => {
                const val = inputEl.value;
                close();
                if (cb) cb(val);
            };
            cancelBtn.onclick = () => {
                close();
                if (cb) cb(null);
            };
        }


        handleKeyDown(e) {
            switch (e.key) {
                case 'Enter':
                    e.preventDefault();
                    this.executeCommand();
                    break;
                case 'Backspace':
                    e.preventDefault();
                    if (this.cursorPosition > 0) {
                        this.currentInput = this.currentInput.slice(0, this.cursorPosition - 1) + this.currentInput.slice(this.cursorPosition);
                        this.cursorPosition--;
                        this.updateInputLine();
                    }
                    break;
                case 'Delete':
                    e.preventDefault();
                    if (this.cursorPosition < this.currentInput.length) {
                        this.currentInput = this.currentInput.slice(0, this.cursorPosition) + this.currentInput.slice(this.cursorPosition + 1);
                        this.updateInputLine();
                    }
                    break;
                case 'ArrowLeft':
                    e.preventDefault();
                    if (this.cursorPosition > 0) {
                        this.cursorPosition--;
                        this.updateInputLine();
                    }
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    if (this.cursorPosition < this.currentInput.length) {
                        this.cursorPosition++;
                        this.updateInputLine();
                    }
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    if (this.historyIndex < this.commandHistory.length - 1) {
                        this.historyIndex++;
                        this.currentInput = this.commandHistory[this.commandHistory.length - 1 - this.historyIndex];
                        this.cursorPosition = this.currentInput.length;
                        this.updateInputLine();
                    }
                    break;
                case 'ArrowDown':
                    e.preventDefault();
                    if (this.historyIndex > 0) {
                        this.historyIndex--;
                        this.currentInput = this.commandHistory[this.commandHistory.length - 1 - this.historyIndex];
                        this.cursorPosition = this.currentInput.length;
                        this.updateInputLine();
                    } else if (this.historyIndex === 0) {
                        this.historyIndex = -1;
                        this.currentInput = '';
                        this.cursorPosition = 0;
                        this.updateInputLine();
                    }
                    break;
                case 'Home':
                    e.preventDefault();
                    this.cursorPosition = 0;
                    this.updateInputLine();
                    break;
                case 'End':
                    e.preventDefault();
                    this.cursorPosition = this.currentInput.length;
                    this.updateInputLine();
                    break;
                case 'Tab':
                    e.preventDefault();
                    this.handleTabComplete();
                    break;
            }
        }

        handleTabComplete() {
            const commands = [':help', ':open', ':ls', ':show', ':ins', ':insr', ':del', ':delr',
                ':w', ':run', ':resolve', ':plugins', ':plugin_run', ':toggle_dups',
                ':q', ':export', ':import', ':clear', ':config'];
            if (this.currentInput.startsWith(':')) {
                const matches = commands.filter(c => c.startsWith(this.currentInput));
                if (matches.length === 1) {
                    this.currentInput = matches[0] + ' ';
                    this.cursorPosition = this.currentInput.length;
                    this.updateInputLine();
                } else if (matches.length > 1) {
                    this.printLine('');
                    this.printLine('Available commands: ' + matches.join(', '));
                    this.newInputLine();
                    this.updateInputLine();
                }
            }
        }

        executeCommand() {
            const command = this.currentInput.trim();
            if (!command) {
                this.printLine('>> ');
                this.newInputLine();
                return;
            }

            this.printLine(`>> ${command}`);

            if (command !== this.commandHistory[this.commandHistory.length - 1]) {
                this.commandHistory.push(command);
                if (this.commandHistory.length > 100) this.commandHistory.shift();
            }

            this.currentInput = '';
            this.cursorPosition = 0;
            this.historyIndex = -1;

            this.parseAndExecute(command);
            this.newInputLine();
        }

        parseAndExecute(command) {
            const parts = command.split(/\s+/);
            const cmd = parts[0];
            switch (cmd) {
                case ':help': this.showHelp(); break;
                case ':open':
                    if (parts.length >= 2) this.openBank(parts[1]);
                    else this.printError('Usage: :open <bank_id>');
                    break;
                case ':ls': this.listBanks(); break;
                case ':show': this.showCurrentBank(); break;
                case ':ins':
                    if (parts.length >= 3) {
                        const addr = parts[1];
                        const value = parts.slice(2).join(' ');
                        this.insertValue(1, addr, value);
                    } else this.printError('Usage: :ins <addr> <value>');
                    break;
                case ':insr':
                    if (parts.length >= 4) {
                        const reg = parts[1];
                        const addr = parts[2];
                        const value = parts.slice(3).join(' ');
                        this.insertValue(reg, addr, value);
                    } else this.printError('Usage: :insr <reg> <addr> <value>');
                    break;
                case ':del':
                    if (parts.length >= 2) this.deleteValue(1, parts[1]);
                    else this.printError('Usage: :del <addr>');
                    break;
                case ':delr':
                    if (parts.length >= 3) this.deleteValue(parts[1], parts[2]);
                    else this.printError('Usage: :delr <reg> <addr>');
                    break;
                case ':w': this.saveCurrentBank(); break;
                case ':run':
                    if (parts.length >= 2) this.runScript(parts[1]);
                    else this.printError('Usage: :run <script.txt>');
                    break;
                case ':resolve': this.showResolved(); break;
                case ':toggle_dups': this.toggleDuplicates(); break;
                case ':q': this.quit(); break;
                case ':clear': this.clearTerminal(); break;
                case ':export': this.exportCurrentBank(); break;
                case ':import': this.importBank(); break;
                case ':config': this.showConfig(); break;
                case ':plugins':
                    this.printLine('<span class="warning">Plugins not available in browser/GOS version</span>', false);
                    break;
                default:
                    if (command.startsWith(':')) this.printError(`Unknown command: ${cmd}. Type :help for commands.`);
                    else this.printError('Commands must start with ":"');
            }
        }

        showHelp() {
            const help = `
<span class="info">CLIX HTML REPL Commands</span>
----------------------------------------------------------------------------------------
<span class="command">:help</span>                          Show this help
<span class="command">:open</span> &lt;ctx&gt;                    Open/create context (e.g. x00001 or 1)
<span class="command">:ls</span>                            List loaded contexts
<span class="command">:show</span>                          Print current buffer
<span class="command">:ins</span> &lt;addr&gt; &lt;value.&gt;         Insert/replace into register 1
<span class="command">:insr</span> &lt;reg&gt; &lt;addr&gt; &lt;value.&gt;  Insert/replace into a specific register
<span class="command">:del</span> &lt;addr&gt;                    Delete from register 1
<span class="command">:delr</span> &lt;reg&gt; &lt;addr&gt;             Delete from a specific register
<span class="command">:w</span>                             Write current buffer to storage
<span class="command">:run</span> &lt;script.txt&gt;              Run commands from a script (paste in prompt)
<span class="command">:resolve</span>                       Print resolved view of current bank
<span class="command">:toggle_dups</span>                   Toggle allowing duplicate values
<span class="command">:export</span>                        Export current bank to file
<span class="command">:import</span>                        Import bank from file
<span class="command">:config</span>                        Show configuration
<span class="command">:clear</span>                         Clear terminal
<span class="command">:q</span>                             Quit (clear session)
----------------------------------------------------------------------------------------
<span class="dim">Tab completion available for commands. Use arrow keys for history.</span>`;
            this.printLine(help, false);
        }

        openBank(idStr) {
            const config = this.workspace.config;
            idStr = idStr.replace(/\.txt$/, '');
            let id;
            if (idStr.startsWith(config.prefix)) id = parseInt(idStr.substring(1), config.base);
            else id = parseInt(idStr, config.base);
            if (isNaN(id)) {
                this.printError('Invalid bank ID format');
                return;
            }
            let bank = this.workspace.getBank(id);
            if (bank) {
                this.workspace.currentBankId = id;
                this.printLine(`<span class="success">Switched to loaded bank: ${config.prefix}${id.toString(config.base).padStart(config.width_bank, '0')}</span>`, false);
            } else {
                bank = this.workspace.loadBank(id);
                if (bank) {
                    this.workspace.currentBankId = id;
                    this.printLine(`<span class="success">Loaded bank from storage: ${config.prefix}${id.toString(config.base).padStart(config.width_bank, '0')}</span>`, false);
                } else {
                    bank = this.workspace.createBank(id, `Bank ${id}`);
                    this.workspace.currentBankId = id;
                    this.printLine(`<span class="success">Created new bank: ${config.prefix}${id.toString(config.base).padStart(config.width_bank, '0')}</span>`, false);
                }
            }
            this.updateStatusBar();
        }

        listBanks() {
            const loaded = Object.keys(this.workspace.banks);
            const saved = this.workspace.getSavedBanks();
            if (loaded.length === 0 && saved.length === 0) {
                this.printLine('<span class="dim">(no banks loaded or saved)</span>', false);
                return;
            }
            if (loaded.length > 0) {
                this.printLine('<span class="info">Loaded banks:</span>', false);
                for (const id of loaded) {
                    const bank = this.workspace.getBank(id);
                    const config = this.workspace.config;
                    const idStr = id.toString(config.base).padStart(config.width_bank, '0');
                    const current = id == this.workspace.currentBankId ? ' <span class="warning">[current]</span>' : '';
                    this.printLine(`  <span class="bank-header">${config.prefix}${idStr}</span> (${bank.title})${current}`, false);
                }
            }
            if (saved.length > 0) {
                this.printLine('<span class="info">Saved banks:</span>', false);
                for (const item of saved) {
                    if (!loaded.includes(item.id.toString())) {
                        this.printLine(`  <span class="dim">${item.name}</span>`, false);
                    }
                }
            }
        }

        showCurrentBank() {
            if (!this.workspace.currentBankId) {
                this.printError('No bank loaded');
                return;
            }
            const bank = this.workspace.getBank(this.workspace.currentBankId);
            const config = this.workspace.config;
            this.printLine(`<span class="bank-header">${config.prefix}${this.workspace.currentBankId.toString(config.base).padStart(config.width_bank, '0')} (${bank.title}) {</span>`, false);
            const regIds = Object.keys(bank.registers).map(Number).sort((a,b)=>a-b);
            for (const regId of regIds) {
                if (regIds.length > 1 || regId !== 1) {
                    this.printLine(`<span class="register-header">${regId.toString(config.base).padStart(config.width_reg, '0')}</span>`, false);
                }
                const addresses = bank.registers[regId];
                const addrIds = Object.keys(addresses).map(Number).sort((a,b)=>a-b);
                for (const addrId of addrIds) {
                    const addrStr = addrId.toString(config.base).padStart(config.width_addr, '0');
                    this.printLine(`\t<span class="address-id">${addrStr}</span>\t<span class="value">${addresses[addrId]}</span>`, false);
                }
            }
            this.printLine('<span class="bank-header">}</span>', false);
        }

        insertValue(reg, addr, value) {
            if (!this.workspace.currentBankId) {
                this.printError('No bank loaded. Use :open <id> first.');
                return;
            }
            const config = this.workspace.config;
            const regId = parseInt(reg, config.base);
            const addrId = parseInt(addr, config.base);
            if (isNaN(regId) || isNaN(addrId)) {
                this.printError('Invalid reg/addr format');
                return;
            }
            const res = this.workspace.setValue(this.workspace.currentBankId, regId, addrId, value);
            if (!res.success) {
                this.printError(res.error);
            } else {
                this.printLine('<span class="success">Value inserted.</span>', false);
                this.updateStatusBar();
            }
        }

        deleteValue(reg, addr) {
            if (!this.workspace.currentBankId) {
                this.printError('No bank loaded.');
                return;
            }
            const config = this.workspace.config;
            const regId = parseInt(reg, config.base);
            const addrId = parseInt(addr, config.base);
            if (isNaN(regId) || isNaN(addrId)) {
                this.printError('Invalid reg/addr format');
                return;
            }
            const ok = this.workspace.deleteValue(this.workspace.currentBankId, regId, addrId);
            if (ok) {
                this.printLine('<span class="success">Value deleted.</span>', false);
                this.updateStatusBar();
            } else {
                this.printError('No such value to delete.');
            }
        }

        saveCurrentBank() {
            if (!this.workspace.currentBankId) {
                this.printError('No bank loaded.');
                return;
            }
            const ok = this.workspace.saveBank(this.workspace.currentBankId);
            if (ok) this.printLine('<span class="success">Bank saved.</span>', false);
            else this.printError('Failed to save bank.');
            this.updateStatusBar();
        }

        showResolved() {
            if (!this.workspace.currentBankId) {
                this.printError('No bank loaded.');
                return;
            }
            const bank = this.workspace.getBank(this.workspace.currentBankId);
            const config = this.workspace.config;
            this.printLine('<span class="info">Resolved view:</span>', false);
            const regIds = Object.keys(bank.registers).map(Number).sort((a,b)=>a-b);
            for (const regId of regIds) {
                const addrObj = bank.registers[regId];
                const addrIds = Object.keys(addrObj).map(Number).sort((a,b)=>a-b);
                for (const addrId of addrIds) {
                    const rawVal = addrObj[addrId];
                    const resolved = this.workspace.resolver.resolve(this.workspace.currentBankId, rawVal);
                    const addrStr = addrId.toString(config.base).padStart(config.width_addr, '0');
                    this.printLine(`<span class="address-id">${addrStr}</span>\t<span class="value">${this.escapeHtml(resolved)}</span>`, false);
                }
            }
        }

        toggleDuplicates() {
            this.workspace.config.allow_duplicate_values = !this.workspace.config.allow_duplicate_values;
            this.workspace.config.save();
            const status = this.workspace.config.allow_duplicate_values ? 'ALLOWED' : 'NOT ALLOWED';
            this.printLine(`<span class="success">Duplicate values are now: ${status}</span>`, false);
            this.updateStatusBar();
        }

        runScript(name) {
            this.showPrompt(
                `Paste script content for "${name}" (linebreaks allowed if you paste):`,
                'Run Script',
                '',
                (script) => {
                    if (!script) {
                        this.printError('Script cancelled');
                        return;
                    }
                    this.printLine(`<span class="info">Running script: ${name}</span>', false`);
                    const lines = script.split('\n');
                    for (const line of lines) {
                        const trimmed = line.trim();
                        if (!trimmed || trimmed.startsWith('#')) continue;
                        this.printLine(`<span class="dim">&gt;&gt; ${trimmed}</span>`, false);
                        this.parseAndExecute(trimmed);
                    }
                    this.printLine('<span class="info">Script completed</span>', false);
                }
            );
        }

        exportCurrentBank() {
            if (!this.workspace.currentBankId) {
                this.printError('No current bank to export');
                return;
            }
            const data = this.workspace.exportBank(this.workspace.currentBankId);
            if (!data) {
                this.printError('Failed to export bank');
                return;
            }
            const blob = new Blob([data.content], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const link = this.root.querySelector('#downloadLink');
            link.href = url;
            link.download = data.filename;
            link.click();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
            this.printLine(`<span class="success">Bank exported as ${data.filename}</span>`, false);
        }

        importBank() {
            const input = this.doc.createElement('input');
            input.type = 'file';
            input.accept = '.txt';
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = (evt) => {
                    const bank = this.workspace.importBankFromText(evt.target.result);
                    if (bank) {
                        this.printLine(`<span class="success">Imported bank: ${bank.id} (${bank.title})</span>`, false);
                        this.updateStatusBar();
                    } else {
                        this.printError('Failed to import bank - invalid format');
                    }
                };
                reader.readAsText(file);
            };
            input.click();
        }

        showConfig() {
            const config = this.workspace.config;
            this.printLine('<span class="info">Current Configuration:</span>', false);
            this.printLine(`  prefix = ${config.prefix}`);
            this.printLine(`  base = ${config.base}`);
            this.printLine(`  width_bank = ${config.width_bank}`);
            this.printLine(`  width_reg = ${config.width_reg}`);
            this.printLine(`  width_addr = ${config.width_addr}`);
            this.printLine(`  allow_duplicate_values = ${config.allow_duplicate_values}`);
        }

        clearTerminal() {
            this.terminal.innerHTML = '';
            this.printHeader();
            this.newInputLine();
        }

        quit() {
            if (this.workspace.dirty) {
                this.showPrompt(
                    'Unsaved changes. Type "yes" to quit anyway:',
                    'Confirm Quit',
                    '',
                    (val) => {
                        if (val !== 'yes') {
                            this.printLine('<span class="warning">Quit cancelled</span>', false);
                            return;
                        }
                        this._doQuit();
                    }
                );
            } else {
                this._doQuit();
            }
        }

        _doQuit() {
            this.printLine('<span class="info">Clearing session...</span>', false);
            this.workspace = new ClixWorkspace();
            this.workspace.config.load();
            this.workspace.currentBankId = null;
            this.printLine('<span class="success">Session cleared. Type :help to start again.</span>', false);
            this.updateStatusBar();
        }


        updateStatusBar() {
            const bankDisplay = this.root.querySelector('#currentBank');
            const dirtyDisplay = this.root.querySelector('#dirtyIndicator');
            const configDisplay = this.root.querySelector('#configDisplay');
            if (this.workspace.currentBankId) {
                const config = this.workspace.config;
                const idStr = this.workspace.currentBankId.toString(config.base).padStart(config.width_bank, '0');
                bankDisplay.textContent = `Bank: ${config.prefix}${idStr}`;
            } else {
                bankDisplay.textContent = 'No bank loaded';
            }
            if (this.workspace.dirty) {
                dirtyDisplay.textContent = '[unsaved]';
                dirtyDisplay.className = 'status-dirty';
            } else {
                dirtyDisplay.textContent = '';
                dirtyDisplay.className = '';
            }
            const config = this.workspace.config;
            configDisplay.textContent = `prefix=${config.prefix} base=${config.base} dupes=${config.allow_duplicate_values ? 'on' : 'off'}`;
        }

        closeFileModal() {
            const modal = this.root.querySelector('#fileModal');
            if (modal) modal.classList.remove('active');
        }
    }

    // 3) boot CLIX
    new ClixREPL(container.querySelector('#clix-app'), doc);
}
