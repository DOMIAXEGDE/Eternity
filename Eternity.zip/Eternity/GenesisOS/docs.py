import os

def list_text_files():
    # Corrected missing comma between '.env' and '.gitignore'
    # Also corrected 'json' to '.json'
    extensions = [
        '.css', '.cmd', '.env', '.gitignore', '.js',
        '.php', '.hpp', '.cpp', '.md', '.py', '.txt',
        '.ps1', '.json', '.html'
    ]
    # Filter files in the current directory based on specified extensions
    return [
        f for f in os.listdir()
        if os.path.isfile(f) and any(f.endswith(ext) for ext in extensions)
    ]

def read_file_content(filename):
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            return file.read()
    except Exception as e:
        return f"[Error reading {filename}]: {e}"

def sort_files(files):
    # Extract numbers from filenames and sort based on those numbers
    def extract_number(file):
        try:
            return int(os.path.splitext(file)[0])
        except ValueError:
            return float('inf')  # In case of unexpected filename format, put it at the end

    return sorted(files, key=extract_number)

def create_txt(files):
    os.makedirs("doc", exist_ok=True)  # Ensure 'doc' directory exists
    output_path = os.path.join("doc", "doc.txt")

    # Prepare sections (index, filename, content)
    sections = []
    for idx, file in enumerate(files, start=1):
        content = read_file_content(file)
        sections.append((idx, file, content))

    with open(output_path, "w", encoding='utf-8') as txt_file:
        # Header
        txt_file.write("Documentation Bundle\n")
        txt_file.write("====================\n\n")

        # Table of Contents
        txt_file.write("Table of Contents\n")
        txt_file.write("-----------------\n")
        for idx, file, _ in sections:
            txt_file.write(f"{idx}. {file}\n")
        txt_file.write("\n\n")

        # Sections
        for idx, file, content in sections:
            header = f"[{idx}] {file}"
            txt_file.write(header + "\n")
            txt_file.write("-" * len(header) + "\n")
            txt_file.write(f";Content of {file}\n")
            txt_file.write(content)
            txt_file.write("\n\n")

if __name__ == "__main__":
    text_files = list_text_files()
    sorted_text_files = sort_files(text_files)

    create_txt(sorted_text_files)  # Generate the text file

    print("Documentation updated: Created 'doc/doc.txt'")
