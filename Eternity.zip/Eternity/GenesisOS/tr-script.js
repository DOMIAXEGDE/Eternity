document.addEventListener('DOMContentLoaded', () => {
    // --- STATE MANAGEMENT ---
    const state = {
        versions: [],
        selectedVersion: null,
        selectedFile: null,
        isDirty: false, // Tracks if editor has unsaved changes
        editor: null,
    };

    // --- DOM SELECTORS ---
    const versionsList = document.getElementById('versions-list');
    const createVersionBtn = document.getElementById('create-version-btn');
    const fileTreeContainer = document.getElementById('file-tree');
    const fileBrowserHeading = document.getElementById('file-browser-heading');
    const editorContainer = document.getElementById('editor-container');
    const editorPlaceholder = document.getElementById('editor-placeholder');
    const editorActions = document.getElementById('editor-actions');
    const saveFileBtn = document.getElementById('save-file-btn');
    const editorHeading = document.getElementById('editor-heading');
    
    const actionsPlaceholder = document.getElementById('actions-placeholder');
    const actionsContent = document.getElementById('actions-content');
    const runTestsBtn = document.getElementById('run-tests-btn');
    const testResultsOutput = document.getElementById('test-results-output');
    const deployBtn = document.getElementById('deploy-btn');
    const downloadBtn = document.getElementById('download-btn');
    const deleteBtn = document.getElementById('delete-btn');

    // --- API HELPER ---
    async function apiCall(action, params = {}) {
        const formData = new FormData();
        formData.append('action', action);
        formData.append('params', JSON.stringify(params));

        try {
            const response = await fetch('api.php', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();
            if (!result.success) {
                throw new Error(result.message);
            }
            return result.data;
        } catch (error) {
            showModal('API Error', `An error occurred: ${error.message}`);
            throw error; // Re-throw to stop promise chains
        }
    }
    
    // --- MODAL/NOTIFICATION ---
    function showModal(title, message, options = {}) {
        const modal = document.getElementById('modal');
        document.getElementById('modal-title').textContent = title;
        document.getElementById('modal-message').innerHTML = message;
        
        const confirmBtn = document.getElementById('modal-confirm-btn');
        const cancelBtn = document.getElementById('modal-cancel-btn');

        modal.style.display = 'flex';
        
        return new Promise((resolve) => {
            confirmBtn.onclick = () => { modal.style.display = 'none'; resolve(true); };
            cancelBtn.onclick = () => { modal.style.display = 'none'; resolve(false); };
            
            if (options.confirmText) confirmBtn.textContent = options.confirmText;
            if (options.showCancel) {
                 cancelBtn.style.display = 'inline-block';
            } else {
                 cancelBtn.style.display = 'none';
            }
        });
    }

    // --- EDITOR ---
    function initializeEditor() {
        state.editor = CodeMirror(editorContainer, {
            lineNumbers: true,
            mode: 'php',
            theme: 'default', // Using CSS variables, a custom theme isn't strictly needed
        });
        state.editor.on('change', () => {
            if (!state.isDirty) {
                state.isDirty = true;
                editorHeading.textContent += ' *';
            }
        });
    }

    // --- RENDER FUNCTIONS ---
    function renderVersions() {
        versionsList.innerHTML = '';
        state.versions.forEach(version => {
            const li = document.createElement('li');
            li.dataset.version = version;
            li.textContent = version;
            if (version === state.selectedVersion) {
                li.classList.add('active');
            }
            li.addEventListener('click', () => selectVersion(version));
            versionsList.appendChild(li);
        });
    }

    function renderFileTree(files) {
        fileTreeContainer.innerHTML = '';
        // Simple, non-nested tree for now
        files.sort((a, b) => {
            if (a.type === 'dir' && b.type === 'file') return -1;
            if (a.type === 'file' && b.type === 'dir') return 1;
            return a.path.localeCompare(b.path);
        });

        files.forEach(file => {
            const item = document.createElement('div');
            item.className = 'file-tree-item';
            item.dataset.path = file.path;
            item.dataset.type = file.type;
            
            const indent = (file.path.split('/').length - 1) * 15;
            item.style.paddingLeft = `${indent + 8}px`;

            const icon = document.createElement('span');
            icon.className = 'icon';
            icon.textContent = file.type === 'dir' ? '📁' : '📄';

            const name = document.createElement('span');
            name.textContent = file.path.split('/').pop();
            
            item.appendChild(icon);
            item.appendChild(name);
            
            if (file.type === 'file') {
                item.addEventListener('click', () => selectFile(file.path));
            }
            
            if(state.selectedFile === file.path){
                item.classList.add('active');
            }

            fileTreeContainer.appendChild(item);
        });
    }

    function updateActionsPanel() {
        if (state.selectedVersion) {
            actionsPlaceholder.style.display = 'none';
            actionsContent.style.display = 'block';
            testResultsOutput.innerHTML = '';
            deployBtn.disabled = true;
        } else {
            actionsPlaceholder.style.display = 'block';
            actionsContent.style.display = 'none';
        }
    }

    // --- ACTION HANDLERS ---
    async function loadVersions() {
        state.versions = await apiCall('listVersions');
        renderVersions();
    }

    async function selectVersion(version) {
        if (state.isDirty) {
            const abandon = await showModal('Unsaved Changes', 'You have unsaved changes. Do you want to discard them and switch versions?', {showCancel: true});
            if (!abandon) return;
        }
        
        state.selectedVersion = version;
        state.selectedFile = null;
        state.isDirty = false;
        
        // Update UI
        renderVersions();
        fileBrowserHeading.textContent = `Version: ${version}`;
        editorPlaceholder.style.display = 'block';
        editorContainer.style.display = 'none';
        editorActions.style.display = 'none';
        editorHeading.textContent = 'Editor';
        
        updateActionsPanel();

        // Load files
        const files = await apiCall('listVersionFiles', { version });
        renderFileTree(files);
    }

    async function selectFile(filePath) {
        if (state.isDirty) {
            const abandon = await showModal('Unsaved Changes', 'You have unsaved changes. Do you want to discard them and open a new file?', {showCancel: true});
            if (!abandon) return;
        }
        
        state.selectedFile = filePath;
        
        // Update file tree selection
        document.querySelectorAll('.file-tree-item').forEach(el => el.classList.remove('active'));
        document.querySelector(`.file-tree-item[data-path="${filePath}"]`)?.classList.add('active');
        
        // Load file content
        const content = await apiCall('readFile', { version: state.selectedVersion, file: filePath });
        
        editorPlaceholder.style.display = 'none';
        editorContainer.style.display = 'block';
        editorActions.style.display = 'block';
        
        state.editor.setValue(content);
        state.isDirty = false;
        editorHeading.textContent = `Editing: ${filePath}`;
    }

    // --- EVENT LISTENERS ---
    createVersionBtn.addEventListener('click', async () => {
        try {
            await apiCall('createVersion');
            await loadVersions();
            showModal('Success', 'A new version has been created from the live system.');
        } catch (error) {
            // Error is handled in apiCall
        }
    });
    
    saveFileBtn.addEventListener('click', async () => {
        if (!state.selectedVersion || !state.selectedFile) return;
        
        try {
            const content = state.editor.getValue();
            await apiCall('writeFile', {
                version: state.selectedVersion,
                file: state.selectedFile,
                content: content
            });
            state.isDirty = false;
            editorHeading.textContent = `Editing: ${state.selectedFile}`;
            showModal('Success', 'File saved successfully.');
        } catch (error) {
            // Error handled in apiCall
        }
    });

    runTestsBtn.addEventListener('click', async () => {
        if (!state.selectedVersion) return;
        testResultsOutput.textContent = 'Running tests...';
        deployBtn.disabled = true;

        try {
            const results = await apiCall('runTests', { version: state.selectedVersion });
            let outputHtml = '';
            let allPassed = true;

            for (const [testName, result] of Object.entries(results)) {
                const statusClass = result.passed ? 'test-pass' : 'test-fail';
                const statusText = result.passed ? 'PASSED' : 'FAILED';
                if (!result.passed) allPassed = false;
                
                outputHtml += `<div><strong>${testName}:</strong> <span class="${statusClass}">${statusText}</span></div>`;
                outputHtml += `<small>${result.details}</small><br><br>`;
            }
            testResultsOutput.innerHTML = outputHtml;

            if (allPassed) {
                deployBtn.disabled = false;
                showModal('Tests Passed', 'All tests passed successfully. You can now deploy this version.');
            } else {
                showModal('Tests Failed', 'Some tests failed. Please review the output before attempting to deploy.');
            }
        } catch (error) {
            testResultsOutput.textContent = `Error running tests: ${error.message}`;
        }
    });

    deployBtn.addEventListener('click', async () => {
        if (!state.selectedVersion || deployBtn.disabled) return;

        const confirmed = await showModal(
            'Confirm Deployment',
            `Are you sure you want to deploy version <strong>${state.selectedVersion}</strong> to the live site? The current site will be backed up and replaced.`,
            { showCancel: true, confirmText: 'Deploy' }
        );

        if (confirmed) {
            try {
                await apiCall('deployVersion', { version: state.selectedVersion });
                showModal('Deployment Successful', `Version ${state.selectedVersion} is now live.`);
                // Reset state
                state.selectedVersion = null;
                await loadVersions();
                renderVersions();
                fileTreeContainer.innerHTML = '';
                fileBrowserHeading.textContent = 'Select a Version';
                updateActionsPanel();
            } catch (error) {
                // Error handled in apiCall
            }
        }
    });
    
    downloadBtn.addEventListener('click', () => {
        if (!state.selectedVersion) return;
        // This is a direct link, not an API call, to trigger browser download.
        window.location.href = `VersionManager.php?action=download&version=${state.selectedVersion}`;
    });

    deleteBtn.addEventListener('click', async () => {
        if (!state.selectedVersion) return;
        
        const confirmed = await showModal(
            'Confirm Deletion',
            `Are you sure you want to permanently delete version <strong>${state.selectedVersion}</strong>? This action cannot be undone.`,
            { showCancel: true, confirmText: 'Delete' }
        );

        if (confirmed) {
             try {
                await apiCall('deleteVersion', { version: state.selectedVersion });
                showModal('Success', `Version ${state.selectedVersion} was deleted.`);
                 // Reset state
                state.selectedVersion = null;
                await loadVersions();
                renderVersions();
                fileTreeContainer.innerHTML = '';
                fileBrowserHeading.textContent = 'Select a Version';
                updateActionsPanel();
            } catch (error) {
                // Error handled in apiCall
            }
        }
    });


    // --- INITIALIZATION ---
    function init() {
        initializeEditor();
        loadVersions();
    }

    init();
});