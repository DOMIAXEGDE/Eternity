export function initialize(gosApiProxy) {
  const container = gosApiProxy.window.getContainer();
  const doc = container.ownerDocument;

  // --- Styles (minimal rectangle center) ---
  const style = doc.createElement('style');
  style.textContent = `
    :root {
      --bg-color: #1e1e2e;
      --editor-bg: #282a36;
      --text-color: #cdd6f4;
      --line-num-color: #6c7086;
      --border-color: #313244;
      --focus-color: #f5c2e7;
      --placeholder-color: rgba(205,214,244,.5);
      --scrollbar-bg: #313244;
      --scrollbar-thumb: #585b70;
      --scrollbar-thumb-hover: #6c7086;
      --err: #e74c3c;
    }
    .gos-root {
      font-family: 'Fira Code','Cascadia Code','JetBrains Mono',monospace;
      background: var(--bg-color);
      min-height: 100%;
      display:flex;align-items:center;justify-content:center;padding:20px;
    }
    .editor-container {
      width: 90%; max-width: 800px; height: 70vh;
      background: var(--editor-bg);
      border: 2px solid var(--border-color); border-radius: 8px;
      box-shadow: 0 4px 30px rgba(0,0,0,.3);
      transition: border-color .3s ease, box-shadow .3s ease;
      display:flex; overflow:hidden;
    }
    .editor-container:focus-within {
      outline:none; border-color: var(--focus-color);
      box-shadow: 0 0 0 3px rgba(245,194,231,.3), 0 4px 30px rgba(0,0,0,.3);
    }
    .editor-container.dup { border-color: var(--err); box-shadow: 0 0 0 3px rgba(231,76,60,.3), 0 4px 30px rgba(0,0,0,.3); }
    #line-numbers {
      background: var(--editor-bg); color: var(--line-num-color);
      padding: 15px 10px 15px 15px; font-size: 16px; line-height: 1.6;
      user-select:none; text-align:right; overflow-y:hidden; min-width:45px;
      border-right: 1px solid var(--border-color);
    }
    #prompt-text {
      flex:1; height:100%; background:transparent; color:var(--text-color);
      border:none; border-radius:0; padding:15px; font-size:16px; line-height:1.6;
      resize:none; box-shadow:none; tab-size:4; outline:none; overflow-y:scroll;
      scrollbar-width: thin; scrollbar-color: var(--scrollbar-thumb) var(--scrollbar-bg);
    }
    #prompt-text::-webkit-scrollbar{ width:8px; }
    #prompt-text::-webkit-scrollbar-track{ background: var(--scrollbar-bg); border-radius:0 8px 8px 0; }
    #prompt-text::-webkit-scrollbar-thumb{ background: var(--scrollbar-thumb); border-radius:4px; border:2px solid var(--scrollbar-bg); }
    #prompt-text::-webkit-scrollbar-thumb:hover{ background: var(--scrollbar-thumb-hover); }
    #prompt-text::placeholder{ color: var(--placeholder-color); }
    .hint { position:absolute; bottom:14px; left:50%; transform:translateX(-50%); color:var(--line-num-color); font-size:12px; opacity:.8; user-select:none; }
  `;
  doc.head.appendChild(style);

  // --- Shell skeleton ---
  const root = doc.createElement('div');
  root.className = 'gos-root';
  root.innerHTML = `
    <div class="editor-container" id="editor">
      <pre id="line-numbers">1</pre>
      <textarea id="prompt-text" spellcheck="false" placeholder=":help"></textarea>
    </div>
    <div class="hint">Type <code>:help</code> for documentation</div>
  `;
  container.innerHTML = '';
  container.appendChild(root);

  const editor = root.querySelector('#editor');
  // --- Safe confirm (works in sandbox without allow-modals) ---
  const confirmAsync = (message) => {
    try {
      if (gosApiProxy && gosApiProxy.ui && typeof gosApiProxy.ui.confirm === 'function') {
        return gosApiProxy.ui.confirm(message);
      }
    } catch(_) {}
    // DOM-based fallback modal
    return new Promise((resolve) => {
      const doc = gosApiProxy.window.getContainer().ownerDocument;
      const overlay = doc.createElement('div');
      overlay.style.position = 'fixed';
      overlay.style.inset = '0';
      overlay.style.background = 'rgba(0,0,0,.55)';
      overlay.style.display = 'grid';
      overlay.style.placeItems = 'center';
      overlay.style.zIndex = '99999';
      const box = doc.createElement('div');
      box.style.maxWidth = '420px';
      box.style.width = '90%';
      box.style.background = '#282a36';
      box.style.color = '#cdd6f4';
      box.style.border = '1px solid #313244';
      box.style.borderRadius = '10px';
      box.style.boxShadow = '0 10px 30px rgba(0,0,0,.35)';
      box.style.padding = '16px';
      box.innerHTML = `<div style="margin-bottom:12px;font-family:'Fira Code','Cascadia Code','JetBrains Mono',monospace;">${message}</div>`;
      const row = doc.createElement('div');
      row.style.display = 'flex';
      row.style.gap = '8px';
      row.style.justifyContent = 'flex-end';
      const btn = (label, ok) => {
        const b = doc.createElement('button');
        b.textContent = label;
        b.style.background = '#202124';
        b.style.color = '#f1f1f1';
        b.style.border = '1px solid #313244';
        b.style.padding = '8px 12px';
        b.style.borderRadius = '8px';
        b.style.cursor = 'pointer';
        b.onclick = () => { overlay.remove(); resolve(ok); };
        return b;
      };
      row.appendChild(btn('Cancel', false));
      row.appendChild(btn('OK', true));
      box.appendChild(row);
      overlay.appendChild(box);
      doc.body.appendChild(overlay);
    });
  };

  const ta = root.querySelector('#prompt-text');
  const ln = root.querySelector('#line-numbers');

  // --- DB state & helpers ---
  const storeKey = 'db-json.json'; // same name for compatibility with your web version
  let DB = { items: [], dupsBlocked: 0, lastSaved: 'never' };
  let page = 0; const pageSize = 5;
  let anchor = 0; // prompt-lock boundary
  let prevValue = '';

  const nowStr = () => new Date().toLocaleString();
  const sanitize = s => (s||'').replace(/[\s\n\t]+/g,' ').trim().replace(/[.]+\s*$/,''); // strip trailing dots
  const norm = s => sanitize(s).toLowerCase();

  const save = () => { localStorage.setItem(storeKey, JSON.stringify(DB)); DB.lastSaved = nowStr(); };
  const load = () => { const raw = localStorage.getItem(storeKey); if(!raw) return false; try{ const o=JSON.parse(raw); if(Array.isArray(o.items)) DB={ dupsBlocked:0, lastSaved:'never', ...o }; return true; }catch(e){ return false; } };

  const isDup = (s, exceptId=null) => { const n=norm(s); return !!n && DB.items.some(it=> it.id!==exceptId && norm(it.text)===n ); };
  const add = (text) => { const v=sanitize(text); if(!v) return {ok:false,reason:'empty'}; if(isDup(v)){ DB.dupsBlocked++; return {ok:false,reason:'dup'}; } DB.items.push({ id: crypto.randomUUID(), text:v, createdAt:new Date().toISOString(), updatedAt:new Date().toISOString() }); save(); return {ok:true}; };
  const edit = (id, text) => { const v=sanitize(text); if(!v) return false; if(isDup(v, id)) return 'dup'; const it=DB.items.find(x=>x.id===id); if(!it) return false; it.text=v; it.updatedAt=new Date().toISOString(); save(); return true; };
  const delById = (id) => { const n=DB.items.length; DB.items = DB.items.filter(x=>x.id!==id); if(DB.items.length!==n){ save(); return true; } return false; };
  const delByText = (t) => { const n=norm(t); const m=DB.items.length; DB.items = DB.items.filter(x=>norm(x.text)!==n); if(DB.items.length!==m){ save(); return true; } return false; };

  const toLearn = () => DB.items.map(it=>it.text).join(' . ') + (DB.items.length?' .':'');
  const toJson = () => JSON.stringify(DB, null, 2);

  const updateLineNumbers = () => { const lines = ta.value.split('\n').length; ln.textContent = Array.from({length:lines}, (_,i)=>String(i+1)).join('\n'); ln.scrollTop = ta.scrollTop; };
  const setCaretToEnd = () => { ta.selectionStart = ta.selectionEnd = ta.value.length; };

  const print = (s='') => {
    const needsNL = ta.value && !ta.value.endsWith('\n');
    ta.value += (needsNL ? '\n' : '') + s;
    ta.value += (s && !s.endsWith('\n')) ? '\n' : '';
    anchor = ta.value.length;
    prevValue = ta.value;
    setCaretToEnd(); ta.scrollTop = ta.scrollHeight; updateLineNumbers();
  };

  const printListPage = () => {
    const total = DB.items.length; const pages = Math.max(1, Math.ceil(total / pageSize));
    if(page >= pages) page = pages - 1; if(page < 0) page = 0;
    const start = page * pageSize; const end = Math.min(total, start + pageSize);
    print(`LIST (${start+1}-${end} of ${total})  •  :next  :prev`);
    for(let i=start;i<end;i++){
      const it = DB.items[i];
      print(`  - ${String(i+1).padStart(3,' ')} | ${it.text}  [${it.id.slice(0,8)}]`);
    }
  };

  const onTyping = () => {
    const current = ta.value.slice(anchor);
    if(current.startsWith(':')){ editor.classList.remove('dup'); return; }
    editor.classList.toggle('dup', isDup(current));
  };

  const runLine = (line) => {
    const raw = line.trim(); if(!raw) return;
    if(!raw.startsWith(':')){
      const res = add(raw);
      if(res.ok) print('✓ added'); else if(res.reason==='dup') print('✗ duplicate blocked'); else print('· empty ignored');
      return;
    }
    const [cmd, ...rest] = raw.split(/\s+/); const args = rest.join(' ');
    switch(cmd){
      case ':help':
        print(`OVERVIEW
  • Plain text adds an entry (duplicate-safe).
  • Commands start with ':'

COMMANDS
  :help                      Show this help.
  :list                      Show up to 5 entries (use :next / :prev).
  :next / :prev              Page list forward/back.
  :search <q>                Search entries.
  :add <text>                Add entry.
  :edit <id> <text>          Edit by id.
  :del <id|text>             Delete by id or exact text.
  :clear                     Remove ALL entries.
  :stats                     Show counts & last-saved.
  :export json|learn         Download db-json.json or LEARN.txt.
  :import json|learn         Import from a file chooser.
  :save / :load              Persist via localStorage.`);
      break;
      case ':list': page = 0; printListPage(); break;
      case ':next': page++; printListPage(); break;
      case ':prev': page--; printListPage(); break;
      case ':search': {
        const q = norm(args); const hits = DB.items.filter(it=>norm(it.text).includes(q));
        print(`SEARCH '${args}' → ${hits.length} hit(s)`);
        hits.slice(0, pageSize).forEach((it,i)=> print(`  - ${String(i+1).padStart(3,' ')} | ${it.text}  [${it.id.slice(0,8)}]`));
        if(hits.length>pageSize) print(`  … ${hits.length - pageSize} more (refine search)`);
      } break;
      case ':add': { const res = add(args); print(res.ok? '✓ added' : (res.reason==='dup'? '✗ duplicate blocked' : '· empty ignored')); } break;
      case ':del': { const tok=args.trim(); if(!tok){ print('usage: :del <id|text>'); break; } const ok = tok.length>=8 && DB.items.some(it=>it.id.startsWith(tok)) ? delById(DB.items.find(it=>it.id.startsWith(tok)).id) : delByText(tok); print(ok? '✓ deleted':'· not found'); } break;
      case ':edit': { const m=args.match(/^(\S+)\s+([\s\S]+)$/); if(!m){ print('usage: :edit <id> <text>'); break; } const r=edit(m[1], m[2]); print(r===true? '✓ updated' : (r==='dup'? '✗ duplicate blocked' : '· not found')); } break;
      case ':clear':
        confirmAsync('Clear all entries?').then(ok=>{
          if(ok){ DB.items=[]; save(); print('✓ cleared'); }
        });
        break;
      case ':stats': print(`count ${DB.items.length} • duplicates blocked ${DB.dupsBlocked} • last saved ${DB.lastSaved}`); break;
      case ':export': { const t=args.toLowerCase(); if(t==='json') download('db-json.json', toJson(), 'application/json'); else if(t==='learn') download('LEARN.txt', toLearn(), 'text/plain'); else print('usage: :export json|learn'); } break;
      case ':import': { const t=args.toLowerCase(); if(t==='json') pickFile('application/json,.json', importJson); else if(t==='learn') pickFile('.txt', importLearn); else print('usage: :import json|learn'); } break;
      case ':save': save(); print('✓ saved'); break;
      case ':load': print(load()? '✓ loaded' : '· nothing to load'); break;
      default: print(`unknown command: ${cmd}. Type :help`);
    }
  };

  // downloads & import helpers
  const download = (name, content, mime='text/plain') => {
    const blob = new Blob([content],{type:mime});
    const a = doc.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
    doc.body.appendChild(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); },0);
  };
  const pickFile = (accept, cb) => { const inp=doc.createElement('input'); inp.type='file'; inp.accept=accept; inp.onchange=async(e)=>{ const f=e.target.files[0]; if(!f) return; const txt=await f.text(); cb(txt); }; inp.click(); };
  const importLearn = (txt) => { const parts = txt.replace(/\r/g,'').split('.').map(s=>sanitize(s)).filter(Boolean); let adds=0, dups=0; parts.forEach(p=>{ if(isDup(p)) dups++; else { DB.items.push({ id: crypto.randomUUID(), text:p, createdAt:new Date().toISOString(), updatedAt:new Date().toISOString() }); adds++; }}); DB.dupsBlocked += dups; save(); print(`Imported ${adds} entr${adds===1?'y':'ies'}${dups?`, ${dups} duplicate skipped`:''}.`); };
  const importJson = (txt) => { try{ const o=JSON.parse(txt); if(!Array.isArray(o.items)) throw new Error('Invalid JSON'); let adds=0, dups=0; o.items.forEach(it=>{ const v=sanitize(it.text); if(!v) return; if(isDup(v)) dups++; else { DB.items.push({ id: crypto.randomUUID(), text:v, createdAt:new Date().toISOString(), updatedAt:new Date().toISOString() }); adds++; }}); DB.dupsBlocked += dups; save(); print(`Merged ${adds} entr${adds===1?'y':'ies'}${dups?`, ${dups} duplicate skipped`:''}.`);}catch(e){ print('Import failed: '+e.message); } };

  // guards to protect printed output (prompt-lock)
  ta.addEventListener('beforeinput', (e)=>{
    const start = ta.selectionStart, end = ta.selectionEnd;
    const isDeletion = e.inputType?.startsWith('delete');
    if(start < anchor || (isDeletion && end <= anchor)) { e.preventDefault(); setCaretToEnd(); }
  });
  ta.addEventListener('keydown', (e)=>{
    if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); const line = ta.value.slice(anchor); runLine(line); print(''); return; }
    if(e.key==='Home'){ e.preventDefault(); ta.selectionStart = ta.selectionEnd = anchor; return; }
    if(e.key==='Backspace' && ta.selectionStart<=anchor && ta.selectionEnd<=anchor){ e.preventDefault(); return; }
  });
  ta.addEventListener('input', ()=>{
    if(ta.selectionStart < anchor || ta.value.length < anchor){
      const keep = prevValue.slice(0, anchor);
      const tail = ta.value.slice(Math.max(anchor, 0));
      ta.value = keep + tail; setCaretToEnd();
    }
    prevValue = ta.value; onTyping(); updateLineNumbers();
  });
  ta.addEventListener('scroll', ()=>{ ln.scrollTop = ta.scrollTop; });

  // boot
  load();
  print('Ready. Type :help for documentation.');
}
