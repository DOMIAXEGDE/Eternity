// lattice-gamev4.js
// Genesis OS app version of the "x00004 Lattice Game Workbench"
// modelled after clix.js structure

export function initialize(gosApiProxy) {
  const container = gosApiProxy.window.getContainer();
  const doc = container.ownerDocument;
  const win = doc.defaultView;

  // -------- inject styles (taken from lattice-gamev4.html) --------
  const style = doc.createElement("style");
  style.textContent = `
    * { box-sizing: border-box; }
    #lattice-app {
      margin: 0;
      height: 100%;
      display: flex;
      background: #000;
      color: #eee;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      min-height: 0;
    }
    #lattice-app #panel {
      display: flex;
      flex-direction: column;
      width: 250px;
      background: #121212;
      border-right: 1px solid #2c2c2c;
      padding: 6px;
      gap: 4px;
      min-height: 0;
    }
    #lattice-app #panel-top {
      flex: 0 0 auto;
    }
    #lattice-app h1 { font-size: 0.95rem; margin: 0; }
    #lattice-app label {
      font-size: 0.7rem;
      color: #ddd;
      display: block;
      margin-top: 4px;
    }
    #lattice-app input,
    #lattice-app select,
    #lattice-app button,
    #lattice-app textarea {
      width: 100%;
      background: #0f0f0f;
      border: 1px solid #333;
      color: #eee;
      border-radius: 4px;
      padding: 4px 6px;
      font-size: 0.7rem;
    }
    #lattice-app button { cursor: pointer; background: #222; }
    #lattice-app button:hover { background: #2e2e2e; }
    #lattice-app textarea {
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      resize: vertical;
    }
    #lattice-app small { font-size: 0.6rem; color: #aaa; }
    #lattice-app #viewport {
      flex: 1;
      position: relative;
      background: radial-gradient(circle at top, #050505 0%, #000 80%);
      overflow: hidden;
      min-width: 0;
    }
    #lattice-app #canvas { width: 100%; height: 100%; display: block; }
    #lattice-app .legend { font-size: 0.6rem; line-height: 1.4; }
    #lattice-app .legend-row { display: flex; align-items: center; gap: 4px; margin-bottom: 2px; }
    #lattice-app .swatch { width: 10px; height: 10px; border-radius: 9999px; }
    #lattice-app #coordInfo { font-size: 0.6rem; color: #ccc; }
    #lattice-app #log {
      background: #0f0f0f;
      border: 1px solid #333;
      min-height: 34px;
      max-height: 70px;
      overflow-y: auto;
      font-size: 0.6rem;
      padding: 4px 6px;
      white-space: pre-wrap;
    }
    #lattice-app #meshGallery {
      background: #111;
      border: 1px solid #333;
      max-height: 140px;
      overflow-y: auto;
      font-size: 0.65rem;
      padding: 4px;
    }
    #lattice-app .mesh-item {
      padding: 2px 4px;
      cursor: pointer;
      border-radius: 3px;
    }
    #lattice-app .mesh-item:hover { background: #2c2c2c; }
    #lattice-app .mesh-item.active { background: #444; }
    #lattice-app #meshJson {
      min-height: 100px;
      max-height: 140px;
    }
    #lattice-app #api-doc {
      background: #121212;
      border: 1px solid #2c2c2c;
      border-radius: 6px;
      padding: 6px;
      margin-top: 6px;
      max-height: 300px;
      overflow-y: auto;
    }
    #lattice-app #api-doc .doc-title {
      font-size: 0.7rem;
      font-weight: 600;
      margin-bottom: 4px;
    }
    #lattice-app #api-doc details { margin-bottom: 4px; }
    #lattice-app #api-doc summary { cursor: pointer; font-size: 0.65rem; }
    #lattice-app #api-doc .doc-code {
      background: #000;
      border: 1px solid #333;
      border-radius: 4px;
      padding: 4px 6px;
      font-size: 0.6rem;
      white-space: pre;
      overflow-x: auto;
    }
    #lattice-app #api-doc .doc-text {
      font-size: 0.6rem;
      line-height: 1.3;
      margin-top: 4px;
    }
    #lattice-app #api-doc .doc-text h4 {
      font-size: 0.62rem;
      margin: 5px 0 2px;
    }
    #lattice-app #api-doc .doc-text ul,
    #lattice-app #api-doc .doc-text ol {
      padding-left: 16px;
      margin: 3px 0;
    }
  `;
  doc.head.appendChild(style);

  // -------- inject HTML --------
  container.innerHTML = `
    <div id="lattice-app">
      <div id="panel">
        <div id="panel-top">
          <h1>x00004 Lattice Game</h1>
          <label>
            Dimension
            <select id="dimension">
              <option value="1">1D</option>
              <option value="2" selected>2D</option>
              <option value="3">3D</option>
            </select>
          </label>
          <label>
            Extent per dimension
            <input id="extent" type="number" value="6" min="1" max="48" />
          </label>
          <label>
            Basis X (default 2)
            <input id="basisX" type="number" value="2" min="1" />
          </label>
          <label>
            Basis Y (default 3)
            <input id="basisY" type="number" value="3" min="1" />
          </label>
          <label>
            Basis Z (default 5)
            <input id="basisZ" type="number" value="5" min="1" />
          </label>

          <label>
            Rotate Y (3D)
            <input id="rotY" type="range" min="-180" max="180" value="-45" />
          </label>
          <label>
            Rotate X (3D)
            <input id="rotX" type="range" min="-90" max="90" value="25" />
          </label>
          <label>
            Zoom
            <input id="zoom" type="range" min="0.3" max="2.5" value="1.1" step="0.05" />
          </label>

          <div class="legend">
            <div class="legend-row"><span class="swatch" style="background:#fff;"></span>valid island (x00004.03)</div>
            <div class="legend-row"><span class="swatch" style="background:#555;"></span>invalid island (code division)</div>
            <div class="legend-row"><span class="swatch" style="background:#f90;"></span>even-toggled (02)</div>
          </div>

          <label>
            Game script (JS)
            <textarea id="scriptBox" style="min-height:90px">// Example:
engine.buildMeshes();
engine.showAllMeshes();</textarea>
          </label>
          <button id="runScript">Run Script</button>
          <div id="log"></div>

          <label style="margin-top:6px;">Mesh Gallery (auto)</label>
          <div id="meshGallery"></div>

          <label style="margin-top:6px;">Mesh JSON (auto)</label>
          <textarea id="meshJson" readonly></textarea>

          <div id="api-doc">
            <div class="doc-title">JavaScript Scripting API</div>

            <details open>
              <summary>engine object</summary>
              <pre class="doc-code">
        // core
        engine.getPoints()
        engine.read(i,j,k)
        engine.write(i,j,k,value)
        engine.toggle(i,j,k)
        engine.highlight(i,j,k,color)
        engine.clearHighlights()
        engine.draw()

        // mesh
        engine.buildMeshes()
        engine.getMeshes()
        engine.showMesh(index)
        engine.showAllMeshes()

        // export (if you added JSON download earlier)
        engine.exportMeshesJSON?.()
        engine.downloadMeshesJSON?.("mesh-db.json")
            </pre>
            </details>

            <details>
            <summary>Data: point</summary>
            <pre class="doc-code">
        {
            i: Number,    // 0-based lattice index X
            j: Number,    // 0-based lattice index Y (1D → 0)
            k: Number,    // 0-based lattice index Z (1D/2D → 0)
            valid: Bool   // x00004.03 says this is a valid island
        }
            </pre>
            </details>

            <details>
            <summary>Data: mesh (from engine.getMeshes())</summary>
            <pre class="doc-code">
        [
            { i:0, j:0, k:0 },
            { i:1, j:0, k:0 },
            ...
        ]
            </pre>
            </details>

            <details>
            <summary>Recipe: build + view all</summary>
            <pre class="doc-code">
        engine.buildMeshes();
        const meshes = engine.getMeshes();
        engine.showAllMeshes();
            </pre>
            </details>

            <details>
            <summary>Recipe: step through meshes</summary>
            <pre class="doc-code">
        engine.buildMeshes();
        const ms = engine.getMeshes();
        let idx = 0;
        function nextMesh() {
            engine.showMesh(idx);
            idx = (idx + 1) % ms.length;
        }
        nextMesh(); // call again to advance
            </pre>
            </details>

            <details>
            <summary>Recipe: use lattice as memory</summary>
            <pre class="doc-code">
        // write a value (stored in toggle-map space)
        engine.write(2,0,0,5);

        // read it back
        const cell = engine.read(2,0,0);
        console.log(cell.toggles, cell.isValid);
            </pre>
            </details>

            <details>
            <summary>Render flags (if present)</summary>
            <pre class="doc-code">
        engine.setRender?.({
            invalid: false, // hide invalid islands
            edges: true,    // draw mesh edges
            vertices: true, // draw mesh vertices
            angles: false   // show angle hints
        });
            </pre>
            </details>

            <details>
            <summary>Mesh JSON schema (export)</summary>
            <pre class="doc-code">
        {
            "meta": {
            "basis": { "x":2, "y":3, "z":5 },
            "dimension": 3,
            "extent": 6
            },
            "meshes": [
            {
                "id": 0,
                "size": 174,
                "vertices": [ { "i":0,"j":0,"k":0 }, ... ],
                "edges": [ [ {i:0,j:0,k:0}, {i:1,j:0,k:0} ], ... ],
                "degree": { "0,0,0": 3, ... },
                "bounds": { "i":[0,5], "j":[0,5], "k":[0,5] },
                "centroid": { "i":2.4,"j":1.6,"k":0, "X":..., "Y":..., "Z":... },
                "angles": { "0,0,0": [90,90,...], ... }
            }
            ]
        }
            </pre>
            </details>
            <details>
            <summary>Engineering Science Notes (full)</summary>
            <div class="doc-text">
                <p><strong>Short answer:</strong> you just gave yourself a way to <strong>spawn repeatable, addressable, geometry-based experiments</strong> on demand. That turns “I have an idea for a structure / network / controller” into “I can generate a clean discrete space, label the good cells, and run code on it” — in 1D, 2D, or 3D — with the same rules every time.</p>

                <h4>1. Deterministic = testable engineering experiments</h4>
                <p>Because the lattice is generated the same way from the same inputs (extent, basis, dimension, x00004.03), you can:</p>
                <ul>
                <li>run Algorithm A on the lattice,</li>
                <li>run Algorithm B on <strong>the exact same</strong> lattice,</li>
                <li>compare outcomes.</li>
                </ul>
                <p>That’s basically <strong>“same geometry, different engineering method.”</strong> That’s what people try to do in CFD, FEA, control experiments, etc. You’ve got a toy-sized but totally reproducible discrete domain.</p>

                <h4>2. Valid vs invalid = structural vs control planes</h4>
                <p>Your “valid islands” and “invalid islands” separation is sneaky powerful:</p>
                <ul>
                <li><strong>valid</strong> = where the “thing” lives (structure, path, data, terrain)</li>
                <li><strong>invalid</strong> = out-of-band (metadata, code division, channel separation, keying)</li>
                </ul>
                <p>That’s basically a <strong>built-in multiplexing scheme.</strong> In engineering science terms, you’ve got:</p>
                <ul>
                <li>a <strong>primary field</strong> (the realizable nodes), and</li>
                <li>a <strong>sideband field</strong> (constraints, priorities, security tags).</li>
                </ul>
                <p>This lets you prototype:</p>
                <ul>
                <li>routing with guard channels,</li>
                <li>multi-layer additive manufacturing patterns,</li>
                <li>logic-on-a-grid where some cells cannot be used.</li>
                </ul>

                <h4>3. 1D / 2D / 3D → three classic engineering problem classes</h4>
                <p><strong>1D (lines):</strong></p>
                <ul>
                <li>signal / pipeline models</li>
                <li>timing chains</li>
                <li>“instruction buses” like CLIX</li>
                <li>serial inspection: walk from cell 0 → N deterministically</li>
                </ul>
                <p><strong>2D (panels):</strong></p>
                <ul>
                <li>circuit boards / floorplans / cellular automata</li>
                <li>layer-by-layer toolpaths</li>
                <li>image/bitmap → structure mappings</li>
                <li>process scheduling as a grid</li>
                </ul>
                <p><strong>3D (volumes):</strong></p>
                <ul>
                <li>structural frames / trusses / voxel materials</li>
                <li>pathfinding / coverage in space (drones, arms, scanners)</li>
                <li>volumetric encryption or stego (hide data in valid pockets)</li>
                <li>layout for programmable matter / 3D-printed metamaterials</li>
                </ul>
                <p>You just unified those under one generator.</p>

                <h4>4. A playground for lattice-based crypto / stego</h4>
                <p>Now that the meshes are deterministic and exportable as JSON, you can:</p>
                <ol>
                <li>Treat the <strong>mesh shape itself</strong> as the key (only someone who can regenerate your x00004.03 lattice with the same params can interpret it).</li>
                <li>Use <strong>invalid</strong> cells as code-division slots.</li>
                <li>Play with <strong>parity toggles (01, 02)</strong> as a signaling layer.</li>
                </ol>
                <p>This is very close to <strong>structure-as-key</strong> cryptography: the message only makes sense when embedded in the right lattice.</p>

                <h4>5. Procedural CAD / Generative engineering</h4>
                <p>You now have “procedural geometry that is guaranteed to be clean.” That means you can do:</p>
                <ul>
                <li><strong>parameter sweeps</strong>: vary basis (2,3,5) → get different density lattices</li>
                <li><strong>component extraction</strong>: each mesh = 1 component</li>
                <li><strong>library building</strong>: export JSON → feed to another tool → loft/extrude → get printable parts</li>
                </ul>
                <p>That’s a mini <strong>engineering-PCG</strong> pipeline: deterministic grid → extract topologies → push to CAD.</p>

                <h4>6. Discrete control / robotics thinking</h4>
                <p>A 3D lattice with edges is literally a <strong>graph with known adjacency.</strong> That’s the starting point for:</p>
                <ul>
                <li>coverage algorithms (visit all valid nodes)</li>
                <li>shortest path in constrained structure</li>
                <li>task allocation (assign robots to sub-meshes)</li>
                <li>safety zones (invalid = don’t go there)</li>
                </ul>
                <p>Because you can regenerate the same lattice again, you can test controllers on the identical graph — <strong>same plant, different controller.</strong></p>

                <h4>7. Metamaterials & structural patterning (discrete)</h4>
                <p>Your generator is making <strong>repeatable cell complexes.</strong> The mesh DB already has:</p>
                <ul>
                <li>vertices</li>
                <li>edges</li>
                <li>bounds</li>
                <li>degrees</li>
                </ul>
                <p>So you can:</p>
                <ul>
                <li>assign stiffness per edge,</li>
                <li>run a quick constraint check,</li>
                <li>label load paths,</li>
                <li>study “remove every 3rd valid cell” in a controlled space.</li>
                </ul>

                <h4>8. Education / formal methods bridge</h4>
                <p>You can show, on one page:</p>
                <ol>
                <li>the rule (x00004.03),</li>
                <li>the result (the lattice),</li>
                <li>the machine-readable form (JSON),</li>
                <li>the program that runs on it (the JS textbox).</li>
                </ol>
                <p>That’s the whole <strong>spec → model → artifact</strong> cycle — very good for teaching engineering science.</p>

                <h4>9. Integration with CLIX / C700</h4>
                <p>You already have banks, resolvers, pointer-style instruction definitions. Now you also have a <strong>geometric address space.</strong> So you can say:</p>
                <blockquote>“Instruction x00004.03 applies to the 3D lattice where valid cells form mesh #2.”</blockquote>
                <p>That’s spatial scoping of instructions — <strong>geometry-scoped programs.</strong></p>

                <h4>TL;DR</h4>
                <ul>
                <li><strong>Repeatable experiments</strong> (same geometry every time)</li>
                <li><strong>Clean separation</strong> of data vs control via valid/invalid</li>
                <li><strong>A graph you can simulate on</strong> (pathfinding, coverage, logistics)</li>
                <li><strong>Shape-as-key crypto/stego</strong></li>
                <li><strong>Pipeline to CAD / 3D printing / structural analysis</strong></li>
                <li><strong>Didactic rule → structure → program flow</strong></li>
                </ul>
                <p>So this page is basically a small, deterministic <strong>geometry lab</strong> for engineering science.</p>
            </div>
            </details>
            <details>
            <summary>x00004.00 – x00004.03 (bank specifics)</summary>
            <div class="doc-text">
                <h4>x00004.00 — Prime basis</h4>
                <p>
                <code>0000 A set of prime numbers, serves as a basis for all positive and negative integers (Including zero), by repeated addition and subtraction.</code>
                </p>
                <p>
                This declares the arithmetic foundation: pick a finite set of primes (in this bank we later see {2,5,3}) and allow repeated ± operations. With repetition and sign you can span ℤ. This is the numeric substrate the rest of the bank assumes. :contentReference[oaicite:0]{index=0}
                </p>

                <h4>x00004.01 — Odd-toggle rule</h4>
                <p>
                <code>0000 An odd number of toggle actions (between two states) yields the final state being equal to the initial state.</code>
                </p>
                <p>
                This is your “parity holds” rule: if you toggle 1, 3, 5… times, you end where you started. This is intentionally the reverse of the usual UI toggle, but it’s consistent with the rest of your system. We use this in the UI to decide how a clicked point should look after an odd count. :contentReference[oaicite:1]{index=1}
                </p>

                <h4>x00004.02 — Even-toggle rule</h4>
                <p>
                <code>0000 An even number of toggle actions (Between two states) yields the non initial state as the final state.</code>
                </p>
                <p>
                Complement to 01: after 2, 4, 6… toggles, you must show the opposite of the initial state. Together 01 + 02 define the parity semantics we baked into the lattice click-handler. :contentReference[oaicite:2]{index=2}
                </p>

                <h4>x00004.03 — Parameterized numeric construction</h4>
                <p>This is the big one. It’s a staged definition that introduces symbols and then ties them together:</p>
                <ul>
                <li><strong>Variables:</strong> <code>a</code>, <code>b</code>, <code>p</code>, <code>k</code>, <code>z</code>, <code>epsilon</code>, <code>L</code>.</li>
                <li><strong>Prime constraint:</strong> <code>p is less than or equal to 12 and prime</code>.</li>
                <li><strong>Ordering:</strong> <code>a is greater than b</code> (later text also says “This is true for values for a and b from 1 to 101010100”).</li>
                <li><strong>Summation:</strong> <code>k</code> is defined as “the summation of (i + 1) from i = a to i = b”.</li>
                <li><strong>Derived value:</strong> <code>z</code> is “the square root (k / 2a)”.</li>
                <li><strong>Epsilon set:</strong> epsilon ∈ { e1, e2, e3, e4, e5 } where:
                    <ul>
                    <li>e1 = 1</li>
                    <li>e2 = 0</li>
                    <li>e3 = 1 − (decimal part of z)</li>
                    <li>e4 = (decimal part of z)</li>
                    <li>e5 = −1</li>
                    </ul>
                </li>
                <li><strong>L-member rule:</strong> <code>L</code> is a member of { 2, 5, 3 } — which matches the prime basis introduced in 00.</li>
                <li><strong>XOR condition:</strong> there is an exclusive-or on <code>(z − epsilon)</code> and <code>(z + epsilon)</code> being a member of {2,5,3} — i.e. exactly one of those offsets must land in the basis set.</li>
                <li><strong>Domain:</strong> “This is true for values for a and b from 1 to 101010100”.</li>
                </ul>
                <p>
                Put differently: x00004.03 is a recipe to turn index-like integers (a, b) into a structured numeric neighborhood around <code>z</code>, then select an allowable epsilon from a 5-element set, then assert membership of an offset in {2,5,3}. That’s exactly what we used to decide whether a lattice point is a “valid island.” :contentReference[oaicite:3]{index=3}
                </p>
                <p>
                The tail lines <code>0033</code>–<code>0041</code> are the resolved / compressed restatements (they restitch the earlier tokens into full sentences).
                </p>
            </div>
            </details>
          </div>

          <small>
            01: odd toggles → stay initial<br>
            02: even toggles → non-initial<br>
            03: z/epsilon/L → valid island<br>
            mesh-mode → only vertices/edges
          </small>
          <div id="coordInfo">Hover: (–)</div>
        </div>
      </div>
      <div id="viewport">
        <canvas id="canvas"></canvas>
      </div>
    </div>
  `;

  // -------- JS logic (adapted from lattice-gamev4.html) --------
  const root = container.querySelector("#lattice-app");
  const canvas = root.querySelector("#canvas");
  const ctx = canvas.getContext("2d");

  const dimensionSel = root.querySelector("#dimension");
  const extentInput = root.querySelector("#extent");
  const basisXInput = root.querySelector("#basisX");
  const basisYInput = root.querySelector("#basisY");
  const basisZInput = root.querySelector("#basisZ");
  const rotYInput = root.querySelector("#rotY");
  const rotXInput = root.querySelector("#rotX");
  const zoomInput = root.querySelector("#zoom");
  const scriptBox = root.querySelector("#scriptBox");
  const runScriptBtn = root.querySelector("#runScript");
  const coordInfo = root.querySelector("#coordInfo");
  const logBox = root.querySelector("#log");
  const meshGallery = root.querySelector("#meshGallery");
  const meshJson = root.querySelector("#meshJson");

  // state
  let toggles = new Map();
  let points = [];
  let extraColors = new Map();
  let meshes = [];
  const viewState = { mode: "all", currentMesh: -1 };

  function frac(x) { return x - Math.floor(x); }
  function almostEq(a, b, tol = 1e-6) { return Math.abs(a - b) < tol; }
  function logTime() { return new Date().toLocaleTimeString(); }
  function logMsg(msg) {
    logBox.textContent = `[${logTime()}] ${msg}\n` + logBox.textContent;
  }

  // rule checker (x00004.03)
  function isValidX00004_03(i, j, k) {
    let a = i + 1;
    let b = (typeof j === "number") ? j + 1 : a;
    if (a > b) { const tmp = a; a = b; b = tmp; }

    let K = 0;
    for (let t = a; t <= b; t++) K += (t + 1);

    const zVal = Math.sqrt(K / (2 * a));
    const epsSet = [1, 0, 1 - frac(zVal), frac(zVal), -1];
    const Lset = [2, 5, 3];

    for (const eps of epsSet) {
      const zMinus = zVal - eps;
      const zPlus = zVal + eps;
      const minusIn = Lset.some(v => almostEq(zMinus, v));
      const plusIn = Lset.some(v => almostEq(zPlus, v));
      if (minusIn !== plusIn && (minusIn || plusIn)) return true;
    }
    return false;
  }

  function getPointId(i, j, k) { return `${i},${j},${k}`; }

  function resize() {
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
    draw();
  }

  function buildLattice() {
    points = [];
    extraColors.clear();
    meshes = [];
    viewState.mode = "all";
    viewState.currentMesh = -1;

    const dim = parseInt(dimensionSel.value, 10);
    const extent = parseInt(extentInput.value, 10);
    const bx = parseFloat(basisXInput.value);
    const by = parseFloat(basisYInput.value);
    const bz = parseFloat(basisZInput.value);

    for (let i = 0; i < extent; i++) {
      const maxJ = (dim >= 2) ? extent : 1;
      const maxK = (dim >= 3) ? extent : 1;
      for (let j = 0; j < maxJ; j++) {
        for (let k = 0; k < maxK; k++) {
          const valid = isValidX00004_03(i, j, k);
          const X = i * bx;
          const Y = j * by;
          const Z = k * bz;
          points.push({ i, j, k, X, Y, Z, valid });
        }
      }
    }
    renderMeshGallery();
    meshJson.value = "";
  }

  function projectPoint(p) {
    const w = canvas.width, h = canvas.height;
    const cx = w / 2, cy = h / 2;
    const zoom = parseFloat(zoomInput.value);
    const rx = parseFloat(rotXInput.value) * Math.PI / 180;
    const ry = parseFloat(rotYInput.value) * Math.PI / 180;

    let x = p.X, y = p.Y, z = p.Z;
    const cosY = Math.cos(ry), sinY = Math.sin(ry);
    let x1 = x * cosY - z * sinY;
    let z1 = x * sinY + z * cosY;

    const cosX = Math.cos(rx), sinX = Math.sin(rx);
    let y1 = y * cosX - z1 * sinX;
    let z2 = y * sinX + z1 * cosX;

    const perspective = 400 / (400 + z2);
    const px = cx + x1 * zoom * perspective * 20;
    const py = cy + y1 * zoom * perspective * 20;
    return { x: px, y: py, depth: z2 };
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (viewState.mode === "mesh" && viewState.currentMesh >= 0 && meshes[viewState.currentMesh]) {
      drawMeshMode(meshes[viewState.currentMesh]);
      return;
    }

    const projected = points.map(p => ({ ...p, ...projectPoint(p) }))
                            .sort((a, b) => a.depth - b.depth);

    for (const p of projected) {
      const id = getPointId(p.i, p.j, p.k);
      const toggleCount = toggles.get(id) || 0;
      let color = p.valid ? "#ffffff" : "#555555";
      if (toggleCount > 0 && toggleCount % 2 === 0) color = "#f90";
      if (extraColors.has(id)) color = extraColors.get(id);
      const r = p.valid ? 5 : 3.5;
      ctx.beginPath();
      ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
    }
  }

  function drawMeshMode(mesh) {
    const set = new Set(mesh.map(m => getPointId(m.i, m.j, m.k)));
    const proj = new Map();
    for (const m of mesh) {
      const full = points.find(p => p.i === m.i && p.j === m.j && p.k === m.k);
      if (!full) continue;
      proj.set(getPointId(m.i, m.j, m.k), { ...full, ...projectPoint(full) });
    }

    ctx.lineWidth = 1;
    ctx.strokeStyle = "#ffffff";
    for (const m of mesh) {
      const mid = getPointId(m.i, m.j, m.k);
      const mp = proj.get(mid);
      if (!mp) continue;
      const neigh = [
        [m.i+1, m.j, m.k],
        [m.i-1, m.j, m.k],
        [m.i, m.j+1, m.k],
        [m.i, m.j-1, m.k],
        [m.i, m.j, m.k+1],
        [m.i, m.j, m.k-1],
      ];
      for (const [ni,nj,nk] of neigh) {
        const nid = getPointId(ni,nj,nk);
        if (set.has(nid)) {
          const np = proj.get(nid);
          if (!np) continue;
          ctx.beginPath();
          ctx.moveTo(mp.x, mp.y);
          ctx.lineTo(np.x, np.y);
          ctx.stroke();
        }
      }
    }

    for (const m of mesh) {
      const mid = getPointId(m.i, m.j, m.k);
      const mp = proj.get(mid);
      if (!mp) continue;
      ctx.beginPath();
      ctx.arc(mp.x, mp.y, 5, 0, Math.PI * 2);
      ctx.fillStyle = "#ffffff";
      ctx.fill();
    }
  }

  function buildMeshesDeterministic() {
    const dim = parseInt(dimensionSel.value, 10);
    const extent = parseInt(extentInput.value, 10);
    const pointMap = new Map();
    for (const p of points) pointMap.set(getPointId(p.i, p.j, p.k), p);

    const visited = new Set();
    const outMeshes = [];

    for (let i = 0; i < extent; i++) {
      const maxJ = (dim >= 2) ? extent : 1;
      const maxK = (dim >= 3) ? extent : 1;
      for (let j = 0; j < maxJ; j++) {
        for (let k = 0; k < maxK; k++) {
          const id = getPointId(i,j,k);
          const p = pointMap.get(id);
          if (!p || !p.valid || visited.has(id)) continue;

          const queue = [p];
          visited.add(id);
          const mesh = [];

          while (queue.length) {
            const cur = queue.shift();
            mesh.push({ i: cur.i, j: cur.j, k: cur.k });

            const neigh = [
              [cur.i+1, cur.j, cur.k],
              [cur.i-1, cur.j, cur.k],
              [cur.i, cur.j+1, cur.k],
              [cur.i, cur.j-1, cur.k],
              [cur.i, cur.j, cur.k+1],
              [cur.i, cur.j, cur.k-1],
            ];

            for (const [ni,nj,nk] of neigh) {
              if (ni < 0 || nj < 0 || nk < 0) continue;
              if (ni >= extent || nj >= ((dim>=2)?extent:1) || nk >= ((dim>=3)?extent:1)) continue;
              const nid = getPointId(ni,nj,nk);
              if (visited.has(nid)) continue;
              const np = pointMap.get(nid);
              if (!np || !np.valid) continue;
              visited.add(nid);
              queue.push(np);
            }
          }
          outMeshes.push(mesh);
        }
      }
    }
    meshes = outMeshes;
    renderMeshGallery();
    renderMeshJson();
  }

  function renderMeshGallery() {
    meshGallery.innerHTML = "";
    meshes.forEach((mesh, idx) => {
      const div = doc.createElement("div");
      div.className = "mesh-item" + (viewState.currentMesh === idx ? " active" : "");
      div.textContent = `Mesh ${idx} — ${mesh.length} pts`;
      div.addEventListener("click", () => {
        engine.showMesh(idx);
      });
      meshGallery.appendChild(div);
    });
  }

  function renderMeshJson() {
    const db = meshes.map((m, i) => ({
      id: i,
      size: m.length,
      points: m
    }));
    meshJson.value = JSON.stringify(db, null, 2);
  }

  // engine API exposed to scripts
  const engine = {
    getPoints() {
      return points.map(p => ({ i:p.i, j:p.j, k:p.k, valid:p.valid }));
    },
    toggle(i, j=0, k=0) {
      const id = getPointId(i,j,k);
      const prev = toggles.get(id) || 0;
      toggles.set(id, prev+1);
    },
    highlight(i, j=0, k=0, color="#fff") {
      const id = getPointId(i,j,k);
      extraColors.set(id, color);
    },
    clearHighlights() { extraColors.clear(); },
    draw() { draw(); },
    read(i, j=0, k=0) {
      const id = getPointId(i,j,k);
      return { toggles: toggles.get(id)||0, isValid: isValidX00004_03(i,j,k) };
    },
    write(i, j=0, k=0, value=1) {
      const id = getPointId(i,j,k);
      toggles.set(id, value);
    },
    buildMeshes() {
      buildMeshesDeterministic();
      logMsg("Meshes built: " + meshes.length);
      return meshes;
    },
    getMeshes() { return meshes; },
    showMesh(idx) {
      if (!meshes[idx]) return;
      viewState.mode = "mesh";
      viewState.currentMesh = idx;
      Array.from(meshGallery.children).forEach((el,i) => {
        el.classList.toggle("active", i === idx);
      });
      draw();
    },
    showAllMeshes() {
      viewState.mode = "all";
      viewState.currentMesh = -1;
      this.clearHighlights();
      const palette = ["#ffffff", "#ff5e5e", "#7df76b", "#5ad1ff", "#ffdb5a", "#ff9ef5"];
      meshes.forEach((mesh, i) => {
        const col = palette[i % palette.length];
         mesh.forEach(p => this.highlight(p.i,p.j,p.k,col));
      });
      draw();
    }
  };

  // expose to console (optional)
  win.engine = engine;

  // events
  runScriptBtn.addEventListener("click", () => {
    try {
      const code = scriptBox.value;
      const fn = new Function("engine", code);
      fn(engine);
      logMsg("Script OK");
    } catch (err) {
      logMsg("Script error: " + err.message);
      console.error(err);
    }
  });

  [dimensionSel, extentInput, basisXInput, basisYInput, basisZInput].forEach(el => {
    el.addEventListener("input", () => {
      buildLattice();
      draw();
    });
  });
  [rotXInput, rotYInput, zoomInput].forEach(el => {
    el.addEventListener("input", draw);
  });

  // canvas hover info
  canvas.addEventListener("mousemove", (e) => {
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    // cheap nearest
    let best = null, bestD = 9999;
    for (const p of points) {
      const pr = projectPoint(p);
      const dx = pr.x - x, dy = pr.y - y;
      const d2 = dx*dx + dy*dy;
      if (d2 < 100 && d2 < bestD) {
        bestD = d2;
        best = p;
      }
    }
    if (best) {
      coordInfo.textContent = `Hover: (${best.i},${best.j},${best.k}) valid=${best.valid}`;
    } else {
      coordInfo.textContent = "Hover: (–)";
    }
  });

  canvas.addEventListener("click", (e) => {
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    let best = null, bestD = 9999;
    for (const p of points) {
      const pr = projectPoint(p);
      const dx = pr.x - x, dy = pr.y - y;
      const d2 = dx*dx + dy*dy;
      if (d2 < 100 && d2 < bestD) {
        bestD = d2;
        best = p;
      }
    }
    if (best) {
      const id = getPointId(best.i,best.j,best.k);
      const prev = toggles.get(id) || 0;
      toggles.set(id, prev+1);
      draw();
    }
  });

  // init
  resize();
  buildLattice();
  draw();

  // resize on window/container resize
  win.addEventListener("resize", resize);
}
